// @ts-check
/**
 * Secret scan (CONTRACTS.md 12.3). Runs before anything is published: on index.md,
 * on every text file in the bundle and on any image metadata left after stripping.
 * Each rule aims at real credentials and stays quiet on ordinary prose.
 * Node built-ins only, so the publish guard can load it fast.
 */

/**
 * @typedef {{ rule: string, line: number, preview: string, file?: string }} SecretHit
 * @typedef {{ id: string, re: RegExp, group?: number, check?: (value: string, m: RegExpExecArray, text: string) => boolean }} Rule
 */

/** Names that hold secrets, inside a longer name too (SECRET_KEY, dbPassword). */
const SECRET_NAME = '(?:password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key|auth[_-]?key|client[_-]?secret)';

/** Values that are clearly not real secrets. */
const PLACEHOLDER = [
  /^<[^>]*>$/, // <password>
  /<[^>]+>/, // user-<token>-here
  /x{3,}/i, // xxx, XXXX
  /\*{3,}/, // ****
  /changeme/i,
  /example/i,
  /\$\{[^}]*\}/, // ${TOKEN}
  /^\$[A-Z_][A-Z0-9_]*$/, // $TOKEN
  /\{\{[^}]*\}\}/, // {{ token }}
  /placeholder/i,
  /redacted/i,
  /^your[-_]/i,
  /dummy/i,
  /^\.{3,}$|…/, // ... or an ellipsis
];

/** @param {string} v */
export function isPlaceholder(v) {
  return PLACEHOLDER.some((re) => re.test(v));
}

/** @param {string} s */
function hasDigit(s) {
  return /\d/.test(s);
}

/** @param {string} s mixed case letters and a digit: how generated keys look */
function looksRandom(s) {
  return /[a-z]/.test(s) && /[A-Z]/.test(s) && /\d/.test(s);
}

/** @param {string} part */
function decodeBase64Url(part) {
  try {
    return Buffer.from(part.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
  } catch {
    return '';
  }
}

/**
 * The value side of a name = value line: not a placeholder, a reference or code, and not a
 * plain word ("token: rotation"). @param {string} v
 */
function assignedValueOk(v) {
  if (isPlaceholder(v) || REFERENCE_VALUE.test(v)) return false;
  // Code, not a value: tokens[idx], crypto.randomBytes(32), config.apiKey
  if (/[()[\]]/.test(v) || /^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+$/.test(v)) return false;
  // Prose like "token: rotation" is a word, not a secret: ask for a digit or a symbol.
  return /[0-9]/.test(v) || /[^A-Za-z]/.test(v.replace(/[-.]/g, '')) || looksRandom(v);
}

/** @param {string} v base64 that decodes to user:password (printable, both sides non-empty) */
function decodesToUserPass(v) {
  return /^[\x20-\x7e]+:[\x20-\x7e]+$/.test(Buffer.from(v, 'base64').toString('latin1'));
}

/**
 * The URL (or bare query string) around a match: from the last space or quote before it to
 * the next one after it, at most 4 KB each way.
 * @param {string} text @param {number} index
 */
function tokenAround(text, index) {
  const stop = /[\s"'<>`]/;
  let a = index;
  while (a > 0 && index - a < 4096 && !stop.test(text[a - 1])) a--;
  let b = index;
  while (b < text.length && b - index < 4096 && !stop.test(text[b])) b++;
  return text.slice(a, b);
}

// Code-ish values that name where a secret comes from, not the secret itself.
const REFERENCE_VALUE = /^(?:process\.env|os\.environ|env\.|secrets\.|vault:|arn:|ssm:|null|none|true|false|undefined|required|optional|string|number|boolean)/i;

/** @type {Rule[]} */
export const RULES = [
  {
    id: 'private-key',
    re: /-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY(?: BLOCK)?-----/g,
  },
  {
    id: 'aws-access-key-id',
    re: /(?<![A-Z0-9])(?:AKIA|ASIA|ABIA|ACCA)[A-Z0-9]{16}(?![A-Z0-9])/g,
    check: (v) => !isPlaceholder(v),
  },
  {
    // 40 characters of base64 on a line that mentions aws (as in ~/.aws/credentials).
    id: 'aws-secret-key',
    re: /(?<![A-Za-z0-9/+=])[A-Za-z0-9/+]{40}(?![A-Za-z0-9/+=])/g,
    check: (v, m, text) => looksRandom(v) && !isPlaceholder(v) && /aws/i.test(lineAround(text, m.index) + '\n' + lineBefore(text, m.index)),
  },
  {
    id: 'github-token',
    re: /(?<![A-Za-z0-9_])(?:(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,255}|github_pat_[A-Za-z0-9_]{50,255})(?![A-Za-z0-9_])/g,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    id: 'slack-token',
    re: /(?<![A-Za-z0-9])xox[abposr]-[A-Za-z0-9-]{10,250}/g,
    check: (v) => (v.match(/\d/g) ?? []).length >= 6 && !isPlaceholder(v),
  },
  {
    id: 'slack-webhook',
    re: /https:\/\/hooks\.slack\.com\/(?:services|workflows|triggers)\/[A-Za-z0-9_/-]{20,200}/g,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    id: 'google-api-key',
    re: /(?<![A-Za-z0-9_-])AIza[0-9A-Za-z_-]{35}(?![A-Za-z0-9_-])/g,
    check: (v) => !isPlaceholder(v),
  },
  {
    id: 'stripe-live-key',
    re: /(?<![A-Za-z0-9_])(?:sk|rk)_live_[0-9A-Za-z]{20,250}/g,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    id: 'anthropic-key',
    re: /(?<![A-Za-z0-9_-])sk-ant-[A-Za-z0-9_-]{20,250}/g,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    // sk-proj-, sk-svcacct-, sk-admin- keys, and the older sk-<48 characters>.
    id: 'openai-key',
    re: /(?<![A-Za-z0-9_-])sk-(?!ant-)(?:(?:proj|svcacct|admin)-[A-Za-z0-9_-]{40,250}|[A-Za-z0-9]{32,250}(?![A-Za-z0-9_-]))/g,
    check: (v) => looksRandom(v.replace(/^sk-(?:proj|svcacct|admin)-/, '')) && !isPlaceholder(v),
  },
  {
    id: 'slack-app-token',
    re: /(?<![A-Za-z0-9])xapp-\d-[A-Za-z0-9-]{10,250}/g,
    check: (v) => hasDigit(v.slice(7)) && !isPlaceholder(v),
  },
  {
    id: 'gitlab-token',
    re: /(?<![A-Za-z0-9_])glpat-[A-Za-z0-9_-]{20,64}/g,
    check: (v) => hasDigit(v.slice(6)) && !isPlaceholder(v),
  },
  {
    id: 'huggingface-token',
    re: /(?<![A-Za-z0-9_])hf_[A-Za-z0-9]{34,64}(?![A-Za-z0-9_])/g,
    check: (v) => /[a-z]/.test(v.slice(3)) && /[A-Z]/.test(v.slice(3)) && !isPlaceholder(v),
  },
  {
    id: 'sendgrid-key',
    re: /(?<![A-Za-z0-9_])SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}(?![A-Za-z0-9_-])/g,
    check: (v) => !isPlaceholder(v),
  },
  {
    id: 'azure-storage-key',
    re: /AccountKey=[A-Za-z0-9+/]{86}==/g,
    check: (v) => !isPlaceholder(v),
  },
  {
    id: 'stripe-webhook-secret',
    re: /(?<![A-Za-z0-9_])whsec_[A-Za-z0-9]{32,128}(?![A-Za-z0-9_])/g,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    id: 'google-oauth-secret',
    re: /(?<![A-Za-z0-9_-])GOCSPX-[A-Za-z0-9_-]{28}(?![A-Za-z0-9_-])/g,
    check: (v) => !isPlaceholder(v),
  },
  {
    id: 'atlassian-token',
    re: /(?<![A-Za-z0-9_])ATATT3[A-Za-z0-9_=-]{100,400}/g,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    id: 'npm-auth-token',
    re: /_auth(?:Token)?\s*=\s*["']?([^\s"']{20,500})/g,
    group: 1,
    check: (v) => !isPlaceholder(v) && !REFERENCE_VALUE.test(v),
  },
  {
    id: 'bearer-token',
    re: /\bBearer[ \t]+([A-Za-z0-9._~+/-]{20,2000}=*)/g,
    group: 1,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    // Authorization: Basic <base64 of user:password>
    id: 'basic-auth',
    re: /\bBasic[ \t]+([A-Za-z0-9+/]{12,2000}={0,2})(?![A-Za-z0-9+/=])/g,
    group: 1,
    check: (v) => !isPlaceholder(v) && decodesToUserPass(v),
  },
  {
    // Docker config.json: "auths": { "registry": { "auth": "<base64 of user:password>" } }
    id: 'docker-auth',
    re: /(?<![A-Za-z0-9_])["']?auth["']?[ \t]*:[ \t]*["']?([A-Za-z0-9+/]{8,2000}={0,2})(?![A-Za-z0-9+/=])/g,
    group: 1,
    check: (v) => !isPlaceholder(v) && decodesToUserPass(v),
  },
  {
    // Azure shared access signature: sig= with sv= or se= in the same URL or query string.
    id: 'azure-sas',
    re: /[?&;=]sig=([A-Za-z0-9%+/=_-]{32,300})/g,
    group: 1,
    check: (v, m, text) => {
      if (isPlaceholder(v)) return false;
      let sig = v;
      try { sig = decodeURIComponent(v); } catch { /* keep it as it is */ }
      return /^[A-Za-z0-9+/_-]{32,}={0,2}$/.test(sig) && /(?:^|[?&;=])(?:sv|se)=[^&\s]/.test(tokenAround(text, m.index));
    },
  },
  {
    id: 'npm-token',
    re: /(?<![A-Za-z0-9_])npm_[A-Za-z0-9]{36}(?![A-Za-z0-9_])/g,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    id: 'posthog-key',
    re: /(?<![A-Za-z0-9_])phc_[A-Za-z0-9]{32,64}(?![A-Za-z0-9_])/g,
    check: (v) => hasDigit(v) && !isPlaceholder(v),
  },
  {
    // Three base64url parts, the first decoding to a JSON header with "alg".
    id: 'jwt',
    re: /(?<![A-Za-z0-9_-])eyJ[A-Za-z0-9_-]{8,2000}\.[A-Za-z0-9_-]{8,8000}\.[A-Za-z0-9_-]{8,2000}/g,
    check: (v) => {
      try {
        const head = JSON.parse(decodeBase64Url(v.split('.')[0]));
        return Boolean(head && typeof head === 'object' && 'alg' in head);
      } catch {
        return false;
      }
    },
  },
  {
    // scheme://user:password@host
    id: 'connection-string',
    re: /(?<![A-Za-z0-9+.-])[A-Za-z][A-Za-z0-9+.-]{1,20}:\/\/([^\s:@/'"`<>]{1,64}):([^\s@/'"`]{1,200})@[A-Za-z0-9.-]+/g,
    group: 2,
    // A port number after a host (http://127.0.0.1:4317@evil.example/) is not a password.
    check: (v, m) => v.length >= 3 && !isPlaceholder(v) && !/^(?:pass(?:word)?|pwd|secret|\*+)$/i.test(v)
      && !(/^\d{1,5}$/.test(v) && /^(?:localhost|[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+|\[[0-9a-fA-F:]+\])$/.test(m[1])),
  },
  {
    // password: hunter2hunter2, API_KEY="...", clientSecret = '...', SECRET_KEY=..., DB_PASSWORD_PROD=..., dbPassword: "..."
    id: 'assignment',
    re: new RegExp(`(?<![A-Za-z0-9_])([A-Za-z0-9_]*?${SECRET_NAME}[A-Za-z0-9_]*)["']?[ \\t]*[:=][ \\t]*["']?([^\\s"'\`,;<>]{8,500})`, 'gi'),
    group: 2,
    check: (v, m) => !/^(?:old)?pwd$/i.test(m[1]) && assignedValueOk(v), // PWD: the shell's working folder
  },
  {
    // DB_PASS=..., SMTP_PASS: ..., smtpPass = ...: "pass" as a whole part of the name
    // (between _, - or a camelCase step), so passport, bypass and compass do not count.
    id: 'pass-assignment',
    // Bounded parts keep it linear on long hyphenated text.
    re: /(?<![A-Za-z0-9_])((?:[A-Za-z0-9]{1,40}[_-]){0,8}[Pp][Aa][Ss][Ss](?:[_-][A-Za-z0-9]{1,40}){0,8}|[a-z][a-z0-9]{0,40}Pass(?:[A-Z0-9][A-Za-z0-9]{0,40})?)["']?[ \t]*[:=][ \t]*["']?([^\s"'`,;<>]{8,500})/g,
    group: 2,
    check: (v) => assignedValueOk(v),
  },
  {
    // password = "correct horse battery staple": a quoted passphrase with spaces.
    id: 'assignment',
    re: /(?<![A-Za-z0-9_])[A-Za-z0-9_]*?(?:password|passwd|passphrase|pwd|secret)[A-Za-z0-9_]*["']?[ \t]*[:=][ \t]*(["'])([^"'\n]*[ \t][^"'\n]*)\1/gi,
    group: 2,
    check: (v) => v.trim().length >= 12 && !isPlaceholder(v) && !REFERENCE_VALUE.test(v),
  },
];

const ENTITIES = /** @type {Record<string, string>} */ ({ quot: '"', '#34': '"', '#39': "'", '#x27': "'", amp: '&', lt: '<', gt: '>' });

/** @param {string} text the basic HTML entities the renderer writes, decoded (no newlines added) */
function decodeEntities(text) {
  return text.replace(/&(quot|#34|#39|#x27|amp|lt|gt);/g, (_, e) => ENTITIES[e] ?? _);
}

/** @param {string} text @param {number} index the line before the one holding index */
function lineBefore(text, index) {
  const start = text.lastIndexOf('\n', index - 1);
  if (start <= 0) return '';
  return text.slice(text.lastIndexOf('\n', start - 1) + 1, start);
}

/** @param {string} text @param {number} index */
function lineAround(text, index) {
  const start = text.lastIndexOf('\n', index - 1) + 1;
  let end = text.indexOf('\n', index);
  if (end === -1) end = text.length;
  return text.slice(start, end);
}

/**
 * Mask all but the first 4 characters. Control characters are replaced.
 * @param {string} v
 */
export function maskPreview(v) {
  const head = v.slice(0, 4).replace(/[\u0000-\u001f\u007f-\u009f]/g, '�');
  return `${head}${'*'.repeat(Math.min(Math.max(v.length - 4, 1), 12))}`;
}

/**
 * Find likely secrets in text.
 * @param {string} text
 * @param {{ file?: string, html?: boolean }} [opts] `html`: decode the basic entities first
 * @returns {SecretHit[]}
 */
export function scanSecrets(text, opts = {}) {
  if (typeof text !== 'string' || text.length === 0) return [];
  if (opts.html) text = decodeEntities(text);
  // Invisible format characters (zero-width space, soft hyphen) inside a token would hide it
  // while the page still shows it. They never hold a newline, so line numbers stay right.
  text = text.replace(/[\p{Cf}\u00ad]/gu, '');
  /** @type {SecretHit[]} */
  const hits = [];
  /** @type {number[]} start offsets of each line, for line numbers */
  const starts = [0];
  for (let i = text.indexOf('\n'); i !== -1; i = text.indexOf('\n', i + 1)) starts.push(i + 1);
  const lineOf = (/** @type {number} */ index) => {
    let lo = 0, hi = starts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (starts[mid] <= index) lo = mid; else hi = mid - 1;
    }
    return lo + 1;
  };
  const seen = new Set();
  for (const rule of RULES) {
    rule.re.lastIndex = 0;
    let m;
    while ((m = rule.re.exec(text)) !== null) {
      if (m[0].length === 0) { rule.re.lastIndex += 1; continue; }
      const value = rule.group ? m[rule.group] ?? m[0] : m[0];
      if (rule.check && !rule.check(value, m, text)) continue;
      const line = lineOf(m.index);
      const key = `${rule.id}:${line}:${value}`;
      if (seen.has(key)) continue;
      seen.add(key);
      /** @type {SecretHit} */
      const hit = { rule: rule.id, line, preview: maskPreview(value) };
      if (opts.file) hit.file = opts.file;
      hits.push(hit);
      if (hits.length >= 100) return hits;
    }
  }
  // One hit per line: the generic assignment rules give way to a more specific one.
  const generic = (/** @type {SecretHit} */ h) => h.rule === 'assignment' || h.rule === 'pass-assignment';
  const specific = new Set(hits.filter((h) => !generic(h)).map((h) => h.line));
  const kept = hits.filter((h) => !generic(h) || !specific.has(h.line));
  // DB_PASSWORD matches both generic rules: keep one.
  const both = new Set(kept.filter((h) => h.rule === 'assignment').map((h) => h.line));
  return kept.filter((h) => h.rule !== 'pass-assignment' || !both.has(h.line)).sort((a, b) => a.line - b.line);
}

/**
 * Printable ASCII runs of 16 or more characters in binary data (image metadata that
 * survived stripping, say), joined by newlines, for scanSecrets.
 * @param {Uint8Array} bytes
 */
export function printableRuns(bytes) {
  /** @type {string[]} */
  const runs = [];
  let start = -1;
  const max = Math.min(bytes.length, 50 * 1024 * 1024);
  for (let i = 0; i <= max; i++) {
    const b = i < max ? bytes[i] : 0;
    const printable = b >= 0x20 && b < 0x7f;
    if (printable && start === -1) start = i;
    else if (!printable && start !== -1) {
      if (i - start >= 16) runs.push(Buffer.from(bytes.subarray(start, i)).toString('latin1'));
      start = -1;
    }
  }
  return runs.join('\n');
}

/**
 * One line per hit, for people and for Claude.
 * @param {SecretHit[]} hits
 */
export function formatSecretHits(hits) {
  return hits.map((h) => `${h.file ?? 'file'}:${h.line}  ${h.rule}  ${h.preview}`).join('\n');
}
