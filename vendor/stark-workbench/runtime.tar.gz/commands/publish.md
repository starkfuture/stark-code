---
description: Publish a Stark page to Stark Pages (checked, scanned for secrets, and confirmed by the user)
argument-hint: "[slug]"
---

Publish a Stark page to Stark Pages. Follow these steps exactly. The publish guard checks every step and asks the user before anything becomes public.

Page (optional): $ARGUMENTS

Rules:
- Publish only because the user asked for it in this conversation (running this command counts). Never start a publish on your own.
- Upload only through the steps below. Never use `curl`, scripts, a browser tool, `pages_upload_files`, the `spage hook` commands or any other route. If the guard denies a step, do not work around it: tell the user what it said.
- Publishing works only in Claude Code. Desktop Chat runs no hooks, so it cannot be guarded.
- Publishing needs a person to say yes. In auto, dontAsk or bypassPermissions mode (or a `-p` run) the guard denies every Pages upload (shared style files too) and every other Pages write. If it says so, tell the user to switch to the default permission mode (Shift+Tab) and ask again. Do not retry.
- Ask the user to answer each publish prompt with a plain yes, never "don't ask again". If the guard says a saved "always allow" rule may skip the question, tell the user which rule and file it named; the user removes it. Do not edit settings files yourself.

Steps:

1. **Pick the page.** Use the slug given above, or the page this conversation is about. Its folder is `pages/<slug>/` in the project folder. If it is not clear which page, ask.
2. **Check the Pages tools.** You need the `pages_upload_begin` and `pages_upload_commit` tools of the Stark Pages MCP server. They usually come from the claude.ai connector "Pages" (`mcp__claude_ai_Pages__pages_*`). If they are missing, tell the user to run `/mcp` and reconnect "Pages". If `/mcp` cannot reconnect it (for example "Server not found"), or there is no such connector, the user adds the server by hand: `claude mcp add --transport http stark-pages https://pages-ext.starkfuture.com/mcp/`, then `/mcp` to sign in to stark-pages. Then stop.
3. **Pick the project.** Read `pages/.spage/publish.json`. If it has a `project`, use it. If not, call `pages_list_projects`, show the user the names, and ask which one. Never guess.
4. **Prepare.** Run:
   `ELECTRON_RUN_AS_NODE=1 "${STARK_WORKBENCH_NODE:-node}" "${CLAUDE_PLUGIN_ROOT}/packages/spage/bin/spage.js" publish prepare pages/<slug> --project "<project>"`
   - Exit 2 means it refused. Show the user the reasons. Fix page errors with Edit if they are yours to fix, then prepare again. If the secret scan found something, tell the user and let them decide how to remove it. Do not publish a page with a `pending` block.
   - On success it prints an upload plan. Keep it: the bundle is good for 30 minutes.
5. **Upload each file, in the order of the plan.** The order is: shared Stark style files (`_stark/`) first, then the page's images, then `index.html` last, so the page goes live only once everything it needs is there. Tell the user how many prompts to expect: one per page file (each image, then `index.html`), none for the shared style files. For each file:
   1. Call `pages_upload_begin` with exactly the arguments the plan shows.
      - A shared style file under `_stark/` goes through without a prompt, except when the plugin runs from inside the project folder: then it asks too, and says why.
      - A page file (`<slug>/img/...` or `<slug>/index.html`) makes Claude Code ask the user, every time, with the page title, the file and its size. That is the guard working; wait for the answer. The prompt for `index.html` says how many of the page's images were already approved. If the user says no, stop and ask what they want.
   2. Stark then uploads the file itself and adds a note to the result: "Stark uploaded <path> (<size>). Now call pages_upload_commit with upload_id <id>." You never see or handle an upload URL; the result shows `[kept by the Stark guard]` in its place.
   3. Call `pages_upload_commit` with that `upload_id`.
   If the note says "Stark could not upload <path>: <reason>", call `pages_upload_begin` again for that file (a page file asks the user again), then commit the new `upload_id`. If the guard denies a begin (the page or bundle changed, another page was prepared since, or the bundle expired), prepare again and restart the upload from the first file.
6. **Record.** Run the plan's last line as printed: `ELECTRON_RUN_AS_NODE=1 "${STARK_WORKBENCH_NODE:-node}" "<spage.js>" publish record <page>`. It reads the public URL Stark kept from the commit of `<slug>/index.html` and notes it in the page header. If it refuses, tell the user what it said.
7. **Reply** in two lines: the public URL (record prints it), and who can see it (the members of the Pages project, or everyone with the link if the project is public; say which if `pages_list_projects` showed it, otherwise say it follows the project's sharing settings).
