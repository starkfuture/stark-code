---
schema: 1
type: data
title: What the numbers show
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Summary

```pending
The main result in one to three sentences.
```

## Data

| Item | Value | Source |
|---|---|---|
| Example row | 0 | path/or/url |

## How it was made

```pending
Where the data came from, the query or steps, and when it was pulled.
```

## Caveats

```pending
What the data does not show.
```
