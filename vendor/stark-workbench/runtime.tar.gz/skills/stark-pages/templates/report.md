---
schema: 1
type: report
title: What the report answers, in plain words
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Bottom line

```pending
The answer in at most three sentences and 450 characters. Lead with the answer, then the one fact that matters most.
```

## Findings

```findings
- claim: One finding per item, stated as a plain fact.
  confidence: high
  sources: [path/or/url-of-the-source]
- claim: A second finding, with its own confidence.
  confidence: medium
  sources: [path/or/url-of-the-source]
```

## Evidence

```pending
The facts behind the findings: numbers, quotes under 25 words, dates. Each with its source.
```

## Open questions

```pending
What is still unknown, and what would settle it.
```

## Next steps

```pending
Who does what next. One line each.
```
