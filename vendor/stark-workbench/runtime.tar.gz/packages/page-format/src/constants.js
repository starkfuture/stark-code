// @ts-check

/** The eight page types the header accepts. */
export const PAGE_TYPES = Object.freeze([
  'decision', 'report', 'explainer', 'guide', 'plan', 'spec', 'data', 'mock',
]);

/**
 * Required level-2 sections per type, in order. Types not listed have none yet.
 * @type {Readonly<Record<string, readonly string[]>>}
 */
export const REQUIRED_SECTIONS = Object.freeze({
  decision: Object.freeze(['Context', 'Options', 'Decision', 'Why', 'Consequences']),
  report: Object.freeze(['Bottom line', 'Findings', 'Evidence', 'Open questions', 'Next steps']),
});

/**
 * The typed block that must appear inside a given section, per type.
 * @type {Readonly<Record<string, { section: string, block: string }>>}
 */
export const REQUIRED_BLOCKS = Object.freeze({
  decision: Object.freeze({ section: 'Options', block: 'options' }),
  report: Object.freeze({ section: 'Findings', block: 'findings' }),
});

/** Fence labels with a meaning. `options` and `findings` hold YAML. */
export const TYPED_BLOCKS = Object.freeze(['options', 'findings', 'pending', 'mermaid']);

/** Typed blocks whose content is parsed as YAML into `block.data`. */
export const YAML_BLOCKS = Object.freeze(['options', 'findings']);

export const PAGE_STATUSES = Object.freeze(['draft', 'current', 'superseded']);
export const AUTHORS = Object.freeze(['claude', 'codex', 'human']);
export const CONFIDENCE = Object.freeze(['high', 'medium', 'low']);

/** Slug: lowercase letters, digits and hyphens, 3 to 64 characters. */
export const SLUG_PATTERN = '^[a-z0-9-]{3,64}$';
export const SLUG_RE = new RegExp(SLUG_PATTERN);

/** Largest allowed index.md, in bytes (200 KB). */
export const MAX_PAGE_BYTES = 200 * 1024;

/** Report "Bottom line" limits. */
export const BOTTOM_LINE_MAX_SENTENCES = 3;
export const BOTTOM_LINE_MAX_CHARS = 450;

/** A section that lost more than this share of its text since the previous version gets a warning. */
export const SHRINK_THRESHOLD = 0.3;

/** Header fields the author writes. */
export const AUTHOR_FIELDS = Object.freeze([
  'schema', 'type', 'title', 'owner', 'status', 'verified', 'reviewBy', 'sources', 'supersedes',
]);
/** Header fields `spage` fills. */
export const TOOL_FIELDS = Object.freeze(['id', 'created', 'author', 'session', 'supersededBy', 'published']);
export const KNOWN_FIELDS = Object.freeze([...AUTHOR_FIELDS, ...TOOL_FIELDS]);

/** Stable issue codes. */
export const ISSUE_CODES = Object.freeze([
  'header-missing', 'header-yaml', 'header-field', 'header-unknown-field', 'type-unsupported',
  'h1-not-allowed', 'section-missing', 'section-order', 'block-missing', 'block-yaml',
  'block-schema', 'options-chosen', 'pending', 'link-unsafe', 'image-remote', 'image-missing',
  'image-outside-img', 'size', 'bottom-line-long', 'no-sources', 'section-shrank', 'fence-unclosed',
  'placeholder', 'not-text', 'image-type', 'image-alt', 'image-count', 'image-size', 'diagram',
]);

/**
 * Text from the skill's templates (skills/stark-pages/templates/) that must be replaced.
 * A page that still contains one gets a "placeholder" warning (an error with --strict).
 */
export const PLACEHOLDERS = Object.freeze({
  titles: Object.freeze([
    'Which option we take for the thing being decided',
    'What the report answers, in plain words',
    'How the thing works, in plain words',
    'How to do the task',
    'What we will build, and when',
    'What the thing must do',
    'What the numbers show',
    'What the screen is for',
    'Title in plain words',
  ]),
  optionNames: Object.freeze(['First option', 'Second option']),
  claims: Object.freeze([
    'One finding per item, stated as a plain fact.',
    'A second finding, with its own confidence.',
  ]),
});
