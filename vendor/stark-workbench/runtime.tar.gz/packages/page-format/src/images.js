// @ts-check
/**
 * Image rules (CONTRACTS.md 13.1, FORMAT.md 9.2 and 9.3).
 *
 * `sniffImage` recognises an image by its first bytes and reads its size from the
 * file header (PNG IHDR, JPEG SOF, GIF screen descriptor, WebP VP8/VP8L/VP8X).
 * HEIC, TIFF and BMP are recognised only so that `spage image add` can convert them.
 * This file has no dependencies, so `@stark/page-format/images` can be loaded alone.
 */

/** Types a page may use. */
export const ALLOWED_IMAGE_TYPES = Object.freeze(['png', 'jpg', 'webp', 'gif']);
/** Types that are recognised only to be converted. */
export const CONVERTIBLE_IMAGE_TYPES = Object.freeze(['heic', 'tiff', 'bmp']);

/** Limits per page and per image. */
export const IMAGE_LIMITS = Object.freeze({ maxImages: 40, maxBytes: 1_000_000, maxSide: 4096 });

/** Content type for each allowed image type. */
export const IMAGE_CONTENT_TYPES = Object.freeze({
  png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif',
});

/**
 * @typedef {'png' | 'jpg' | 'webp' | 'gif' | 'heic' | 'tiff' | 'bmp'} ImageType
 * @typedef {{ type: ImageType, width: number, height: number }} ImageInfo
 */

/** @param {Uint8Array} b @param {number} i */
const u16be = (b, i) => (b[i] << 8) | b[i + 1];
/** @param {Uint8Array} b @param {number} i */
const u16le = (b, i) => b[i] | (b[i + 1] << 8);
/** @param {Uint8Array} b @param {number} i */
const u24le = (b, i) => b[i] | (b[i + 1] << 8) | (b[i + 2] << 16);
/** @param {Uint8Array} b @param {number} i */
const u32be = (b, i) => ((b[i] << 24) >>> 0) + ((b[i + 1] << 16) | (b[i + 2] << 8) | b[i + 3]);
/** @param {Uint8Array} b @param {number} i */
const u32le = (b, i) => ((b[i + 3] << 24) >>> 0) + ((b[i + 2] << 16) | (b[i + 1] << 8) | b[i]);
/** @param {Uint8Array} b @param {number} i @param {string} s */
const ascii = (b, i, s) => {
  if (i + s.length > b.length) return false;
  for (let k = 0; k < s.length; k++) if (b[i + k] !== s.charCodeAt(k)) return false;
  return true;
};

/** @param {Uint8Array} b @returns {ImageInfo | null} */
function sniffPng(b) {
  if (b.length < 24 || !ascii(b, 12, 'IHDR')) return null;
  return { type: 'png', width: u32be(b, 16), height: u32be(b, 20) };
}

/** SOF markers carry the frame size; C4 (DHT), C8 (JPG) and CC (DAC) do not. */
const JPEG_SOF = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);

/** @param {Uint8Array} b @returns {ImageInfo | null} */
function sniffJpeg(b) {
  let i = 2;
  while (i + 3 < b.length) {
    if (b[i] !== 0xff) return null;
    let marker = b[i + 1];
    // Fill bytes before a marker.
    while (marker === 0xff && i + 2 < b.length) { i++; marker = b[i + 1]; }
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
    if (marker === 0xd9 || marker === 0xda) return null; // end, or image data before any frame header
    if (i + 3 >= b.length) return null;
    const len = u16be(b, i + 2);
    if (len < 2) return null;
    if (JPEG_SOF.has(marker)) {
      if (i + 8 >= b.length) return null;
      return { type: 'jpg', width: u16be(b, i + 7), height: u16be(b, i + 5) };
    }
    i += 2 + len;
  }
  return null;
}

/** @param {Uint8Array} b @returns {ImageInfo | null} */
function sniffWebp(b) {
  if (b.length < 30) return null;
  if (ascii(b, 12, 'VP8 ')) {
    if (b[23] !== 0x9d || b[24] !== 0x01 || b[25] !== 0x2a) return null;
    return { type: 'webp', width: u16le(b, 26) & 0x3fff, height: u16le(b, 28) & 0x3fff };
  }
  if (ascii(b, 12, 'VP8L')) {
    if (b[20] !== 0x2f) return null;
    const bits = u32le(b, 21);
    return { type: 'webp', width: (bits & 0x3fff) + 1, height: ((bits >>> 14) & 0x3fff) + 1 };
  }
  if (ascii(b, 12, 'VP8X')) {
    return { type: 'webp', width: u24le(b, 24) + 1, height: u24le(b, 27) + 1 };
  }
  return null;
}

/** @param {Uint8Array} b @returns {ImageInfo | null} */
function sniffTiff(b) {
  const le = b[0] === 0x49;
  const r16 = (/** @type {number} */ i) => (le ? u16le(b, i) : u16be(b, i));
  const r32 = (/** @type {number} */ i) => (le ? u32le(b, i) : u32be(b, i));
  let width = 0;
  let height = 0;
  const ifd = r32(4);
  if (ifd + 2 <= b.length) {
    const n = r16(ifd);
    for (let k = 0; k < n && k < 512; k++) {
      const e = ifd + 2 + k * 12;
      if (e + 12 > b.length) break;
      const tag = r16(e);
      const kind = r16(e + 2);
      const value = kind === 3 ? r16(e + 8) : r32(e + 8);
      if (tag === 256) width = value;
      if (tag === 257) height = value;
    }
  }
  return { type: 'tiff', width, height };
}

/** HEIC: an ISO BMFF file whose brand is a HEIF one. */
const HEIC_BRANDS = new Set(['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1']);

/**
 * Orientation as EXIF numbers it (1 = as stored), each as the 2 x 2 matrix [a, b, c, d]
 * that maps a stored pixel (u, v), measured from the centre with v pointing down, to
 * where it shows: (a u + b v, c u + d v).
 */
const ORIENTATION_MATRIX = /** @type {const} */ ([
  null, [1, 0, 0, 1], [-1, 0, 0, 1], [-1, 0, 0, -1], [1, 0, 0, -1],
  [0, 1, 1, 0], [0, -1, 1, 0], [0, -1, -1, 0], [0, 1, -1, 0],
]);

/** @param {readonly number[]} m @returns {number} the EXIF orientation for a matrix */
function orientationOf(m) {
  for (let o = 1; o <= 8; o++) if (ORIENTATION_MATRIX[o]?.every((x, k) => x === m[k])) return o;
  return 1;
}

/** Apply `first`, then `then`. @param {readonly number[]} first @param {readonly number[]} then */
function compose(first, then) {
  const [a, b, c, d] = then;
  const [e, f, g, h] = first;
  return [a * e + b * g, a * f + b * h, c * e + d * g, c * f + d * h];
}

/** A HEIF `irot` turns anticlockwise by angle x 90 degrees; one quarter turn anticlockwise is EXIF 8. */
const IROT = [ORIENTATION_MATRIX[1], ORIENTATION_MATRIX[8], ORIENTATION_MATRIX[3], ORIENTATION_MATRIX[6]];
/**
 * A HEIF `imir` with axis 0 swaps top and bottom (EXIF 4); axis 1 swaps left and right
 * (EXIF 2). This is what macOS ImageIO writes and reads back (checked with sips for all
 * eight orientations) and what libheif does.
 */
const IMIR = [ORIENTATION_MATRIX[4], ORIENTATION_MATRIX[2]];

/**
 * Walk ISO BMFF boxes in b[start, end). Returns the boxes, or null when the layout is broken
 * (a box that runs past its parent, a size too small to hold its own header, too many boxes).
 * @param {Uint8Array} b @param {number} start @param {number} end
 * @returns {Array<{ type: string, body: number, end: number }> | null}
 */
function bmffBoxes(b, start, end) {
  /** @type {Array<{ type: string, body: number, end: number }>} */
  const out = [];
  let i = start;
  while (i < end) {
    if (i + 8 > end || out.length >= 4096) return null;
    let size = u32be(b, i);
    let head = 8;
    if (size === 1) {
      if (i + 16 > end || u32be(b, i + 8) !== 0) return null;
      size = u32be(b, i + 12);
      head = 16;
    } else if (size === 0) {
      size = end - i;
    }
    if (size < head || i + size > end) return null;
    out.push({ type: String.fromCharCode(b[i + 4], b[i + 5], b[i + 6], b[i + 7]), body: i + head, end: i + size });
    i += size;
  }
  return out;
}

/**
 * Read a HEIF file's primary image: its stored size (the `ispe` property the primary item
 * is associated with, found through `pitm` and `ipma`) and its orientation (the `irot` and
 * `imir` properties, in association order). A tile's or thumbnail's `ispe` is never used.
 * Anything that cannot be read reliably gives size 0 x 0 (unknown) and orientation 1.
 * @param {Uint8Array} b
 * @returns {{ width: number, height: number, orientation: number }}
 */
export function readHeif(b) {
  const unknown = { width: 0, height: 0, orientation: 1 };
  // Top-level boxes until `meta`; a truncated `mdat` after it does not matter.
  let i = 0;
  /** @type {{ body: number, end: number } | null} */
  let meta = null;
  for (let n = 0; i + 8 <= b.length && n < 64; n++) {
    let size = u32be(b, i);
    let head = 8;
    if (size === 1) {
      if (i + 16 > b.length || u32be(b, i + 8) !== 0) return unknown;
      size = u32be(b, i + 12);
      head = 16;
    } else if (size === 0) {
      size = b.length - i;
    }
    if (size < head) return unknown;
    if (ascii(b, i + 4, 'meta')) {
      if (i + size > b.length) return unknown;
      meta = { body: i + head + 4, end: i + size }; // meta is a full box
      break;
    }
    i += size;
  }
  if (!meta) return unknown;
  const children = bmffBoxes(b, meta.body, meta.end);
  if (!children) return unknown;
  const pitms = children.filter((c) => c.type === 'pitm');
  const iprps = children.filter((c) => c.type === 'iprp');
  if (pitms.length !== 1 || iprps.length !== 1) return unknown;
  const pitm = pitms[0];
  if (pitm.end - pitm.body < 6) return unknown;
  const primary = b[pitm.body] === 0 ? u16be(b, pitm.body + 4) : (pitm.end - pitm.body >= 8 ? u32be(b, pitm.body + 4) : -1);
  if (primary < 0) return unknown;
  const inner = bmffBoxes(b, iprps[0].body, iprps[0].end);
  if (!inner) return unknown;
  const ipcos = inner.filter((c) => c.type === 'ipco');
  if (ipcos.length !== 1) return unknown;
  const props = bmffBoxes(b, ipcos[0].body, ipcos[0].end);
  if (!props) return unknown;
  /** @type {number[] | null} property indexes (1-based) of the primary item */
  let assoc = null;
  for (const ipma of inner.filter((c) => c.type === 'ipma')) {
    if (ipma.end - ipma.body < 8) return unknown;
    const version = b[ipma.body];
    const wide = (b[ipma.body + 3] & 1) === 1;
    const count = u32be(b, ipma.body + 4);
    let p = ipma.body + 8;
    for (let e = 0; e < count; e++) {
      const idSize = version < 1 ? 2 : 4;
      if (p + idSize + 1 > ipma.end) return unknown;
      const id = idSize === 2 ? u16be(b, p) : u32be(b, p);
      const n = b[p + idSize];
      p += idSize + 1;
      if (p + n * (wide ? 2 : 1) > ipma.end) return unknown;
      /** @type {number[]} */
      const list = [];
      for (let k = 0; k < n; k++) {
        list.push(wide ? u16be(b, p) & 0x7fff : b[p] & 0x7f);
        p += wide ? 2 : 1;
      }
      if (id === primary) {
        if (assoc) return unknown; // listed twice: do not guess
        assoc = list;
      }
    }
  }
  if (!assoc) return unknown;
  let width = 0;
  let height = 0;
  let sizes = 0;
  /** @type {readonly number[]} */
  let m = ORIENTATION_MATRIX[1];
  for (const index of assoc) {
    if (index === 0) continue;
    const prop = props[index - 1];
    if (!prop) return unknown;
    if (prop.type === 'ispe') {
      if (prop.end - prop.body < 12) return unknown;
      width = u32be(b, prop.body + 4);
      height = u32be(b, prop.body + 8);
      sizes++;
    } else if (prop.type === 'irot' && prop.end > prop.body) {
      m = compose(m, IROT[b[prop.body] & 3]);
    } else if (prop.type === 'imir' && prop.end > prop.body) {
      m = compose(m, IMIR[b[prop.body] & 1]);
    }
  }
  if (sizes !== 1) return { width: 0, height: 0, orientation: orientationOf(m) };
  return { width, height, orientation: orientationOf(m) };
}

/** @param {Uint8Array} b @returns {ImageInfo | null} */
function sniffHeic(b) {
  if (b.length < 16 || !ascii(b, 4, 'ftyp')) return null;
  const brand = String.fromCharCode(b[8], b[9], b[10], b[11]);
  if (!HEIC_BRANDS.has(brand)) return null;
  const { width, height } = readHeif(b);
  return { type: 'heic', width, height };
}

/**
 * The Orientation tag (274) of a TIFF block (as EXIF stores it), or 1.
 * @param {Uint8Array} b @param {number} start @param {number} end
 */
function tiffOrientation(b, start, end) {
  if (end - start < 8) return 1;
  const le = b[start] === 0x49 && b[start + 1] === 0x49;
  if (!le && !(b[start] === 0x4d && b[start + 1] === 0x4d)) return 1;
  const r16 = (/** @type {number} */ i) => (le ? u16le(b, i) : u16be(b, i));
  const r32 = (/** @type {number} */ i) => (le ? u32le(b, i) : u32be(b, i));
  if (r16(start + 2) !== 42) return 1;
  const ifd = start + r32(start + 4);
  if (ifd + 2 > end) return 1;
  const n = r16(ifd);
  for (let k = 0; k < n && k < 1024; k++) {
    const e = ifd + 2 + k * 12;
    if (e + 12 > end) return 1;
    if (r16(e) === 0x0112) {
      const kind = r16(e + 2);
      const value = kind === 3 ? r16(e + 8) : kind === 4 ? r32(e + 8) : 0;
      return value >= 1 && value <= 8 ? value : 1;
    }
  }
  return 1;
}

/** @param {Uint8Array} b @param {number} start @param {number} end EXIF data that may start with "Exif\0\0" */
function exifOrientation(b, start, end) {
  if (ascii(b, start, 'Exif\0\0')) start += 6;
  return tiffOrientation(b, start, end);
}

/**
 * How a picture is meant to be turned for display, as an EXIF orientation number:
 * 1 is as stored, 3 upside down, 6 and 8 a quarter turn (width and height swap),
 * 2, 4, 5 and 7 mirrored. Read from the JPEG EXIF segment, the PNG `eXIf` chunk, the WebP
 * `EXIF` chunk, a TIFF's first IFD, or a HEIC primary item's `irot` and `imir`.
 * Returns 1 for GIF, BMP, anything without the tag, and anything it cannot read.
 * @param {Uint8Array | null | undefined} bytes
 * @returns {number}
 */
export function readOrientation(bytes) {
  const info = sniffImage(bytes);
  if (!info || !bytes) return 1;
  const b = bytes;
  if (info.type === 'jpg') {
    let i = 2;
    while (i + 4 <= b.length && b[i] === 0xff) {
      const marker = b[i + 1];
      if (marker === 0xd8 || marker === 0xff || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += marker === 0xff ? 1 : 2; continue; }
      if (marker === 0xda || marker === 0xd9) return 1;
      const len = u16be(b, i + 2);
      if (len < 2 || i + 2 + len > b.length) return 1;
      if (marker === 0xe1 && ascii(b, i + 4, 'Exif\0')) return exifOrientation(b, i + 4, i + 2 + len);
      i += 2 + len;
    }
    return 1;
  }
  if (info.type === 'png') {
    let i = 8;
    while (i + 12 <= b.length) {
      const len = u32be(b, i);
      if (i + 12 + len > b.length) return 1;
      if (ascii(b, i + 4, 'eXIf')) return exifOrientation(b, i + 8, i + 8 + len);
      if (ascii(b, i + 4, 'IEND')) return 1;
      i += 12 + len;
    }
    return 1;
  }
  if (info.type === 'webp') {
    const end = Math.min(b.length, 8 + u32le(b, 4));
    let i = 12;
    while (i + 8 <= end) {
      const len = u32le(b, i + 4);
      if (i + 8 + len > end) return 1;
      if (ascii(b, i, 'EXIF')) return exifOrientation(b, i + 8, i + 8 + len);
      i += 8 + len + (len % 2);
    }
    return 1;
  }
  if (info.type === 'tiff') return tiffOrientation(b, 0, b.length);
  if (info.type === 'heic') return readHeif(b).orientation;
  return 1;
}

/** Orientations that swap width and height when applied. */
export const SWAPS_SIDES = Object.freeze(new Set([5, 6, 7, 8]));

/**
 * Recognise an image by its first bytes and read its size from the header.
 * Returns null for anything else, including SVG and broken headers.
 * @param {Uint8Array | null | undefined} bytes
 * @returns {ImageInfo | null}
 */
export function sniffImage(bytes) {
  if (!bytes || typeof bytes.length !== 'number' || bytes.length < 12) return null;
  const b = bytes;
  if (b[0] === 0x89 && ascii(b, 1, 'PNG\r\n\u001a\n')) return sniffPng(b);
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return sniffJpeg(b);
  if (ascii(b, 0, 'GIF87a') || ascii(b, 0, 'GIF89a')) return { type: 'gif', width: u16le(b, 6), height: u16le(b, 8) };
  if (ascii(b, 0, 'RIFF') && ascii(b, 8, 'WEBP')) return sniffWebp(b);
  if ((ascii(b, 0, 'II') && b[2] === 42 && b[3] === 0) || (ascii(b, 0, 'MM') && b[2] === 0 && b[3] === 42)) return sniffTiff(b);
  if (ascii(b, 0, 'BM') && b.length >= 26) {
    const h = u32le(b, 22) | 0;
    return { type: 'bmp', width: u32le(b, 18) | 0, height: Math.abs(h) };
  }
  return sniffHeic(b);
}

/**
 * A short name for what a file looks like, for messages: "an SVG file", "a HEIC photo"...
 * @param {Uint8Array} bytes
 */
export function describeImageBytes(bytes) {
  const info = sniffImage(bytes);
  if (info) {
    return { heic: 'a HEIC photo', tiff: 'a TIFF image', bmp: 'a BMP image' }[/** @type {string} */ (info.type)] ?? `a ${info.type.toUpperCase()} image`;
  }
  const head = new TextDecoder('utf-8', { fatal: false }).decode(bytes.subarray(0, 512)).replace(/^﻿/, '').trimStart();
  if (/^(<\?xml[^>]*>\s*)?(<!--[\s\S]*?-->\s*)*(<!DOCTYPE svg[^>]*>\s*)?<svg[\s>]/i.test(head)) return 'an SVG file';
  if (/^<\?xml/i.test(head) && /<svg[\s>]/i.test(head)) return 'an SVG file';
  return 'not an image this page can use';
}

/**
 * @typedef {{ kind: 'link' | 'image', url: string, line: number, alt?: string }} ImageRef
 * @typedef {{ code: string, severity: 'error' | 'warning', line: number | null, field: string | null,
 *   message: string, expected?: string, found?: string, hint?: string }} Issue
 * @typedef {{
 *   existsSync?: (p: string) => boolean,
 *   statSync?: (p: string) => unknown,
 *   readFileSync?: (p: string) => Uint8Array | string,
 * }} ImageFs
 * @typedef {{ kind: 'remote' | 'outside' | 'ok', file?: string }} ImageTarget
 */

/** @param {string} s */
function shorten(s) {
  return s.length > 60 ? `${s.slice(0, 57)}...` : s;
}

/**
 * Read what the checker needs from one image file: its size, and its type and size in
 * pixels when it is small enough to read. Returns null when the file cannot be read.
 * @param {ImageFs} fs @param {string} full
 * @returns {{ bytes: number, info: ImageInfo | null, looks: string } | null}
 */
function inspectFile(fs, full) {
  if (typeof fs.readFileSync !== 'function') return null;
  let size = -1;
  try {
    const st = /** @type {{ size?: number, isFile?: () => boolean } | undefined} */ (typeof fs.statSync === 'function' ? fs.statSync(full) : undefined);
    if (st && typeof st.isFile === 'function' && !st.isFile()) return null;
    if (st && typeof st.size === 'number') size = st.size;
  } catch {
    return null;
  }
  // Never read a big file just to say it is too big.
  if (size > IMAGE_LIMITS.maxBytes) return { bytes: size, info: null, looks: 'too big to read' };
  try {
    const raw = fs.readFileSync(full);
    const bytes = typeof raw === 'string' ? new TextEncoder().encode(raw) : raw;
    return { bytes: size >= 0 ? size : bytes.length, info: sniffImage(bytes), looks: describeImageBytes(bytes) };
  } catch {
    return null;
  }
}

/**
 * Check the images a page uses: alt text, how many, and (when the page path is known)
 * each file's type and size. Remote, outside and missing images are reported elsewhere.
 * @param {ImageRef[]} refs image refs in page order
 * @param {{ path: string | null, fs: ImageFs, target: (src: string) => ImageTarget, join: (dir: string, file: string) => string, issue: (code: string, severity: 'error' | 'warning', line: number | null, field: string | null, message: string, extra?: { expected?: string, found?: string, hint?: string }) => Issue }} o
 * @param {Issue[]} out
 */
export function checkImages(refs, o, out) {
  const images = refs.filter((r) => r.kind === 'image');
  images.forEach((ref) => {
    if (typeof ref.alt === 'string' && ref.alt.trim() === '') {
      out.push(o.issue('image-alt', 'error', ref.line, null,
        `Image "${shorten(ref.url)}" has no alt text.`, {
          expected: 'a short description in the brackets', found: 'nothing',
          hint: 'Describe what the image shows, like ![Checkout page with the new button](img/checkout.png).',
        }));
    }
  });
  if (images.length > IMAGE_LIMITS.maxImages) {
    const extra = images[IMAGE_LIMITS.maxImages];
    out.push(o.issue('image-count', 'error', extra.line, null,
      `The page uses ${images.length} images. The limit is ${IMAGE_LIMITS.maxImages}.`, {
        expected: `at most ${IMAGE_LIMITS.maxImages} images`, found: String(images.length),
        hint: 'Keep the images that carry the point, or split the page in two.',
      }));
  }
  if (!o.path) return;
  /** @type {Map<string, ReturnType<typeof inspectFile>>} */
  const seen = new Map();
  for (const ref of images) {
    const t = o.target(ref.url);
    if (t.kind !== 'ok' || !t.file) continue;
    const full = o.join(o.path, t.file);
    if (!seen.has(full)) {
      let exists = true;
      try { exists = typeof o.fs.existsSync === 'function' ? o.fs.existsSync(full) : true; } catch { exists = false; }
      seen.set(full, exists ? inspectFile(o.fs, full) : null);
    }
    const found = seen.get(full);
    if (!found) continue;
    if (found.bytes > IMAGE_LIMITS.maxBytes) {
      out.push(o.issue('image-size', 'error', ref.line, null,
        `Image "${t.file}" is ${(found.bytes / 1_000_000).toFixed(1)} MB. The limit is 1 MB.`, {
          expected: 'at most 1 MB', found: `${(found.bytes / 1_000_000).toFixed(1)} MB`,
          hint: `Shrink it with: spage image add <page> ${t.file} (it resizes and recompresses).`,
        }));
      continue;
    }
    if (!found.info || !ALLOWED_IMAGE_TYPES.includes(found.info.type)) {
      const svg = found.looks === 'an SVG file';
      out.push(o.issue('image-type', 'error', ref.line, null,
        svg ? `Image "${t.file}" is an SVG file. SVG is not allowed in img/.`
          : `Image "${t.file}" is ${found.looks}. Images must be PNG, JPEG, WebP or GIF.`, {
          expected: 'a PNG, JPEG, WebP or GIF file', found: found.looks,
          hint: svg
            ? 'Export it as PNG, or draw the diagram in a ```mermaid block.'
            : `Convert it with: spage image add <page> ${t.file}`,
        }));
      continue;
    }
    const { width, height } = found.info;
    if (width > IMAGE_LIMITS.maxSide || height > IMAGE_LIMITS.maxSide) {
      out.push(o.issue('image-size', 'error', ref.line, null,
        `Image "${t.file}" is ${width} x ${height} pixels. The limit is ${IMAGE_LIMITS.maxSide} pixels per side.`, {
          expected: `at most ${IMAGE_LIMITS.maxSide} x ${IMAGE_LIMITS.maxSide} pixels`, found: `${width} x ${height}`,
          hint: `Shrink it with: spage image add <page> ${t.file}`,
        }));
    }
  }
}
