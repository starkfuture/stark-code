// @ts-check

/**
 * @typedef {{ kind: 'link' | 'image', url: string, line: number, alt?: string }} Ref
 */

/**
 * Blank out inline code spans so links inside them are ignored (keeps columns).
 * A linear scan: a run of N backticks opens a span that the next run of exactly
 * N backticks closes (a regex here took seconds on long lines of mixed backticks).
 * @param {string} line
 */
export function stripCodeSpans(line) {
  if (!line.includes('`')) return line;
  /** Next run of backticks at or after `from`: { start, len } or null. */
  const nextRun = (/** @type {number} */ from) => {
    const start = line.indexOf('`', from);
    if (start === -1) return null;
    let end = start;
    while (line[end] === '`') end++;
    return { start, len: end - start };
  };
  // Where each run length was last found to have no closer: no need to search again.
  /** @type {Map<number, number>} */
  const noCloserAfter = new Map();
  let out = '';
  let pos = 0;
  let run = nextRun(0);
  while (run) {
    const opener = run;
    const searchFrom = opener.start + opener.len;
    let closer = null;
    if (!(noCloserAfter.has(opener.len) && /** @type {number} */ (noCloserAfter.get(opener.len)) <= searchFrom)) {
      for (let r = nextRun(searchFrom); r; r = nextRun(r.start + r.len)) {
        if (r.len === opener.len) { closer = r; break; }
      }
      if (!closer) noCloserAfter.set(opener.len, searchFrom);
    }
    if (!closer) { run = nextRun(searchFrom); continue; }
    const end = closer.start + closer.len;
    out += line.slice(pos, opener.start) + ' '.repeat(end - opener.start);
    pos = end;
    run = nextRun(end);
  }
  return out + line.slice(pos);
}

/**
 * Read a link destination starting at `i` (just after "(").
 * @param {string} s
 * @param {number} i
 * @returns {{ dest: string, end: number } | null}
 */
function readDestination(s, i) {
  while (s[i] === ' ' || s[i] === '\t') i++;
  if (s[i] === '<') {
    const end = s.indexOf('>', i + 1);
    return end === -1 ? null : { dest: s.slice(i + 1, end), end };
  }
  let depth = 0;
  let j = i;
  for (; j < s.length; j++) {
    const c = s[j];
    if (c === '\\') { j++; continue; }
    if (c === ' ' || c === '\t') break;
    if (c === '(') depth++;
    else if (c === ')') { if (depth === 0) break; depth--; }
  }
  return { dest: s.slice(i, j), end: j };
}

/**
 * For every unescaped "]" in a line, the index of its matching "[" (or -1). One pass.
 * @param {string} s
 * @returns {Map<number, number>}
 */
function bracketPairs(s) {
  /** @type {Map<number, number>} */
  const pairs = new Map();
  /** @type {number[]} */
  const stack = [];
  for (let k = 0; k < s.length; k++) {
    const c = s[k];
    if (c === '\\') { k++; continue; }
    if (c === '[') stack.push(k);
    else if (c === ']') pairs.set(k, stack.length ? /** @type {number} */ (stack.pop()) : -1);
  }
  return pairs;
}

/** Normalise a reference label like CommonMark does (case-insensitive, collapsed spaces). */
function refLabel(/** @type {string} */ s) {
  return s.trim().replace(/\s+/g, ' ').toLowerCase();
}

/**
 * Collect links and images from prose lines.
 * @param {string[]} lines all lines of the file
 * @param {string[]} kinds line kinds from classifyLines
 * @returns {Ref[]}
 */
export function collectRefs(lines, kinds) {
  /** @type {Ref[]} */
  const refs = [];
  /** @type {Map<string, { url: string, line: number }>} */
  const defs = new Map();
  /** @type {{ label: string, line: number, alt: string }[]} */
  const imageRefUses = [];

  for (let i = 0; i < lines.length; i++) {
    if (kinds[i] !== 'text') continue;
    const ln = i + 1;
    const line = stripCodeSpans(lines[i]);
    /** @type {Map<number, number> | null} */
    let pairs = null;

    const def = /^ {0,3}\[([^\]]+)\]:[ \t]*(<[^>]*>|\S+)/.exec(line);
    if (def) {
      const url = def[2].startsWith('<') ? def[2].slice(1, -1) : def[2];
      defs.set(refLabel(def[1]), { url, line: ln });
      refs.push({ kind: 'link', url, line: ln });
      continue;
    }

    // Inline links and images: every "](".
    for (let k = line.indexOf(']('); k !== -1; k = line.indexOf('](', k + 1)) {
      if (line[k - 1] === '\\') continue;
      let d = readDestination(line, k + 2);
      if (d !== null && d.dest === '' && line.slice(k + 2).trim() === '' && kinds[i + 1] === 'text' && i + 1 < lines.length) {
        // The address may start on the next line: "[text](" then "javascript:...)".
        const next = readDestination(stripCodeSpans(lines[i + 1]), 0);
        if (next && next.dest) d = { dest: next.dest, end: d.end };
      }
      if (d === null) continue;
      pairs ??= bracketPairs(line);
      const open = pairs.get(k) ?? -1;
      const isImage = open > 0 && line[open - 1] === '!' && line[open - 2] !== '\\';
      refs.push(isImage
        ? { kind: 'image', url: d.dest, line: ln, alt: lines[i].slice(open + 1, k) }
        : { kind: 'link', url: d.dest, line: ln });
      k = Math.max(k, d.end - 1);
    }

    // Reference-style images: ![alt][label], ![label][], ![label]
    const imgRef = /!\[([^\]]*)\](?:\[([^\]]*)\])?(?!\()/g;
    for (let m = imgRef.exec(line); m; m = imgRef.exec(line)) {
      const label = m[2] ? m[2] : m[1];
      imageRefUses.push({ label: refLabel(label), line: ln, alt: m[1] });
    }

    // Autolinks: <scheme:...>
    const auto = /<([a-z][a-z0-9+.-]{1,31}:[^\s<>]*)>/gi;
    for (let m = auto.exec(line); m; m = auto.exec(line)) refs.push({ kind: 'link', url: m[1], line: ln });
  }

  for (const use of imageRefUses) {
    const d = defs.get(use.label);
    if (d) refs.push({ kind: 'image', url: d.url, line: use.line, alt: use.alt });
  }
  return refs;
}

/** Decode the HTML entities a browser would decode before reading a scheme. */
function decodeEntities(/** @type {string} */ s) {
  return s
    .replace(/&#x([0-9a-f]+);?/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);?/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&colon;/gi, ':')
    .replace(/&tab;/gi, '\t')
    .replace(/&newline;/gi, '\n');
}

/**
 * The URL scheme in lowercase ("https", "javascript"...), "//" for protocol-relative, or null.
 * Ignores whitespace and control characters a browser would skip.
 * @param {string} url
 */
export function urlScheme(url) {
  const s = decodeEntities(url).replace(/[\u0000- \u007f]/g, '');
  if (s.startsWith('//')) return '//';
  const m = /^([a-z][a-z0-9+.-]*):/i.exec(s);
  return m ? m[1].toLowerCase() : null;
}

export const SAFE_SCHEMES = new Set(['http', 'https', 'mailto']);
export const DANGEROUS_SCHEMES = new Set(['javascript', 'data', 'file', 'vbscript']);

/**
 * Classify a link: 'ok', 'error' (javascript:, data:, file:, vbscript:) or 'warning' (any other scheme).
 * @param {string} url
 * @returns {'ok' | 'error' | 'warning'}
 */
export function linkSafety(url) {
  const scheme = urlScheme(url);
  if (scheme === null) return 'ok';
  if (SAFE_SCHEMES.has(scheme)) return 'ok';
  if (DANGEROUS_SCHEMES.has(scheme)) return 'error';
  return 'warning';
}

/**
 * Classify an image source.
 * - 'remote': has a scheme (https:, data:...) or starts with //
 * - 'outside': absolute path, not under img/, or climbs out with ..
 * - 'ok': a relative path under img/; `file` is the clean relative path
 * @param {string} src
 * @returns {{ kind: 'remote' | 'outside' | 'ok', file?: string }}
 */
export function imageTarget(src) {
  if (urlScheme(src) !== null) return { kind: 'remote' };
  let p = src.trim().replace(/[?#].*$/, '');
  try { p = decodeURI(p); } catch { /* keep as written */ }
  if (p.startsWith('/') || p.startsWith('\\')) return { kind: 'outside' };
  p = p.replace(/^(\.\/)+/, '');
  const parts = p.split(/[\\/]/);
  // Flat img/ only: the mirror serves files directly in img/, not in subfolders.
  if (parts[0] !== 'img' || parts.length !== 2 || parts.some((x) => x === '..') || parts[parts.length - 1] === '') {
    return { kind: 'outside' };
  }
  return { kind: 'ok', file: parts.join('/') };
}
