// @ts-check
/**
 * The upload itself (CONTRACTS.md 12.1 and 12.2). Only the publish guard's
 * `post-tool-use-pages` hook calls this, right after pages_upload_begin returned a
 * presigned S3 URL. Claude never runs it and never sees the URL: there is no
 * `spage publish put` command any more. The hook checks the bytes against the file list
 * PreToolUse checked (and re-derives them from current.json) before it calls `putBytes`.
 */

/** Hosts a presigned upload URL may point to. */
export const UPLOAD_HOSTS = Object.freeze(['vibecoded-apps.s3.eu-west-1.amazonaws.com']);

/** How long one upload may take. */
export const PUT_TIMEOUT_MS = 60_000;

/**
 * The URL, checked: https on an allowed host, no user info, default port.
 * @param {string} raw
 * @returns {{ ok: true, url: URL } | { ok: false, reason: string }}
 */
export function checkUploadUrl(raw) {
  let url;
  try {
    url = new URL(raw);
  } catch {
    return { ok: false, reason: 'the upload URL from pages_upload_begin is not a valid URL' };
  }
  if (url.protocol !== 'https:') return { ok: false, reason: 'the upload URL does not use https' };
  if (url.username || url.password) return { ok: false, reason: 'the upload URL holds a user name or password' };
  if (url.port && url.port !== '443') return { ok: false, reason: 'the upload URL does not use the default https port' };
  if (!UPLOAD_HOSTS.includes(url.hostname.toLowerCase())) {
    return { ok: false, reason: `the upload URL host ${url.hostname} is not the Stark Pages upload host` };
  }
  return { ok: true, url };
}

/**
 * Remove the URL (and its query string) from a message.
 * @param {string} message @param {string} raw
 */
export function scrub(message, raw) {
  let out = message;
  for (const s of [raw, raw.split('?').slice(1).join('?')]) {
    if (s) out = out.split(s).join('<upload-url>');
  }
  return out.replace(/https:\/\/[^\s"'<>]*amazonaws\.com[^\s"'<>]*/gi, '<upload-url>').replace(/X-Amz-[A-Za-z-]+=[^&\s"']*/g, '<signature>');
}

/**
 * PUT bytes to a checked presigned URL. Never throws; the reason never holds the URL.
 * @param {{ url: string, data: Buffer, contentType: string, fetch: typeof globalThis.fetch, timeoutMs?: number }} o
 * @returns {Promise<{ ok: true } | { ok: false, reason: string }>}
 */
export async function putBytes(o) {
  const checked = checkUploadUrl(o.url);
  if (!checked.ok) return { ok: false, reason: checked.reason };
  let res;
  try {
    res = await o.fetch(checked.url.href, {
      method: 'PUT',
      headers: { 'content-type': o.contentType },
      body: /** @type {any} */ (o.data),
      redirect: 'error',
      signal: AbortSignal.timeout(o.timeoutMs ?? PUT_TIMEOUT_MS),
    });
  } catch (e) {
    const timeout = e instanceof Error && (e.name === 'TimeoutError' || e.name === 'AbortError');
    if (timeout) return { ok: false, reason: `the upload took longer than ${Math.round((o.timeoutMs ?? PUT_TIMEOUT_MS) / 1000)} seconds` };
    const cause = e instanceof Error && e.cause instanceof Error ? ` (${e.cause.message})` : '';
    return { ok: false, reason: scrub(`the network failed: ${e instanceof Error ? e.message : String(e)}${cause}`, o.url) };
  }
  if (!res.ok) {
    let detail = '';
    try {
      const body = (await res.text()).slice(0, 4096);
      const code = /<Code>([^<]{1,100})<\/Code>/.exec(body)?.[1];
      const msg = /<Message>([^<]{1,300})<\/Message>/.exec(body)?.[1];
      detail = [code, msg].filter(Boolean).join(': ');
    } catch {
      // no body
    }
    return { ok: false, reason: scrub(`the upload host answered HTTP ${res.status}${detail ? ` ${detail}` : ''}`, o.url) };
  }
  return { ok: true };
}
