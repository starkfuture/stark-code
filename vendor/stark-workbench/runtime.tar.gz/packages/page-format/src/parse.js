// @ts-check
import { load } from 'js-yaml';
import { YAML_BLOCKS } from './constants.js';

/**
 * @typedef {{ code: string, severity: 'error' | 'warning', line: number | null, field: string | null,
 *   message: string, expected?: string, found?: string, hint?: string }} Issue
 * @typedef {{ lang: string, info: string, content: string, line: number, data?: unknown, parseError?: string }} Block
 * @typedef {{ heading: string, key: string, line: number, body: string, blocks: Block[] }} Section
 * @typedef {{
 *   path: string | null,
 *   text: string,
 *   header: Record<string, unknown> | null,
 *   headerLines: { start: number, end: number } | null,
 *   preamble: string,
 *   sections: Section[],
 *   blocks: Block[],
 *   parseIssues: Issue[],
 * }} PageDoc
 * @typedef {'header' | 'fence' | 'code' | 'text'} LineKind
 */

/**
 * Load YAML; empty text (or only comments) gives null instead of an error.
 * Aliases (*name) are refused: reused anchors can expand a tiny header into gigabytes.
 * @param {string} text
 */
function loadYaml(text) {
  if (text.split(/\r\n|\n|\r/).every((l) => /^\s*(#.*)?$/.test(l))) return null;
  return load(text, { maxAliases: 0 });
}

export const ALIASES_MESSAGE = 'Anchors and aliases (& and *) are not allowed in a page. Write the values out in full.';

/** @param {any} err */
function isAliasError(err) {
  return /^aliases exceeded/.test(String((err && (err.reason || err.message)) || ''));
}

/** Split text into lines the same way everywhere (CRLF, LF or CR). */
export function splitLines(/** @type {string} */ text) {
  return text.split(/\r\n|\n|\r/);
}

/** Normalise a heading for matching: trim, collapse spaces, lowercase. */
export function sectionKey(/** @type {string} */ heading) {
  return String(heading).trim().replace(/\s+/g, ' ').toLowerCase();
}

const FENCE_OPEN = /^(\s*)(`{3,}|~{3,})(.*)$/;
const ATX = /^ {0,3}(#{1,6})(?:[ \t]+(.*?))?(?:[ \t]+#+)?[ \t]*$/;
const SETEXT_H1 = /^ {0,3}=+[ \t]*$/;

/**
 * Detect an opening fence. Backtick fences may not have a backtick in the info string.
 * @param {string} line
 * @returns {{ indent: number, char: string, len: number, info: string } | null}
 */
function openFence(line) {
  const m = FENCE_OPEN.exec(line);
  if (!m) return null;
  const char = m[2][0];
  if (char === '`' && m[3].includes('`')) return null;
  return { indent: m[1].replace(/\t/g, '    ').length, char, len: m[2].length, info: m[3].trim() };
}

/**
 * @param {string} line
 * @param {{ char: string, len: number }} fence
 */
function closesFence(line, fence) {
  const m = /^\s*(`+|~+)\s*$/.exec(line);
  return !!m && m[1][0] === fence.char && m[1].length >= fence.len;
}

/** Remove up to `n` columns of leading spaces (CommonMark fence content rule). */
function dedent(/** @type {string} */ line, /** @type {number} */ n) {
  let i = 0;
  while (i < n && i < line.length && line[i] === ' ') i++;
  return line.slice(i);
}

/**
 * Where the body starts (0-based line index) given the header lines.
 * @param {{ start: number, end: number } | null} headerLines
 */
export function bodyStartIndex(headerLines) {
  return headerLines ? headerLines.end : 0;
}

const LIST_ITEM = /^ {0,3}(?:[-*+]|\d{1,9}[.)])(?:[ \t]|$)/;

/** Leading columns of white space (a tab counts as 4). */
function indentOf(/** @type {string} */ line) {
  let n = 0;
  for (const c of line) {
    if (c === ' ') n += 1;
    else if (c === '\t') n += 4;
    else break;
  }
  return n;
}

/**
 * Classify every line of a page: header, fence (the ``` lines), code (inside a fence
 * or an indented code block) or text. Used by the checker to scan prose for links and images.
 * An indented code block starts with a line indented 4 or more columns after a blank
 * line (or at the start of the body), outside a list.
 * @param {string[]} lines
 * @param {number} bodyStart 0-based index of the first body line
 * @returns {LineKind[]}
 */
export function classifyLines(lines, bodyStart) {
  /** @type {LineKind[]} */
  const kinds = new Array(lines.length).fill('text');
  for (let i = 0; i < Math.min(bodyStart, lines.length); i++) kinds[i] = 'header';
  /** @type {{ char: string, len: number } | null} */
  let fence = null;
  let prevBlank = true;
  let inList = false;
  let inIndented = false;
  for (let i = bodyStart; i < lines.length; i++) {
    const line = lines[i];
    if (fence) {
      if (closesFence(line, fence)) { kinds[i] = 'fence'; fence = null; } else kinds[i] = 'code';
      prevBlank = false;
      continue;
    }
    const blank = line.trim() === '';
    if (inIndented) {
      if (blank) { prevBlank = true; continue; }
      if (indentOf(line) >= 4) { kinds[i] = 'code'; continue; }
      inIndented = false;
    }
    if (!blank && indentOf(line) >= 4 && prevBlank && !inList) {
      kinds[i] = 'code';
      inIndented = true;
      prevBlank = false;
      continue;
    }
    const f = openFence(line);
    if (f) { kinds[i] = 'fence'; fence = f; prevBlank = false; continue; }
    if (!blank) {
      if (LIST_ITEM.test(line)) inList = true;
      else if (indentOf(line) === 0 && prevBlank) inList = false;
    }
    prevBlank = blank;
  }
  return kinds;
}

/**
 * Turn Date objects (js-yaml may produce them) into strings.
 * `created` and `published[].at` keep the full ISO time; every other date becomes YYYY-MM-DD.
 * @param {unknown} value
 * @param {string} key
 * @returns {unknown}
 */
export function normaliseDates(value, key = '') {
  if (value instanceof Date) {
    if (Number.isNaN(value.getTime())) return String(value);
    return key === 'created' || key === 'at' ? value.toISOString() : value.toISOString().slice(0, 10);
  }
  if (Array.isArray(value)) return value.map((v) => normaliseDates(v, key));
  if (value && typeof value === 'object') {
    /** @type {Record<string, unknown>} */
    const out = {};
    // defineProperty, not assignment: a "__proto__" key stays a plain own field
    // (reported as unknown) instead of replacing the object's prototype.
    for (const [k, v] of Object.entries(value)) {
      Object.defineProperty(out, k, { value: normaliseDates(v, k), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

/**
 * Short reason from a js-yaml error, without the code snippet.
 * @param {any} err
 */
function yamlReason(err) {
  const reason = (err && (err.reason || err.message)) || 'unknown problem';
  return String(reason).split('\n')[0].replace(/\s*\(\d+:\d+\)\s*$/, '').trim();
}

/** @param {any} err */
function yamlLine(err) {
  const l = err && err.mark && typeof err.mark.line === 'number' ? err.mark.line : 0;
  return l;
}

/**
 * Parse a page. Never throws: problems go to `parseIssues`.
 * @param {string} text
 * @param {{ path?: string | null }} [opts]
 * @returns {PageDoc}
 */
export function parsePage(text, { path = null } = {}) {
  const src = typeof text === 'string' ? text : text == null ? '' : String(text);
  const lines = splitLines(src);
  /** @type {Issue[]} */
  const parseIssues = [];
  /** @type {Record<string, unknown> | null} */
  let header = null;
  /** @type {{ start: number, end: number } | null} */
  let headerLines = null;
  let bodyStart = 0;

  const first = (lines[0] ?? '').replace(/^﻿/, '').trimEnd();
  if (first === '---') {
    let end = -1;
    for (let i = 1; i < lines.length; i++) {
      const t = lines[i].trimEnd();
      if (t === '---' || t === '...') { end = i; break; }
    }
    if (end === -1) {
      parseIssues.push({
        code: 'header-missing', severity: 'error', line: 1, field: null,
        message: 'The header starts on line 1 but never ends.',
        hint: 'Add a line with only --- after the last header field.',
      });
      bodyStart = lines.length;
    } else {
      headerLines = { start: 1, end: end + 1 };
      bodyStart = end + 1;
      const yamlText = lines.slice(1, end).join('\n');
      try {
        const raw = loadYaml(yamlText);
        if (raw == null) header = {};
        else if (typeof raw === 'object' && !Array.isArray(raw) && !(raw instanceof Date)) {
          header = /** @type {Record<string, unknown>} */ (normaliseDates(raw, ''));
        } else {
          parseIssues.push({
            code: 'header-yaml', severity: 'error', line: 2, field: null,
            message: 'The header must be a list of fields like "title: ...", one per line.',
            hint: 'Write each header field on its own line as "name: value".',
          });
        }
      } catch (err) {
        parseIssues.push(isAliasError(err)
          ? {
            code: 'header-yaml', severity: 'error', line: 2 + yamlLine(err), field: null,
            message: ALIASES_MESSAGE,
            hint: 'Remove every &name and *name from the header and repeat the value where it is needed.',
          }
          : {
            code: 'header-yaml', severity: 'error', line: 2 + yamlLine(err), field: null,
            message: `The header is not valid YAML: ${yamlReason(err)}.`,
            hint: 'Check the indentation, and put quotes around values that contain a colon or start with a special character.',
          });
      }
    }
  } else {
    parseIssues.push({
      code: 'header-missing', severity: 'error', line: 1, field: null,
      message: 'The page has no header. It must start with a line that contains only ---.',
      hint: 'Add a YAML header at the very top: a --- line, fields such as "schema: 1" and "type: decision", then another --- line.',
    });
  }

  /** @type {Section[]} */
  const sections = [];
  /** @type {Block[]} */
  const blocks = [];
  /** @type {string[]} */
  const preambleLines = [];
  /** @type {(Section & { _lines: string[] }) | null} */
  let current = null;
  /** @type {{ indent: number, char: string, len: number, info: string, line: number, content: string[], section: Section | null } | null} */
  let fence = null;
  let prevIsParagraph = false;

  const push = (/** @type {string} */ line) => {
    if (current) current._lines.push(line); else preambleLines.push(line);
  };

  const finishBlock = () => {
    if (!fence) return;
    const info = fence.info;
    const lang = (info.split(/\s+/)[0] || '').toLowerCase();
    /** @type {Block} */
    const block = { lang, info, content: fence.content.join('\n'), line: fence.line };
    if (YAML_BLOCKS.includes(lang)) {
      try {
        const data = loadYaml(block.content);
        block.data = data === undefined ? null : normaliseDates(data, '');
      } catch (err) {
        const aliases = isAliasError(err);
        block.parseError = aliases ? ALIASES_MESSAGE : yamlReason(err);
        parseIssues.push({
          code: 'block-yaml', severity: 'error', line: fence.line + 1 + yamlLine(err), field: lang,
          message: aliases ? `The ${lang} block uses an alias. ${ALIASES_MESSAGE}` : `The ${lang} block is not valid YAML: ${block.parseError}.`,
          hint: aliases ? 'Remove every &name and *name from the block and repeat the value where it is needed.' : lang === 'options'
            ? 'Start each option with "- name:" and indent its other fields by two spaces. Put quotes around text that contains a colon.'
            : 'Start each finding with "- claim:" and indent its other fields by two spaces. Put quotes around text that contains a colon.',
        });
      }
    }
    blocks.push(block);
    if (fence.section) fence.section.blocks.push(block);
  };

  for (let i = bodyStart; i < lines.length; i++) {
    const line = lines[i];
    const ln = i + 1;
    if (fence) {
      if (closesFence(line, fence)) {
        finishBlock();
        fence = null;
      } else {
        fence.content.push(dedent(line, fence.indent));
      }
      push(line);
      continue;
    }
    const f = openFence(line);
    if (f) {
      fence = { ...f, line: ln, content: [], section: current };
      push(line);
      prevIsParagraph = false;
      continue;
    }
    const h = ATX.exec(line);
    if (h) {
      const level = h[1].length;
      const title = (h[2] ?? '').trim();
      if (level === 2) {
        current = { heading: title, key: sectionKey(title), line: ln, body: '', blocks: [], _lines: [] };
        sections.push(current);
        prevIsParagraph = false;
        continue;
      }
      if (level === 1) {
        parseIssues.push({
          code: 'h1-not-allowed', severity: 'error', line: ln, field: null,
          message: `Level-1 heading "# ${title}" is not allowed. The page title comes from the header.`,
          hint: `Use "## ${title}" for a section, or move the text into the header's title field.`,
          found: `# ${title}`,
        });
      }
      push(line);
      prevIsParagraph = false;
      continue;
    }
    if (prevIsParagraph && SETEXT_H1.test(line)) {
      const title = lines[i - 1].trim();
      parseIssues.push({
        code: 'h1-not-allowed', severity: 'error', line: ln - 1, field: null,
        message: `"${title}" underlined with === is a level-1 heading, which is not allowed. The page title comes from the header.`,
        hint: `Use "## ${title}" for a section and remove the === line.`,
        found: title,
      });
      push(line);
      prevIsParagraph = false;
      continue;
    }
    push(line);
    prevIsParagraph = line.trim() !== '';
  }

  if (fence) {
    const open = fence;
    parseIssues.push({
      code: 'fence-unclosed', severity: 'error', line: open.line, field: null,
      message: `The code block that starts here with ${open.char.repeat(open.len)} is never closed.`,
      hint: `Add a line with ${open.char.repeat(open.len)} where the block ends.`,
    });
    finishBlock();
    fence = null;
  }

  return {
    path: path ?? null,
    text: src,
    header,
    headerLines,
    preamble: preambleLines.join('\n'),
    sections: sections.map((s) => {
      const { _lines, ...rest } = /** @type {Section & { _lines: string[] }} */ (s);
      return { ...rest, body: _lines.join('\n') };
    }),
    blocks,
    parseIssues,
  };
}
