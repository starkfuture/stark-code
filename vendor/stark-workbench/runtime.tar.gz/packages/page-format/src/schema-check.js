// @ts-check
import { Validator } from '@cfworker/json-schema';

/**
 * One plain problem found by a JSON Schema check.
 * @typedef {{ path: (string | number)[], kind: 'required' | 'unknown' | 'invalid', prop?: string, keyword: string }} SchemaProblem
 */

const WRAPPERS = new Set([
  'properties', 'items', 'prefixItems', 'allOf', 'anyOf', 'oneOf', '$ref', 'contains',
  'if', 'then', 'else', 'dependentSchemas', 'unevaluatedProperties', 'unevaluatedItems', 'false',
]);

/** @type {WeakMap<object, Validator>} */
const cache = new WeakMap();

/** @param {object} schema */
function validatorFor(schema) {
  let v = cache.get(schema);
  if (!v) {
    // The validator annotates the schema object, so give it a private copy.
    v = new Validator(/** @type {any} */ (structuredClone(schema)), '2020-12', false);
    cache.set(schema, v);
  }
  return v;
}

/** @param {string} loc a JSON pointer like "#/sources/2" */
function pointerPath(loc) {
  const parts = loc.replace(/^#\/?/, '').split('/').filter((p) => p !== '');
  return parts.map((p) => {
    const s = p.replace(/~1/g, '/').replace(/~0/g, '~');
    return /^\d+$/.test(s) ? Number(s) : s;
  });
}

/**
 * Validate `value` against `schema` and return deduplicated, plain problems.
 * @param {object} schema
 * @param {unknown} value
 * @returns {SchemaProblem[]}
 */
export function checkSchema(schema, value) {
  const result = validatorFor(schema).validate(value);
  if (result.valid) return [];
  /** @type {SchemaProblem[]} */
  const out = [];
  const seen = new Set();
  for (const e of result.errors) {
    if (WRAPPERS.has(e.keyword)) continue;
    const path = pointerPath(e.instanceLocation);
    /** @type {SchemaProblem} */
    let p;
    if (e.keyword === 'required') {
      const m = /property "([^"]+)"/.exec(e.error);
      p = { path, kind: 'required', prop: m ? m[1] : '?', keyword: e.keyword };
    } else if (e.keyword === 'additionalProperties') {
      const m = /Property "([^"]+)"/.exec(e.error);
      p = { path, kind: 'unknown', prop: m ? m[1] : '?', keyword: e.keyword };
    } else {
      p = { path, kind: 'invalid', keyword: e.keyword };
    }
    const key = `${p.kind}|${path.join('/')}|${p.prop ?? ''}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(p);
  }
  return out;
}

/**
 * Describe a value briefly for "found" text.
 * @param {unknown} v
 */
export function describeValue(v) {
  if (v === undefined) return 'nothing';
  if (v === null) return 'null';
  if (typeof v === 'string') {
    const s = v.length > 60 ? `${v.slice(0, 57)}...` : v;
    return JSON.stringify(s);
  }
  if (Array.isArray(v)) return v.length === 0 ? 'an empty list' : `a list of ${v.length}`;
  if (typeof v === 'object') return 'a group of fields';
  return String(v);
}

/** Levenshtein distance, for "did you mean" hints. */
export function editDistance(/** @type {string} */ a, /** @type {string} */ b) {
  a = a.toLowerCase(); b = b.toLowerCase();
  const dp = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = dp[j];
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = tmp;
    }
  }
  return dp[b.length];
}

/**
 * The closest known name, if it is close enough to be a typo.
 * @param {string} name
 * @param {readonly string[]} known
 */
export function closest(name, known) {
  let best = null;
  let bestD = Infinity;
  for (const k of known) {
    const d = editDistance(name, k);
    if (d < bestD) { bestD = d; best = k; }
  }
  return best !== null && bestD <= Math.max(1, Math.floor(name.length / 3)) ? best : null;
}
