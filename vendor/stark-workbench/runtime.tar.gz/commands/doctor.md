---
description: Check the Stark Workbench setup
---

Check the Stark Workbench setup.

1. Run: `ELECTRON_RUN_AS_NODE=1 "${STARK_WORKBENCH_NODE:-node}" "${CLAUDE_PLUGIN_ROOT}/packages/spage/bin/spage.js" doctor --root "${CLAUDE_PROJECT_DIR:-$PWD}"`
2. Report the result in plain words. Each line starts with `ok`, `warn` or `fail`. List every `warn` and `fail` line with what to do about it. If all lines are `ok`, say so in one line.
