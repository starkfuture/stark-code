---
schema: 1
type: mock
title: What the screen is for
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Purpose

```pending
Who uses this screen and what they need to get done.
```

## Screens

```pending
One subsection per screen. Put screenshots in img/ and link them as ![Screen name](img/screen.png).
```

## Known gaps

```pending
What the mock leaves out or gets wrong on purpose.
```
