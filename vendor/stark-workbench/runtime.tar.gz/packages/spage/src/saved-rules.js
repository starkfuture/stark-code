// @ts-check
/**
 * Saved "always allow" rules in Claude Code's settings (CONTRACTS.md 12.2, 16.6).
 *
 * The publish guard asks a person for every page file. Claude Code does not document
 * whether a saved allow rule for a tool (what "Yes, and don't ask again" writes) skips a
 * hook "ask". So the guard does not rely on it: when a saved rule covers the Pages tool it
 * would ask about, it denies and says which line to remove. Only rules saved in a
 * settings file can be seen; a rule kept for the session only cannot.
 */
import fs from 'node:fs';
import path from 'node:path';

/** Claude Code's managed settings file on this machine. */
export function defaultManagedSettings() {
  if (process.platform === 'darwin') return '/Library/Application Support/ClaudeCode/managed-settings.json';
  if (process.platform === 'win32') return 'C:\\ProgramData\\ClaudeCode\\managed-settings.json';
  return '/etc/claude-code/managed-settings.json';
}

/**
 * The settings files whose permissions.allow Claude Code applies, highest precedence first.
 * @param {{ home: string, projectDirs: Array<string | undefined>, managedSettings?: string }} o
 * @returns {string[]}
 */
export function settingsFiles(o) {
  const managed = o.managedSettings ?? defaultManagedSettings();
  const files = [managed];
  try {
    const d = `${managed.replace(/\.json$/, '')}.d`;
    for (const f of fs.readdirSync(d).filter((x) => x.endsWith('.json')).sort()) files.push(path.join(d, f));
  } catch {
    // no drop-in folder
  }
  const dirs = [...new Set(o.projectDirs.filter((x) => typeof x === 'string' && x).map((x) => path.resolve(/** @type {string} */ (x))))];
  for (const d of dirs) files.push(path.join(d, '.claude', 'settings.local.json'), path.join(d, '.claude', 'settings.json'));
  files.push(path.join(o.home, '.claude', 'settings.json'));
  return files;
}

/**
 * The folders whose .claude/settings files may apply when the guard or doctor runs in
 * `root`: Claude Code's project folder (when known), then `root` and each folder above it,
 * stopping before `home` (whose .claude/settings.json is the user file). Claude Code reads
 * project settings from the folder it started in, which may be above `root`.
 * @param {string} root @param {string} home @param {string} [projectDir]
 * @returns {string[]}
 */
export function projectDirsFor(root, home, projectDir) {
  const out = [];
  if (typeof projectDir === 'string' && projectDir) out.push(path.resolve(projectDir));
  const stop = path.resolve(home);
  let d = path.resolve(root);
  while (d !== stop && d !== path.dirname(d)) {
    out.push(d);
    d = path.dirname(d);
  }
  return [...new Set(out)];
}

/** @param {string} file @returns {string[]} */
function allowRules(file) {
  try {
    const st = fs.statSync(file);
    if (!st.isFile() || st.size > 1024 * 1024) return [];
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    const list = j?.permissions?.allow;
    return Array.isArray(list) ? list.filter((x) => typeof x === 'string' && x.length <= 500) : [];
  } catch {
    return [];
  }
}

/** A rule without its "(specifier)" part. @param {string} rule */
function bare(rule) {
  return rule.trim().replace(/\(.*\)$/s, '');
}

/** @param {string} pattern */
function globRe(pattern) {
  return new RegExp(`^${pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*')}$`, 'i');
}

/**
 * Does an allow rule cover this tool? `mcp__server` covers every tool of the server;
 * `*` is a wildcard (`mcp__server__*`).
 * @param {string} rule @param {string} toolName
 */
export function allowRuleCovers(rule, toolName) {
  const r = bare(rule);
  if (!r) return false;
  if (globRe(r).test(toolName)) return true;
  return /^mcp__/i.test(r) && !r.slice(5).includes('__') && toolName.toLowerCase().startsWith(`${r.toLowerCase()}__`);
}

/**
 * The first saved allow rule that covers this tool, or null.
 * @param {string} toolName
 * @param {{ home: string, projectDirs: Array<string | undefined>, managedSettings?: string }} o
 * @returns {{ file: string, rule: string } | null}
 */
export function savedAllowFor(toolName, o) {
  for (const file of settingsFiles(o)) {
    for (const rule of allowRules(file)) if (allowRuleCovers(rule, toolName)) return { file, rule };
  }
  return null;
}

/** The Pages tools that ask a person (12.2). */
const PAGES_ASKING = ['pages_upload_begin', 'pages_upload_commit', 'pages_create_project', 'pages_update_project', 'pages_invite_member', 'pages_query_data'];

/**
 * Could this rule cover a Pages tool that asks, on any server? A rule that names a whole
 * server counts only when the server looks like Pages, so `mcp__gmail` does not.
 * @param {string} rule
 */
export function ruleMayCoverPages(rule) {
  const r = bare(rule);
  if (r === '*' || /^mcp__\*$/i.test(r)) return true;
  const m = /^mcp__(.+?)(?:__(.*))?$/is.exec(r);
  if (!m) return false;
  const server = m[1];
  const tool = m[2];
  if (tool === undefined || tool === '*') return /pages|vibecoded|\*/i.test(server);
  const re = globRe(tool);
  return PAGES_ASKING.some((x) => re.test(x));
}

/**
 * Every saved allow rule that may cover a Pages tool that asks (for spage doctor).
 * @param {{ home: string, projectDirs: Array<string | undefined>, managedSettings?: string }} o
 * @returns {Array<{ file: string, rule: string }>}
 */
export function savedPagesRules(o) {
  /** @type {Array<{ file: string, rule: string }>} */
  const out = [];
  for (const file of settingsFiles(o)) for (const rule of allowRules(file)) if (ruleMayCoverPages(rule)) out.push({ file, rule });
  return out;
}

/**
 * The deny reason when a saved rule may skip the question.
 * @param {{ file: string, rule: string }} hit @param {(s: unknown) => string} show
 */
export function savedRuleReason(hit, show) {
  return `Publishing needs a person to say yes, and a saved "always allow" rule may skip that question: ${show(hit.rule)} in ${show(hit.file)}. Remove that rule from the file, then ask again. When Claude Code asks about a publish, answer with a plain yes, never "don't ask again".`;
}
