// @ts-check
import { fileURLToPath } from 'node:url';
/**
 * Loading the checker and the renderer. Commands take these through a context object,
 * so tests inject stubs and never depend on the real packages.
 */

/**
 * @typedef {{
 *   parsePage: (text: string, opts?: { path?: string | null }) => any,
 *   validatePage: (input: any, opts?: { path?: string | null, previousText?: string, strict?: boolean, fs?: any }) => { ok: boolean, errors: any[], warnings: any[], doc: any },
 *   formatIssues: (result: any, opts?: { file?: string }) => string,
 *   PAGE_TYPES?: string[],
 * }} FormatApi
 * @typedef {{
 *   renderPage: (doc: any, opts?: { mode?: 'document' | 'fragment', theme?: 'stark' | 'host', assetBase?: string, validation?: any, view?: 'page' | 'panel', diagrams?: Map<number, any> }) => string,
 *   drawDiagrams?: (doc: any, opts?: { cacheDir?: string }) => Promise<Map<number, any>>,
 * }} RendererApi
 * @typedef {{ format: FormatApi, renderer: RendererApi }} Deps
 */

export class DepsError extends Error {}

/** The folder that holds the plugin (and its node_modules): CLAUDE_PLUGIN_ROOT when set. */
export const PLUGIN_ROOT = fileURLToPath(new URL('../../../', import.meta.url)).replace(/[\\/]$/, '');

/**
 * What to run to fix missing dependencies, naming the real folder.
 * @param {Record<string, string | undefined>} [env]
 */
export function installHint(env = process.env) {
  const dir = env.CLAUDE_PLUGIN_ROOT || PLUGIN_ROOT;
  return `Run this once: cd ${JSON.stringify(dir)} && npm install`;
}

/** @returns {Promise<FormatApi>} */
export async function loadFormat() {
  try {
    return /** @type {any} */ (await import('@stark/page-format'));
  } catch (e) {
    throw new DepsError(`Cannot load the page checker (@stark/page-format): ${e instanceof Error ? e.message : String(e)}. ${installHint()}`);
  }
}

/** @returns {Promise<RendererApi>} */
export async function loadRenderer() {
  try {
    return /** @type {any} */ (await import('@stark/pages-renderer'));
  } catch (e) {
    throw new DepsError(`Cannot load the page renderer (@stark/pages-renderer): ${e instanceof Error ? e.message : String(e)}. ${installHint()}`);
  }
}

/** @returns {Promise<Deps>} */
export async function loadDeps() {
  return { format: await loadFormat(), renderer: await loadRenderer() };
}

/**
 * The mirror's render function, built from the real (or stub) packages.
 * Diagrams (CONTRACTS.md 14.3) are drawn before the synchronous renderPage when the
 * renderer has drawDiagrams. Drawn diagrams are kept in memory by the renderer; pass
 * `diagramCacheDir` (the mirror passes pages/.spage/diagrams) to keep them on disk too.
 * A drawing failure never fails the page: the block then shows as source.
 * `view: 'panel'` (from /p/<slug>?view=panel) is passed through to renderPage.
 * @param {Deps} deps
 * @param {{ diagramCacheDir?: string }} [opts]
 * @returns {import('./mirror.js').RenderFn}
 */
export function makeRender(deps, opts = {}) {
  return async ({ text, file, assetBase, view }) => {
    const doc = deps.format.parsePage(text, { path: file });
    const validation = deps.format.validatePage(doc, { path: file });
    /** @type {Map<number, any> | undefined} */
    let diagrams;
    const draw = /** @type {any} */ (deps.renderer).drawDiagrams;
    const hasDiagram = Array.isArray(doc?.blocks) && doc.blocks.some((/** @type {any} */ b) => b && b.lang === 'mermaid');
    if (typeof draw === 'function' && hasDiagram) {
      try {
        diagrams = await draw(doc, opts.diagramCacheDir ? { cacheDir: opts.diagramCacheDir } : {});
      } catch {
        diagrams = undefined;
      }
    }
    return deps.renderer.renderPage(doc, {
      mode: 'document', theme: 'stark', assetBase, validation,
      ...(view === 'panel' ? { view: 'panel' } : {}),
      ...(diagrams ? { diagrams } : {}),
    });
  };
}
