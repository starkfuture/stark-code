// @ts-check
/**
 * Who may frame the mirror's panel (CONTRACTS.md section 11.2): origin parsing,
 * the frame-ancestors directive, and the one cross-site navigation the mirror allows.
 *
 * An allowed embed origin is either a CSP scheme source (`starkcode:`) or an exact
 * origin (`scheme://host[:port]`). Anything that would let an ordinary website frame
 * the mirror (`http:`, `https:`, `*`, ...) is refused.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

/** The Stark Code app's window origins: starkcode://app (production) and starkcode-dev://app (development). */
export const BUILTIN_EMBED_ORIGINS = Object.freeze(['starkcode:', 'starkcode-dev:']);

/** Env var with extra origins, space separated. */
export const EMBED_ENV = 'SPAGE_EMBED_ORIGINS';

/**
 * Scheme sources that would match pages any website can create or open.
 * `http:`/`https:` are named by the contract; the others are refused for the same reason
 * (a `blob:` or `data:` document made by any site, a local file, a websocket scheme that
 * never frames anything).
 */
export const REFUSED_SCHEMES = Object.freeze(['http:', 'https:', 'ws:', 'wss:', 'blob:', 'data:', 'filesystem:', 'javascript:', 'about:', 'file:']);

const SCHEME_SOURCE_RE = /^[a-z][a-z0-9+.-]*:$/;
const ORIGIN_RE = /^([a-z][a-z0-9+.-]*):\/\/([a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)*|\[[0-9a-f:.]+\])(?::(\d{1,5}))?$/;

/**
 * @typedef {{ ok: true, value: string, kind: 'scheme' | 'origin' } | { ok: false, reason: string }} ParsedOrigin
 */

/**
 * Check one embed origin entry.
 * @param {unknown} raw
 * @returns {ParsedOrigin}
 */
export function parseEmbedOrigin(raw) {
  if (typeof raw !== 'string') return { ok: false, reason: 'not a string' };
  const entry = raw.trim();
  if (!entry) return { ok: false, reason: 'empty' };
  if (entry.length > 200) return { ok: false, reason: 'longer than 200 characters' };
  if (/['"]/.test(entry)) return { ok: false, reason: 'quotes are not allowed' };
  if (/[;,]/.test(entry)) return { ok: false, reason: '";" and "," are not allowed' };
  if (/\s/.test(entry)) return { ok: false, reason: 'spaces are not allowed' };
  if (entry.includes('*')) return { ok: false, reason: 'wildcards are not allowed' };
  const lower = entry.toLowerCase();
  if (SCHEME_SOURCE_RE.test(lower)) {
    if (REFUSED_SCHEMES.includes(lower)) return { ok: false, reason: `"${lower}" would let any website frame the mirror` };
    return { ok: true, value: lower, kind: 'scheme' };
  }
  const m = ORIGIN_RE.exec(lower);
  if (!m) return { ok: false, reason: 'use a scheme like "myapp:" or an exact origin like "myapp://host:1234" (no path)' };
  if (m[3] !== undefined) {
    const port = Number(m[3]);
    if (!Number.isInteger(port) || port < 1 || port > 65535) return { ok: false, reason: 'port must be 1 to 65535' };
  }
  // A web origin may only be a local dev server: a website listed here could frame the
  // panel, read the project folder from "ready" and page titles from "show".
  if ((m[1] === 'http' || m[1] === 'https') && !(m[2] === '127.0.0.1' || m[2] === 'localhost' || m[2] === '[::1]')) {
    return { ok: false, reason: 'http and https origins are allowed only for 127.0.0.1, localhost or [::1]' };
  }
  return { ok: true, value: lower, kind: 'origin' };
}

/**
 * Split an embed-origins file: one entry per line, `#` starts a comment.
 * @param {string} text
 * @returns {string[]}
 */
export function splitOriginsFile(text) {
  return String(text)
    .split(/\r?\n/)
    .map((line) => {
      const i = line.indexOf('#');
      return (i === -1 ? line : line.slice(0, i)).trim();
    })
    .filter(Boolean);
}

/** @param {string} s */
function printable(s) {
  return String(s).replace(/[\u0000-\u001f\u007f-\u009f]/g, '�').slice(0, 80);
}

/**
 * The allowed embed origins: built-ins, then $SPAGE_EMBED_ORIGINS, then ~/.stark/embed-origins.
 * Bad entries are skipped with one log line each. Never throws.
 * @param {{ env?: Record<string, string | undefined>, home?: string, fs?: Pick<typeof fs, 'readFileSync'>, log?: (line: string) => void }} [opts]
 * @returns {string[]}
 */
export function loadEmbedOrigins(opts = {}) {
  const env = opts.env ?? process.env;
  const f = opts.fs ?? fs;
  const log = opts.log ?? (() => {});
  /** @type {Array<{ entry: string, from: string }>} */
  const entries = BUILTIN_EMBED_ORIGINS.map((entry) => ({ entry, from: 'built-in' }));
  const fromEnv = env[EMBED_ENV];
  if (typeof fromEnv === 'string') {
    for (const entry of fromEnv.split(/\s+/).filter(Boolean)) entries.push({ entry, from: EMBED_ENV });
  }
  let home = opts.home;
  if (home === undefined) {
    try { home = os.homedir(); } catch { home = ''; }
  }
  if (home) {
    const file = path.join(home, '.stark', 'embed-origins');
    let text = null;
    try { text = String(f.readFileSync(file, 'utf8')); } catch { /* no file: nothing to add */ }
    if (text !== null) {
      for (const entry of splitOriginsFile(text)) entries.push({ entry, from: '~/.stark/embed-origins' });
    }
  }
  /** @type {string[]} */
  const out = [];
  for (const { entry, from } of entries) {
    const r = parseEmbedOrigin(entry);
    if (!r.ok) {
      log(`Ignored embed origin "${printable(entry)}" from ${from}: ${r.reason}.`);
      continue;
    }
    if (!out.includes(r.value)) out.push(r.value);
  }
  return out;
}

/**
 * Keep only valid entries (for origins handed in directly, for example by tests or the integrator).
 * @param {readonly unknown[]} list
 * @returns {string[]}
 */
export function cleanEmbedOrigins(list) {
  /** @type {string[]} */
  const out = [];
  for (const raw of list) {
    const r = parseEmbedOrigin(raw);
    if (r.ok && !out.includes(r.value)) out.push(r.value);
  }
  return out;
}

/**
 * `frame-ancestors 'self' <origins>`.
 * @param {readonly string[]} origins already checked with parseEmbedOrigin
 */
export function frameAncestors(origins) {
  return ["frame-ancestors 'self'", ...origins].join(' ');
}

/**
 * Replace (or add) the frame-ancestors directive of a CSP string.
 * @param {string} csp
 * @param {readonly string[]} origins
 */
export function withFrameAncestors(csp, origins) {
  const parts = String(csp).split(';').map((s) => s.trim()).filter(Boolean)
    .filter((d) => !/^frame-ancestors(\s|$)/i.test(d));
  parts.push(frameAncestors(origins));
  return parts.join('; ');
}

/** Routes that the app may frame (section 11.2). Every other route keeps frame-ancestors 'self'. */
export const EMBEDDABLE_ROUTE_RE = /^(?:\/panel|\/p\/[^/]+\/?|\/p\/[^/]+\/img\/[^/]+)$/;

/** @param {string} pathname */
export function isEmbeddableRoute(pathname) {
  return EMBEDDABLE_ROUTE_RE.test(pathname);
}

/**
 * The single cross-site request the mirror accepts: the app framing /panel.
 * @param {{ method?: string, headers: Record<string, string | string[] | undefined> }} req
 * @param {string} pathname
 */
export function isPanelNavigation(req, pathname) {
  const h = req.headers;
  const v = (/** @type {string} */ k) => String(h[k] ?? '').toLowerCase();
  return (req.method ?? 'GET').toUpperCase() === 'GET'
    && pathname === '/panel'
    && v('sec-fetch-mode') === 'navigate'
    && v('sec-fetch-dest') === 'iframe';
}
