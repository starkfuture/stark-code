---
schema: 1
type: plan
title: What we will build, and when
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Bottom line

```pending
The plan in at most three sentences: what, by when, at what cost.
```

## Goal

```pending
What done looks like, and how we will know.
```

## Milestones

```pending
One line per milestone: what, who, by when.
```

## Risks

```pending
What could stop the plan, and what we do about it.
```

## Next steps

```pending
The first actions, with owners.
```
