// @ts-check
/**
 * Diagram rules (CONTRACTS.md 14.2, FORMAT.md 6.1).
 *
 * A `mermaid` block may use only `sequenceDiagram` or `flowchart <LR|RL|TB|TD|BT>`, and only
 * the statements FORMAT 6.1 lists. Anything else is an error, even when the drawing tool
 * would accept it. The check is line based and linear in the size of the source.
 */

export const DIAGRAM_LIMITS = Object.freeze({
  maxBytes: 20 * 1024,
  maxBoxes: 40,
  warnBoxes: 30,
  maxParticipants: 8,
  maxArrows: 40,
  maxDepth: 3,
  maxCaption: 200,
});

/**
 * @typedef {{ offset: number, severity: 'error' | 'warning', message: string, hint?: string }} DiagramProblem
 * @typedef {{
 *   kind: 'flowchart' | 'sequence' | null,
 *   caption: string | null,
 *   problems: DiagramProblem[],
 *   counts: { boxes: number, participants: number, arrows: number },
 * }} DiagramCheck
 */

const CAPTION_RE = /^\s*%%\s*caption\s*:\s*(.*?)\s*$/i;

/**
 * The caption from an optional first line `%% caption: <text>`, or null.
 * @param {string} source
 */
export function diagramCaption(source) {
  const first = String(source ?? '').split('\n', 1)[0].replace(/\r$/, '');
  const m = CAPTION_RE.exec(first);
  if (!m || !m[1]) return null;
  return m[1].slice(0, DIAGRAM_LIMITS.maxCaption);
}

const ID = '[A-Za-z][A-Za-z0-9_]*';
const ID_RE = new RegExp(`^${ID}`);

/** Words the drawing tool treats as styling, links or numbering: refused by FORMAT 6.1. */
const REFUSED = /** @type {Record<string, string>} */ ({
  style: 'Styling is not allowed: diagrams take their look from the page.',
  classdef: 'Styling is not allowed: diagrams take their look from the page.',
  class: 'Styling is not allowed: diagrams take their look from the page.',
  linkstyle: 'Styling is not allowed: diagrams take their look from the page.',
  click: 'Diagrams cannot hold links or click actions.',
  link: 'Diagrams cannot hold links.',
  links: 'Diagrams cannot hold links.',
  autonumber: 'Automatic numbering is not allowed.',
});

/** Sequence statements Mermaid knows that the format does not allow. */
const SEQ_OTHER = new Set(['activate', 'deactivate', 'rect', 'box', 'create', 'destroy', 'title', 'acctitle', 'accdescr', 'option', 'properties', 'details']);
/** Flowchart statements Mermaid knows that the format does not allow. */
const FLOW_OTHER = new Set(['direction', 'title', 'acctitle', 'accdescr', 'interpolate']);

/**
 * Why a label is not allowed, or null. Labels are plain text: no HTML, no markdown,
 * no entity codes, no icons.
 * @param {string} text
 * @returns {string | null}
 */
export function labelProblem(text) {
  if (/[<>]/.test(text)) return 'Labels cannot contain HTML or the characters < and >.';
  if (/`|\*\*|__|~~|\]\(/.test(text)) return 'Labels are plain text: no markdown.';
  if (/&#?[A-Za-z0-9]+;|#[A-Za-z0-9]+;/.test(text)) return 'Labels cannot contain entity codes like &amp; or #quot;.';
  if (/(^|[^A-Za-z0-9])fa[bklrsd]?:fa-|(^|[^A-Za-z0-9])(fa|fab|fas|far|fal|fak):/.test(text) || text.includes('@{')) return 'Icons are not allowed in labels.';
  if (text.includes(':::')) return 'Class shortcuts (:::) are not allowed.';
  return null;
}

/** Shapes from FORMAT 6.1, longest opener first. */
const SHAPES = /** @type {Array<[string, string]>} */ ([['([', '])'], ['[(', ')]'], ['((', '))'], ['[', ']'], ['(', ')'], ['{', '}']]);

/**
 * Parse a flowchart box at `s[i]`: an id and an optional label in one of the allowed shapes.
 * @param {string} s @param {number} i
 * @returns {{ id: string, label: string | null, end: number } | { error: string } | null}
 */
function readBox(s, i) {
  const m = ID_RE.exec(s.slice(i, i + 200));
  if (!m) return null;
  const id = m[0];
  let j = i + id.length;
  for (const [open, close] of SHAPES) {
    if (!s.startsWith(open, j)) continue;
    const start = j + open.length;
    let label;
    let end;
    if (s[start] === '"') {
      const q = s.indexOf('"', start + 1);
      if (q === -1 || !s.startsWith(close, q + 1)) return { error: `The label of box "${id}" is not closed with ${close}.` };
      label = s.slice(start + 1, q);
      end = q + 1 + close.length;
    } else {
      const k = s.indexOf(close, start);
      if (k === -1) return { error: `The label of box "${id}" is not closed with ${close}.` };
      label = s.slice(start, k);
      end = k + close.length;
      if (/[[\](){}|"]/.test(label)) return { error: `The label of box "${id}" has brackets or quotes inside. Put the label in double quotes, without brackets.` };
    }
    if (!label.trim()) return { error: `Box "${id}" has an empty label.` };
    return { id, label: label.trim(), end };
  }
  if (/^[[({>]/.test(s.slice(j, j + 1))) return { error: `Box "${id}" uses a shape that is not allowed. Use [..], (..), ([..]), [(..)], {..} or ((..)).` };
  return { id, label: null, end: j };
}

const ARROWS = ['-.->', '-->', '---', '==>'];

/**
 * Check a diagram source against FORMAT 6.1.
 * @param {string} source
 * @param {{ firstLine?: number }} [opts] file line of the source's first line; messages then name file lines
 * @returns {DiagramCheck}
 */
export function checkMermaid(source, opts = {}) {
  const lineName = typeof opts.firstLine === 'number'
    ? (/** @type {number} */ offset) => `Line ${/** @type {number} */ (opts.firstLine) + offset}`
    : (/** @type {number} */ offset) => `Diagram line ${offset + 1}`;
  const text = String(source ?? '');
  /** @type {DiagramCheck} */
  const result = { kind: null, caption: diagramCaption(text), problems: [], counts: { boxes: 0, participants: 0, arrows: 0 } };
  const bytes = new TextEncoder().encode(text).length;
  if (bytes > DIAGRAM_LIMITS.maxBytes) {
    result.problems.push({
      offset: 0, severity: 'error',
      message: `The diagram source is ${Math.ceil(bytes / 1024)} KB. The limit is 20 KB.`,
      hint: 'Split the process into smaller diagrams.',
    });
    return result;
  }
  const lines = text.split('\n').map((l) => l.replace(/\r$/, ''));
  /** @param {number} offset @param {string} message @param {string} [hint] @param {'error' | 'warning'} [severity] */
  const problem = (offset, message, hint, severity = 'error') => {
    result.problems.push({ offset, severity, message: `${lineName(offset)}: ${message}`, ...(hint ? { hint } : {}) });
  };

  /** Statement lines: comments and blanks removed, a trailing ";" dropped. */
  /** @type {Array<{ offset: number, s: string }>} */
  const statements = [];
  lines.forEach((raw, offset) => {
    const s = raw.trim();
    if (!s) return;
    if (s.startsWith('%%')) {
      if (s.startsWith('%%{')) problem(offset, 'Directives like %%{init: ...}%% are not allowed.', 'Remove the line. Diagrams take their look from the page.');
      return;
    }
    statements.push({ offset, s: s.replace(/;\s*$/, '').trim() });
  });

  if (statements.length === 0) {
    problem(0, 'The diagram is empty.', 'Start with "flowchart LR" or "sequenceDiagram" and add boxes or messages.');
    return result;
  }
  const head = statements[0];
  const flow = /^flowchart\s+(LR|RL|TB|TD|BT)$/.exec(head.s);
  if (head.s === 'sequenceDiagram') result.kind = 'sequence';
  else if (flow) result.kind = 'flowchart';
  else {
    const graph = /^graph\b/.test(head.s);
    problem(head.offset,
      graph ? 'Write "flowchart" with a direction instead of "graph".' : 'Only sequenceDiagram and flowchart diagrams are allowed.',
      'Start with "flowchart LR" (or RL, TB, TD, BT) or "sequenceDiagram".');
    return result;
  }
  const body = statements.slice(1);
  if (body.length === 0) {
    problem(head.offset, 'The diagram is empty.', 'Add boxes and arrows, or participants and messages.');
    return result;
  }

  /** One problem per line is enough; stop after 20 so a hostile block cannot flood the report. */
  const flagged = new Set();
  /** @param {number} offset @param {string} message @param {string} [hint] */
  const lineError = (offset, message, hint) => {
    if (flagged.has(offset) || flagged.size >= 20) return;
    flagged.add(offset);
    problem(offset, message, hint);
  };
  /** Refused words and class shortcuts, for both kinds. */
  const refusedWord = (/** @type {{ offset: number, s: string }} */ st) => {
    const word = st.s.split(/[\s:;]/, 1)[0].toLowerCase();
    if (Object.hasOwn(REFUSED, word)) { lineError(st.offset, `"${st.s.split(/\s/, 1)[0]}" is not allowed. ${REFUSED[word]}`); return true; }
    if (st.s.includes(':::')) { lineError(st.offset, 'Class shortcuts (:::) are not allowed. Diagrams take their look from the page.'); return true; }
    return false;
  };

  if (result.kind === 'flowchart') checkFlowchart(body, result, lineError, refusedWord, problem);
  else checkSequence(body, result, lineError, refusedWord, problem);
  return result;
}

/** @param {DiagramCheck} result */
function flaggedNone(result) {
  return !result.problems.some((p) => p.severity === 'error');
}

/**
 * @param {Array<{ offset: number, s: string }>} body
 * @param {DiagramCheck} result
 * @param {(offset: number, message: string, hint?: string) => void} lineError
 * @param {(st: { offset: number, s: string }) => boolean} refusedWord
 * @param {(offset: number, message: string, hint?: string, severity?: 'error' | 'warning') => void} problem
 */
function checkFlowchart(body, result, lineError, refusedWord, problem) {
  /** @type {Map<string, { label: string, offset: number }>} */
  const boxes = new Map();
  /** @type {Set<string>} */
  const groups = new Set();
  /** @type {Set<string>} */
  const arrows = new Set();
  /** @type {number[]} */
  const open = [];
  let arrowCount = 0;
  const hint = 'Allowed: boxes like A[Label], arrows -->, ---, -.->, ==> with an optional |label|, and subgraph ... end.';

  /** @param {string} id @param {string | null} label @param {number} offset */
  const addBox = (id, label, offset) => {
    if (groups.has(id)) { lineError(offset, `"${id}" is already a group name. Use another id for the box.`); return; }
    const prev = boxes.get(id);
    if (!prev) { boxes.set(id, { label: label ?? id, offset }); return; }
    if (label !== null && label !== prev.label && prev.label !== id) {
      lineError(offset, `Box "${id}" already has the label "${prev.label}". Give a box its label once.`);
    } else if (label !== null && prev.label === id) {
      prev.label = label;
    }
  };

  for (const st of body) {
    if (refusedWord(st)) continue;
    const s = st.s;
    const word = s.split(/\s/, 1)[0];
    if (word === 'subgraph') {
      const m = new RegExp(`^subgraph\\s+(${ID})\\s*(?:\\[(.*)\\])?$`).exec(s);
      if (!m) { lineError(st.offset, 'Write a group as "subgraph <id> [<label>]".'); continue; }
      const why = m[2] !== undefined ? labelProblem(m[2]) : null;
      if (why) { lineError(st.offset, why); continue; }
      if (groups.has(m[1]) || boxes.has(m[1])) { lineError(st.offset, `The name "${m[1]}" is already used.`); continue; }
      groups.add(m[1]);
      open.push(st.offset);
      continue;
    }
    if (word === 'end') {
      if (s !== 'end') { lineError(st.offset, '"end" stands alone on its line.'); continue; }
      if (open.length === 0) lineError(st.offset, '"end" closes nothing.', 'Remove it, or open a group with "subgraph <id> [<label>]" above it.');
      else open.pop();
      continue;
    }
    if (FLOW_OTHER.has(word.toLowerCase())) { lineError(st.offset, `"${word}" is not allowed.`, hint); continue; }

    // A box, or a chain of boxes joined by arrows.
    let i = 0;
    let bad = null;
    /** @type {string | null} */
    let prevId = null;
    while (i < s.length) {
      const box = readBox(s, i);
      if (box === null) { bad = 'This is not an allowed flowchart line.'; break; }
      if ('error' in box) { bad = box.error; break; }
      if (box.label !== null) {
        const why = labelProblem(box.label);
        if (why) { bad = why; break; }
      }
      if (['end', 'subgraph', 'graph', 'flowchart'].includes(box.id)) { bad = `"${box.id}" cannot be a box id.`; break; }
      addBox(box.id, box.label, st.offset);
      if (prevId !== null) {
        const key = `${prevId}>${box.id}`;
        if (arrows.has(key)) { bad = `There is already an arrow from "${prevId}" to "${box.id}". Use at most one arrow per direction.`; break; }
        arrows.add(key);
        arrowCount++;
      }
      i = box.end;
      while (s[i] === ' ' || s[i] === '\t') i++;
      if (i >= s.length) break;
      const arrow = ARROWS.find((a) => s.startsWith(a, i));
      if (!arrow) {
        bad = s[i] === '&' ? 'Joining boxes with & is not allowed. Write one arrow per line.' : /^(-{2,}|={2,}|\.)/.test(s.slice(i)) || s.startsWith('<', i) || s.startsWith('o', i) || s.startsWith('x', i)
          ? 'Only the arrows -->, ---, -.-> and ==> are allowed, each with an optional |label|.'
          : 'This is not an allowed flowchart line.';
        break;
      }
      i += arrow.length;
      if (s[i] === '-' || s[i] === '>' || s[i] === '=' || s[i] === '.') { bad = 'Only the arrows -->, ---, -.-> and ==> are allowed, each with an optional |label|.'; break; }
      while (s[i] === ' ' || s[i] === '\t') i++;
      if (s[i] === '|') {
        const close = s.indexOf('|', i + 1);
        if (close === -1) { bad = 'An arrow label is not closed with |.'; break; }
        const label = s.slice(i + 1, close);
        const why = label.trim() ? labelProblem(label) : 'An arrow label is empty.';
        if (why) { bad = why; break; }
        i = close + 1;
        while (s[i] === ' ' || s[i] === '\t') i++;
      }
      if (i >= s.length) { bad = 'An arrow must end at a box.'; break; }
      prevId = box.id;
    }
    if (bad) lineError(st.offset, bad, bad.startsWith('This is not') ? hint : undefined);
  }
  for (const offset of open) lineError(offset, 'This group is never closed with "end".');

  result.counts.boxes = boxes.size;
  result.counts.arrows = arrowCount;
  const first = body[0].offset;
  if (boxes.size === 0 && flaggedNone(result)) problem(first, 'The diagram has no boxes.');
  if (boxes.size > DIAGRAM_LIMITS.maxBoxes) {
    problem(first, `The diagram has ${boxes.size} boxes. The limit is ${DIAGRAM_LIMITS.maxBoxes}.`, 'Split the process into smaller diagrams.');
  } else if (boxes.size > DIAGRAM_LIMITS.warnBoxes) {
    problem(first, `The diagram has ${boxes.size} boxes. Aim for ${DIAGRAM_LIMITS.warnBoxes} or fewer.`, 'Split the process into smaller diagrams.', 'warning');
  }
  if (arrowCount > DIAGRAM_LIMITS.maxArrows) {
    problem(first, `The diagram has ${arrowCount} arrows. The limit is ${DIAGRAM_LIMITS.maxArrows}.`, 'Split the process into smaller diagrams.');
  }
  /** @type {Map<string, string>} */
  const labels = new Map();
  for (const [id, b] of boxes) {
    const key = b.label.trim().toLowerCase().replace(/\s+/g, ' ');
    const other = labels.get(key);
    if (other !== undefined) lineError(b.offset, `Boxes "${other}" and "${id}" have the same label "${b.label}". Box labels must be unique.`);
    else labels.set(key, id);
  }
}

/**
 * @param {Array<{ offset: number, s: string }>} body
 * @param {DiagramCheck} result
 * @param {(offset: number, message: string, hint?: string) => void} lineError
 * @param {(st: { offset: number, s: string }) => boolean} refusedWord
 * @param {(offset: number, message: string, hint?: string, severity?: 'error' | 'warning') => void} problem
 */
function checkSequence(body, result, lineError, refusedWord, problem) {
  /** @type {Map<string, string>} */
  const participants = new Map();
  /** @type {Array<{ kind: string, offset: number }>} */
  const open = [];
  let messages = 0;
  const hint = 'Allowed: participant/actor <id> as <label>, messages like A->>B: text, loop/alt/opt/par/critical/break ... end, and notes.';
  const PART_RE = new RegExp(`^(participant|actor)\\s+(${ID})(?:\\s+as\\s+(.+))?$`);
  const MSG_RE = new RegExp(`^(${ID})\\s*(-->>|->>|-->|->|--x|-x)\\s*(${ID})\\s*:(.*)$`);
  const NOTE_RE = new RegExp(`^note\\s+(over|left of|right of)\\s+(${ID})(?:\\s*,\\s*(${ID}))?\\s*:(.*)$`, 'i');
  const BLOCK_RE = /^(loop|alt|opt|par|critical|break)(?:\s+(.*))?$/;

  for (const st of body) {
    if (refusedWord(st)) continue;
    const s = st.s;
    const word = s.split(/[\s:]/, 1)[0];
    let m;
    if ((m = PART_RE.exec(s))) {
      if (messages > 0) { lineError(st.offset, 'Declare every participant before the first message.'); continue; }
      if (participants.has(m[2])) { lineError(st.offset, `Participant "${m[2]}" is declared twice.`); continue; }
      const label = (m[3] ?? m[2]).trim();
      const why = labelProblem(label);
      if (why) { lineError(st.offset, why); continue; }
      participants.set(m[2], label);
      continue;
    }
    if (word === 'participant' || word === 'actor') { lineError(st.offset, 'Write a participant as "participant <id> as <label>".'); continue; }
    if ((m = MSG_RE.exec(s))) {
      const missing = [m[1], m[3]].find((id) => !participants.has(id));
      if (missing) { lineError(st.offset, `"${missing}" is not declared.`, `Add "participant ${missing} as <label>" before the first message.`); continue; }
      const label = m[4].trim();
      const why = label ? labelProblem(label) : 'A message needs a label after the colon.';
      if (why) { lineError(st.offset, why); continue; }
      messages++;
      continue;
    }
    if ((m = NOTE_RE.exec(s))) {
      if (messages === 0) { lineError(st.offset, 'A note cannot come before the first message (the drawing tool drops it).'); continue; }
      if (m[3] && m[1].toLowerCase() !== 'over') { lineError(st.offset, 'Only "Note over" can name two participants.'); continue; }
      const missing = [m[2], m[3]].find((id) => id && !participants.has(id));
      if (missing) { lineError(st.offset, `"${missing}" is not declared.`); continue; }
      const label = m[4].trim();
      const why = label ? labelProblem(label) : 'A note needs text after the colon.';
      if (why) lineError(st.offset, why);
      continue;
    }
    if ((m = BLOCK_RE.exec(s))) {
      if (open.length >= DIAGRAM_LIMITS.maxDepth) { lineError(st.offset, `Boxes nest at most ${DIAGRAM_LIMITS.maxDepth} deep.`); open.push({ kind: m[1], offset: st.offset }); continue; }
      const why = m[2] ? labelProblem(m[2]) : null;
      if (why) lineError(st.offset, why);
      open.push({ kind: m[1], offset: st.offset });
      continue;
    }
    if ((m = /^(else|and)(?:\s+(.*))?$/.exec(s))) {
      const want = m[1] === 'else' ? 'alt' : 'par';
      const top = open[open.length - 1];
      if (!top || top.kind !== want) { lineError(st.offset, `"${m[1]}" is allowed only inside "${want}".`); continue; }
      const why = m[2] ? labelProblem(m[2]) : null;
      if (why) lineError(st.offset, why);
      continue;
    }
    if (s === 'end') {
      if (open.length === 0) lineError(st.offset, '"end" closes nothing.');
      else open.pop();
      continue;
    }
    if (SEQ_OTHER.has(word.toLowerCase())) { lineError(st.offset, `"${word}" is not allowed.`, hint); continue; }
    if (/^[A-Za-z]\w*\s*[-<=.x(+]/.test(s) && s.includes(':')) {
      lineError(st.offset, 'Only the arrows ->>, -->>, ->, -->, -x and --x are allowed, between declared participants, with a label after a colon.');
      continue;
    }
    lineError(st.offset, 'This is not an allowed sequence diagram line.', hint);
  }
  for (const b of open) lineError(b.offset, `This "${b.kind}" is never closed with "end".`);

  result.counts.participants = participants.size;
  result.counts.arrows = messages;
  const first = body[0].offset;
  if (participants.size === 0 && flaggedNone(result)) problem(first, 'The diagram has no participants.');
  if (participants.size > DIAGRAM_LIMITS.maxParticipants) {
    problem(first, `The diagram has ${participants.size} participants. The limit is ${DIAGRAM_LIMITS.maxParticipants}.`, 'Split the process into smaller diagrams.');
  }
  if (messages > DIAGRAM_LIMITS.maxArrows) {
    problem(first, `The diagram has ${messages} messages. The limit is ${DIAGRAM_LIMITS.maxArrows}.`, 'Split the process into smaller diagrams.');
  }
  /** @type {Map<string, string>} */
  const labels = new Map();
  for (const [id, label] of participants) {
    const key = label.toLowerCase().replace(/\s+/g, ' ');
    const other = labels.get(key);
    if (other !== undefined) problem(first, `Participants "${other}" and "${id}" have the same label "${label}". Labels must be unique.`);
    else labels.set(key, id);
  }
}
