// @ts-check
// @stark/pages-renderer: turn a parsed Stark page into one safe, styled HTML document.

import { renderMarkdownWith } from './markdown.js';
import { normalizeAssetBase } from './safe.js';

export { renderPage, buildCsp, RENDERER_VERSION } from './render.js';
export { STARK_CSS } from './css.js';
// Publishing (CONTRACTS.md 12.4)
export { pageCss, FONT_FILES, DEFAULT_FONT_BASE } from './css.js';
export { PUBLISHED_CSP } from './render.js';
export { escapeHtml, classifyLink } from './safe.js';
// Diagrams drawn as pictures (CONTRACTS.md 14.3)
export { drawDiagrams, drawDiagram, diagramKey, DRAWING_TOOL } from './diagram.js';
export { sanitizeSvg, SvgSanitizeError, SANITIZER_VERSION, DIAGRAM_CLASSES } from './svg-sanitize.js';

/**
 * Safe HTML for a markdown snippet: no raw HTML, safe links only, images only from img/.
 * @param {string} text
 * @param {{ assetBase?: string }} [opts]
 * @returns {string}
 */
export function renderMarkdown(text, opts = {}) {
  const { prefix } = normalizeAssetBase(opts.assetBase);
  return renderMarkdownWith(text, { assetBase: prefix });
}
