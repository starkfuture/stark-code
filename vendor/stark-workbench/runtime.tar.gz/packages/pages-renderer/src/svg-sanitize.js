// @ts-check
/**
 * The SVG gate for drawn diagrams (CONTRACTS.md 14.3, FORMAT.md 9.4).
 *
 * `sanitizeSvg` reads the drawing tool's SVG with a small strict tokenizer (no DOM) and
 * rebuilds it from an allow list of elements and attributes. Everything else is dropped:
 * `<style>` (with its `@import` of outside fonts), `style=`, scripts, `foreignObject`,
 * images, `use`, links, animation, event handlers, `href`, `data-*`, and any value with
 * `url(` (other than a local marker), `@import`, `javascript:` or `expression(`.
 * Colours the tool sets through CSS variables become `sp-d-*` classes that the page
 * stylesheet colours in light and dark. Text is decoded and escaped again.
 */

export const SANITIZER_VERSION = '1';

export class SvgSanitizeError extends Error {}

const MAX_INPUT = 2 * 1024 * 1024;
const MAX_NODES = 20_000;
const MAX_DEPTH = 64;

const ELEMENTS = new Set(['svg', 'g', 'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'text', 'tspan', 'title', 'desc', 'defs', 'marker']);
const DRAWN = new Set(['path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'text']);
const TEXT_ELEMENTS = new Set(['text', 'tspan', 'title', 'desc']);

const NUMBERS = /^[-+0-9.eE,\s]*(px|%)?$/;
const PATH = /^[MmLlHhVvCcSsQqTtAaZz0-9eE+\-.,\s]*$/;
const MAX_TRANSFORM = 1024;
const TRANSFORM_FN = /\s*(?:translate|scale|rotate|matrix|skewX|skewY)\([-+0-9.eE,\s]*\)\s*,?/y;
/**
 * A transform list such as `translate(10 20) scale(2)`. Checked one function at a time
 * with a sticky regex, so the time is linear in the length (no backtracking across
 * functions), and values over about 1 KB are refused outright.
 * @param {string} value
 */
function isTransform(value) {
  if (value.length > MAX_TRANSFORM) return false;
  TRANSFORM_FN.lastIndex = 0;
  let at = 0;
  while (at < value.length && TRANSFORM_FN.exec(value)) at = TRANSFORM_FN.lastIndex;
  return /^\s*$/.test(value.slice(at));
}
const TRANSFORM = { test: isTransform };

/** Allowed attributes and how to check each value. */
const ATTRS = /** @type {Record<string, RegExp | { test: (v: string) => boolean } | 'color' | 'id' | 'marker' | 'class' | 'label' | 'xmlns'>} */ ({
  x: NUMBERS, y: NUMBERS, x1: NUMBERS, y1: NUMBERS, x2: NUMBERS, y2: NUMBERS,
  cx: NUMBERS, cy: NUMBERS, r: NUMBERS, rx: NUMBERS, ry: NUMBERS, width: NUMBERS, height: NUMBERS,
  d: PATH, points: NUMBERS, transform: TRANSFORM, viewBox: NUMBERS,
  preserveAspectRatio: /^[A-Za-z\s]{1,40}$/,
  fill: 'color', stroke: 'color',
  'stroke-width': NUMBERS, 'stroke-dasharray': NUMBERS,
  'stroke-linecap': /^(butt|round|square)$/, 'stroke-linejoin': /^(miter|round|bevel|arcs|miter-clip)$/,
  opacity: NUMBERS, 'fill-opacity': NUMBERS, 'stroke-opacity': NUMBERS,
  'font-size': /^[0-9.]+(px|em|%)?$/, 'font-weight': /^(normal|bold|bolder|lighter|[1-9]00)$/,
  'text-anchor': /^(start|middle|end)$/, 'dominant-baseline': /^[a-z-]{1,32}$/,
  dy: NUMBERS, dx: NUMBERS,
  'marker-start': 'marker', 'marker-end': 'marker',
  markerWidth: NUMBERS, markerHeight: NUMBERS, refX: NUMBERS, refY: NUMBERS,
  orient: /^(auto|auto-start-reverse|[-+0-9.eE]+(deg)?)$/, markerUnits: /^(strokeWidth|userSpaceOnUse)$/,
  id: 'id', class: 'class', role: /^(img|presentation|group|none)$/, 'aria-label': 'label', xmlns: 'xmlns',
});

/** Fill colours from the drawing tool's CSS variables, as page classes. */
const FILL_CLASSES = /** @type {Record<string, string>} */ ({
  '--_node-fill': 'sp-d-node', '--surface': 'sp-d-node',
  '--_group-fill': 'sp-d-bg', '--bg': 'sp-d-bg',
  '--_group-hdr': 'sp-d-head',
  '--_text': 'sp-d-text', '--fg': 'sp-d-text',
  '--_text-sec': 'sp-d-text-2', '--_text-muted': 'sp-d-text-2', '--muted': 'sp-d-text-2',
  '--_text-faint': 'sp-d-text-3',
  '--_arrow': 'sp-d-arrow', '--accent': 'sp-d-arrow',
  '--_line': 'sp-d-soft', '--line': 'sp-d-soft',
  '--_inner-stroke': 'sp-d-soft', '--_key-badge': 'sp-d-soft',
  '--_node-stroke': 'sp-d-soft', '--border': 'sp-d-soft',
});
/** Stroke colours from the drawing tool's CSS variables, as page classes. */
const STROKE_CLASSES = /** @type {Record<string, string>} */ ({
  '--_node-stroke': 'sp-d-border', '--border': 'sp-d-border',
  '--_line': 'sp-d-line', '--line': 'sp-d-line',
  '--_arrow': 'sp-d-arrow-line', '--accent': 'sp-d-arrow-line',
  '--_inner-stroke': 'sp-d-soft-line', '--_key-badge': 'sp-d-soft-line', '--_group-hdr': 'sp-d-soft-line',
  '--_text': 'sp-d-text-line', '--fg': 'sp-d-text-line', '--_text-sec': 'sp-d-text-line', '--_text-muted': 'sp-d-text-line',
  '--bg': 'sp-d-bg-line', '--_group-fill': 'sp-d-bg-line', '--_node-fill': 'sp-d-bg-line', '--surface': 'sp-d-bg-line',
});
/** Every class the sanitiser can put on an element (the page CSS styles each one). */
export const DIAGRAM_CLASSES = Object.freeze([...new Set(['sp-d', ...Object.values(FILL_CLASSES), ...Object.values(STROKE_CLASSES)])]);

const FORBIDDEN_VALUE = /url\s*\(|@import|javascript\s*:|expression\s*\(|var\s*\(|[<>\\]/i;

/** @param {string} s */
function decodeEntities(s) {
  return s.replace(/&(#x[0-9a-fA-F]{1,8}|#[0-9]{1,8}|[A-Za-z][A-Za-z0-9]{0,31});/g, (m, e) => {
    if (e[0] === '#') {
      const code = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      if (!Number.isFinite(code) || code > 0x10ffff || code === 0 || (code >= 0xd800 && code <= 0xdfff)) throw new SvgSanitizeError('Bad character reference.');
      return String.fromCodePoint(code);
    }
    const named = /** @type {Record<string, string>} */ ({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" })[e];
    if (named === undefined) throw new SvgSanitizeError(`Unknown entity &${e};.`);
    return named;
  });
}

/** @param {string} s */
function escapeXml(s) {
  return s.replace(/[&<>"']/g, (c) => /** @type {Record<string, string>} */ ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

/**
 * @typedef {{ type: 'el', name: string, attrs: Array<[string, string]>, children: Node[] }} El
 * @typedef {{ type: 'text', text: string }} TextNode
 * @typedef {El | TextNode} Node
 */

const NAME = /^[A-Za-z_][A-Za-z0-9_:.-]*/;

/**
 * Parse SVG text into a tree. Strict: anything unexpected throws.
 * @param {string} src
 * @returns {Node[]}
 */
function parse(src) {
  /** @type {El} */
  const top = { type: 'el', name: '#top', attrs: [], children: [] };
  /** @type {El[]} */
  const stack = [top];
  let i = 0;
  let nodes = 0;
  while (i < src.length) {
    const lt = src.indexOf('<', i);
    if (lt === -1 || lt > i) {
      const end = lt === -1 ? src.length : lt;
      const text = src.slice(i, end);
      if (text.trim()) stack[stack.length - 1].children.push({ type: 'text', text: decodeEntities(text) });
      i = end;
      continue;
    }
    if (src.startsWith('<!--', i)) {
      const end = src.indexOf('-->', i + 4);
      if (end === -1) throw new SvgSanitizeError('Unclosed comment.');
      i = end + 3;
      continue;
    }
    if (src.startsWith('<?', i)) {
      if (stack.length > 1) throw new SvgSanitizeError('Processing instruction inside the drawing.');
      const end = src.indexOf('?>', i + 2);
      if (end === -1) throw new SvgSanitizeError('Unclosed processing instruction.');
      i = end + 2;
      continue;
    }
    if (src.startsWith('<![CDATA[', i)) {
      const end = src.indexOf(']]>', i + 9);
      if (end === -1) throw new SvgSanitizeError('Unclosed CDATA section.');
      const text = src.slice(i + 9, end);
      if (text.trim()) stack[stack.length - 1].children.push({ type: 'text', text });
      i = end + 3;
      continue;
    }
    if (src.startsWith('<!', i)) throw new SvgSanitizeError('Declarations (DOCTYPE, ENTITY) are not allowed.');
    if (src.startsWith('</', i)) {
      const m = NAME.exec(src.slice(i + 2, i + 2 + 128));
      if (!m) throw new SvgSanitizeError('Bad closing tag.');
      let j = i + 2 + m[0].length;
      while (src[j] === ' ' || src[j] === '\t' || src[j] === '\n' || src[j] === '\r') j++;
      if (src[j] !== '>') throw new SvgSanitizeError('Bad closing tag.');
      const open = stack.pop();
      if (!open || open.name !== m[0] || stack.length === 0) throw new SvgSanitizeError(`Closing tag </${m[0]}> does not match.`);
      i = j + 1;
      continue;
    }
    const m = NAME.exec(src.slice(i + 1, i + 1 + 128));
    if (!m) throw new SvgSanitizeError('Bad tag.');
    /** @type {El} */
    const el = { type: 'el', name: m[0], attrs: [], children: [] };
    if (++nodes > MAX_NODES) throw new SvgSanitizeError('The drawing is too large.');
    let j = i + 1 + m[0].length;
    const seen = new Set();
    for (;;) {
      const ws = j;
      while (src[j] === ' ' || src[j] === '\t' || src[j] === '\n' || src[j] === '\r') j++;
      if (src[j] === '>' || src.startsWith('/>', j)) break;
      if (j === ws) throw new SvgSanitizeError('Attributes must be separated by spaces.');
      const a = NAME.exec(src.slice(j, j + 128));
      if (!a) throw new SvgSanitizeError('Bad attribute.');
      j += a[0].length;
      while (src[j] === ' ' || src[j] === '\t' || src[j] === '\n' || src[j] === '\r') j++;
      if (src[j] !== '=') throw new SvgSanitizeError('Attributes need a value.');
      j++;
      while (src[j] === ' ' || src[j] === '\t' || src[j] === '\n' || src[j] === '\r') j++;
      const q = src[j];
      if (q !== '"' && q !== "'") throw new SvgSanitizeError('Attribute values must be quoted.');
      const end = src.indexOf(q, j + 1);
      if (end === -1) throw new SvgSanitizeError('Unclosed attribute value.');
      const raw = src.slice(j + 1, end);
      if (raw.includes('<')) throw new SvgSanitizeError('"<" inside an attribute value.');
      if (seen.has(a[0])) throw new SvgSanitizeError(`Attribute ${a[0]} is repeated.`);
      seen.add(a[0]);
      el.attrs.push([a[0], decodeEntities(raw)]);
      j = end + 1;
    }
    stack[stack.length - 1].children.push(el);
    if (src.startsWith('/>', j)) { i = j + 2; continue; }
    i = j + 1;
    stack.push(el);
    if (stack.length > MAX_DEPTH) throw new SvgSanitizeError('The drawing is nested too deeply.');
  }
  if (stack.length !== 1) throw new SvgSanitizeError(`<${stack[stack.length - 1].name}> is never closed.`);
  return top.children;
}

/**
 * The CSS variable a colour value uses, like "--_node-fill", or null.
 * @param {string} v
 */
function colorVar(v) {
  const m = /^\s*var\(\s*(--[A-Za-z0-9_-]+)\s*(?:,[^()]*)?\)\s*$/.exec(v);
  return m ? m[1] : null;
}

/** @param {string} n */
function tidyNumbers(n) {
  return n.replace(/(-?\d+\.\d{3})\d+/g, (_, keep) => String(Number(keep)));
}

/**
 * Rebuild a drawing tool's SVG from the allow list.
 * @param {string} svg
 * @param {{ idPrefix?: string, title?: string | null }} [opts]
 * @returns {string}
 */
export function sanitizeSvg(svg, opts = {}) {
  if (typeof svg !== 'string' || !svg.trim()) throw new SvgSanitizeError('Empty drawing.');
  if (svg.length > MAX_INPUT) throw new SvgSanitizeError('The drawing is too large.');
  const prefix = /^[A-Za-z][A-Za-z0-9_-]{0,40}$/.test(opts.idPrefix ?? '') ? /** @type {string} */ (opts.idPrefix) : 'sp-d';
  const title = String(opts.title ?? '').trim() || 'Diagram';
  const tree = parse(svg.replace(/^﻿/, ''));
  const roots = tree.filter((n) => n.type === 'el');
  if (tree.some((n) => n.type === 'text')) throw new SvgSanitizeError('Text outside the drawing.');
  if (roots.length !== 1 || /** @type {El} */ (roots[0]).name !== 'svg') throw new SvgSanitizeError('The drawing is not one <svg> element.');
  const root = /** @type {El} */ (roots[0]);

  // Local ids (markers and anything else with an id) get the prefix.
  /** @type {Set<string>} */
  const ids = new Set();
  /** @param {El} el */
  const collect = (el) => {
    if (!ELEMENTS.has(el.name)) return;
    for (const [k, v] of el.attrs) if (k === 'id' && /^[A-Za-z][\w-]{0,63}$/.test(v)) ids.add(v);
    for (const c of el.children) if (c.type === 'el') collect(c);
  };
  collect(root);

  let drawn = 0;
  /** Ids already written: a repeated id would make url(#id) and assistive tech ambiguous. */
  /** @type {Set<string>} */
  const emitted = new Set();
  /**
   * @param {El} el
   * @param {boolean} isRoot
   * @returns {string}
   */
  const emit = (el, isRoot) => {
    if (!ELEMENTS.has(el.name)) return '';
    if (!isRoot && el.name === 'svg') return '';
    if (DRAWN.has(el.name)) drawn++;
    /** @type {string[]} */
    const classes = isRoot ? ['sp-d'] : [];
    /** @type {string[]} */
    const out = [];
    for (const [name, value] of el.attrs) {
      const rule = Object.hasOwn(ATTRS, name) ? ATTRS[name] : null;
      if (!rule) continue;
      if (rule === 'color') {
        const v = value.trim();
        if (/^(none|transparent)$/i.test(v)) { out.push(`${name}="none"`); continue; }
        if (/^currentColor$/i.test(v)) { out.push(`${name}="currentColor"`); continue; }
        const variable = colorVar(v);
        const map = name === 'fill' ? FILL_CLASSES : STROKE_CLASSES;
        // A colour that is not one of the tool's variables gets a neutral class.
        const fallback = name === 'fill' ? (TEXT_ELEMENTS.has(el.name) ? 'sp-d-text' : 'sp-d-node') : 'sp-d-border';
        const cls = (variable && Object.hasOwn(map, variable)) ? map[variable] : fallback;
        if (!classes.includes(cls)) classes.push(cls);
        continue;
      }
      if (rule === 'class' || rule === 'xmlns') continue; // the tool's own classes are dropped; xmlns is written below
      if (rule === 'id') {
        if (/^[A-Za-z][\w-]{0,63}$/.test(value) && !emitted.has(value)) {
          emitted.add(value);
          out.push(`id="${escapeXml(`${prefix}-${value}`)}"`);
        }
        continue;
      }
      if (rule === 'marker') {
        const m = /^\s*url\(\s*#([A-Za-z][\w-]{0,63})\s*\)\s*$/.exec(value);
        if (m && ids.has(m[1])) out.push(`${name}="url(#${escapeXml(`${prefix}-${m[1]}`)})"`);
        continue;
      }
      if (rule === 'label') {
        if (FORBIDDEN_VALUE.test(value) || value.length > 300) continue;
        out.push(`${name}="${escapeXml(value)}"`);
        continue;
      }
      if (value.length > 100_000 || FORBIDDEN_VALUE.test(value) || !rule.test(value)) continue;
      if (isRoot && name === 'role') continue;
      out.push(`${name}="${escapeXml(tidyNumbers(value))}"`);
    }
    if (isRoot) out.unshift('xmlns="http://www.w3.org/2000/svg"', 'role="img"', `aria-label="${escapeXml(title)}"`);
    if (classes.length) out.push(`class="${classes.join(' ')}"`);

    let inner = isRoot ? `<title>${escapeXml(title)}</title>` : '';
    for (const c of el.children) {
      if (c.type === 'text') {
        if (TEXT_ELEMENTS.has(el.name)) inner += escapeXml(c.text.replace(/\s+/g, ' '));
      } else if (!(isRoot && c.name === 'title')) {
        // The root gets one <title> (the caption); the drawing tool's own top-level title goes.
        inner += emit(c, false);
      }
    }
    return `<${el.name}${out.length ? ` ${out.join(' ')}` : ''}>${inner}</${el.name}>`;
  };
  const result = emit(root, true);
  if (drawn === 0) throw new SvgSanitizeError('The drawing is empty.');
  return result;
}
