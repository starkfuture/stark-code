// @ts-check
export { parsePage, sectionKey } from './parse.js';
export { validatePage } from './validate.js';
export { formatIssues, safeText } from './format.js';
export {
  PAGE_TYPES, REQUIRED_SECTIONS, REQUIRED_BLOCKS, TYPED_BLOCKS, ISSUE_CODES, KNOWN_FIELDS,
  SLUG_PATTERN, SLUG_RE, MAX_PAGE_BYTES, PLACEHOLDERS,
} from './constants.js';
export { HEADER_SCHEMA, OPTIONS_SCHEMA, FINDINGS_SCHEMA, BLOCK_SCHEMAS } from './schemas/index.js';
export { linkSafety, imageTarget } from './links.js';
export {
  sniffImage, describeImageBytes, ALLOWED_IMAGE_TYPES, CONVERTIBLE_IMAGE_TYPES, IMAGE_LIMITS, IMAGE_CONTENT_TYPES,
} from './images.js';
export { checkMermaid, diagramCaption, labelProblem, DIAGRAM_LIMITS } from './mermaid-subset.js';

/**
 * @typedef {import('./parse.js').PageDoc} PageDoc
 * @typedef {import('./parse.js').Section} Section
 * @typedef {import('./parse.js').Block} Block
 * @typedef {import('./parse.js').Issue} Issue
 * @typedef {import('./validate.js').ValidationResult} ValidationResult
 */
