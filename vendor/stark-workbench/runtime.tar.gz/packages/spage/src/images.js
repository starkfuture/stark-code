// @ts-check
/**
 * Images in and out of pages (CONTRACTS.md 13.2).
 *
 *   sniffImage(bytes)            type and size from the first bytes (from @stark/page-format/images)
 *   stripMetadata(bytes, type)   drop EXIF, XMP, IPTC, comments and text chunks; keep the picture
 *                                and standard ICC colour profiles (cleanIccProfile)
 *   readOrientation(bytes)       the EXIF orientation (or HEIC irot/imir), from @stark/page-format/images
 *   normaliseImage(bytes, opts)  refuse huge input, turn photos upright, convert HEIC/TIFF/BMP,
 *                                shrink with sips, strip
 *   addImage(pageDir, input)     write img/<name>.<ext> and return the markdown for it
 *   readClipboardImage()         the macOS clipboard image (PNG or TIFF), or null
 *   saveUpload(root, slug, ...)  the mirror's upload route; also notes the image in inbox.jsonl
 *
 * normaliseImage, addImage, readClipboardImage and saveUpload return Promises (sips and
 * osascript run through execFile). Only built-in modules and the dependency-free
 * `@stark/page-format/images` are loaded, so this file loads even without npm install.
 */
import { execFile as nodeExecFile } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import zlib from 'node:zlib';
import { sniffImage, readOrientation, SWAPS_SIDES, ALLOWED_IMAGE_TYPES, IMAGE_LIMITS } from '@stark/page-format/images';
import { PLUGIN_ROOT } from './deps.js';
import { isSlug, pagesDir, stateDir } from './pages.js';

export { sniffImage, readOrientation };

/** Inputs over these limits are refused before anything decodes them. */
export const MAX_INPUT_BYTES = 25 * 1024 * 1024;
export const MAX_INPUT_PIXELS = 50_000_000;
const SIPS = '/usr/bin/sips';
const OSASCRIPT = '/usr/bin/osascript';
const TOOL_TIMEOUT_MS = 30_000;

/**
 * An image problem with a plain message. `status` is the HTTP status the mirror answers with.
 */
export class ImageError extends Error {
  /** @param {string} message @param {{ status?: number, code?: string }} [o] */
  constructor(message, o = {}) {
    super(message);
    this.name = 'ImageError';
    this.status = o.status ?? 422;
    this.code = o.code ?? 'image';
  }
}

/** @param {string} what */
const damaged = (what) => new ImageError(`The ${what} file is damaged, so its metadata cannot be removed.`, { status: 415, code: 'damaged' });

/** @param {Uint8Array} b @param {number} i */
const u16be = (b, i) => (b[i] << 8) | b[i + 1];
/** @param {Uint8Array} b @param {number} i */
const u16le = (b, i) => b[i] | (b[i + 1] << 8);
/** @param {Uint8Array} b @param {number} i */
const u32be = (b, i) => ((b[i] << 24) >>> 0) + ((b[i + 1] << 16) | (b[i + 2] << 8) | b[i + 3]);
/** @param {Uint8Array} b @param {number} i */
const u32le = (b, i) => ((b[i + 3] << 24) >>> 0) + ((b[i + 2] << 16) | (b[i + 1] << 8) | b[i]);
/** @param {Uint8Array} b @param {number} i @param {string} s */
const ascii = (b, i, s) => {
  if (i + s.length > b.length) return false;
  for (let k = 0; k < s.length; k++) if (b[i + k] !== s.charCodeAt(k)) return false;
  return true;
};

/**
 * Which JPEG segment to keep (an allow list, so unknown metadata never survives):
 * tables, frames, scans and restarts; APP0 only as JFIF (its thumbnail removed by the
 * caller); APP2 only as an ICC profile (filtered by cleanIccProfile); APP14 only as Adobe.
 * Every other APPn (EXIF, XMP, MPF, JUMBF/C2PA content credentials, IPTC...) and COM is dropped.
 * @param {number} marker @param {Buffer} payload the segment after its length bytes
 */
function keepJpegSegment(marker, payload) {
  if (marker === 0xdb || marker === 0xc4 || marker === 0xdd || marker === 0xdc || marker === 0xda || marker === 0xcc) return true;
  if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc8) return true; // SOFn
  if (marker === 0xe0) return ascii(payload, 0, 'JFIF\0');
  if (marker === 0xe2) return ascii(payload, 0, 'ICC_PROFILE\0');
  if (marker === 0xee) return ascii(payload, 0, 'Adobe');
  return false;
}

/** The most profile data one JPEG APP2 segment holds (65535 minus the length and the 14-byte header). */
const ICC_SEGMENT_DATA = 65535 - 2 - 14;

/**
 * JPEG: keep only the segments keepJpegSegment allows; a JFIF APP0 loses its thumbnail.
 * An ICC profile (one or more APP2 segments) is put back together, filtered by
 * cleanIccProfile and written again where its first segment was, or dropped.
 * Data after the end marker is dropped.
 * @param {Buffer} b
 */
function stripJpeg(b) {
  if (b[0] !== 0xff || b[1] !== 0xd8) throw damaged('JPEG');
  /** @type {Buffer[]} */
  const out = [b.subarray(0, 2)];
  /** @type {Array<{ seq: number, count: number, data: Buffer }>} */
  const icc = [];
  let iccAt = -1;
  const finish = () => {
    if (iccAt >= 0) out[iccAt] = iccSegments(icc);
    return Buffer.concat(out);
  };
  let i = 2;
  while (i < b.length) {
    if (b[i] !== 0xff) throw damaged('JPEG');
    let m = i + 1;
    while (b[m] === 0xff && m < b.length) m++; // fill bytes
    const marker = b[m];
    if (marker === undefined) throw damaged('JPEG');
    if (marker === 0xd9) { out.push(Buffer.from([0xff, 0xd9])); return finish(); }
    if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { out.push(Buffer.from([0xff, marker])); i = m + 1; continue; }
    if (m + 2 >= b.length) throw damaged('JPEG');
    const len = u16be(b, m + 1);
    const end = m + 1 + len;
    if (len < 2 || end > b.length) throw damaged('JPEG');
    const payload = b.subarray(m + 3, end);
    if (keepJpegSegment(marker, payload)) {
      if (marker === 0xe2) {
        // ICC_PROFILE\0, sequence number, count, data
        if (payload.length >= 14) icc.push({ seq: payload[12], count: payload[13], data: payload.subarray(14) });
        if (iccAt < 0) { iccAt = out.length; out.push(Buffer.alloc(0)); }
      } else if (marker === 0xe0 && payload.length > 14) {
        // JFIF header without its thumbnail (the thumbnail can show the uncropped original).
        const head = Buffer.from(payload.subarray(0, 14));
        head[12] = 0;
        head[13] = 0;
        out.push(Buffer.from([0xff, 0xe0, 0x00, 16]), head);
      } else {
        out.push(Buffer.concat([Buffer.from([0xff, marker]), b.subarray(m + 1, end)]));
      }
    }
    i = end;
    if (marker === 0xda) {
      // Entropy-coded data runs to the next marker that is not a stuffed byte or a restart.
      let j = i;
      while (j < b.length) {
        if (b[j] === 0xff && j + 1 < b.length) {
          const n = b[j + 1];
          if (n === 0x00 || (n >= 0xd0 && n <= 0xd7) || n === 0xff) { j += n === 0xff ? 1 : 2; continue; }
          break;
        }
        j++;
      }
      out.push(b.subarray(i, j));
      i = j;
      if (i >= b.length) return finish(); // no end marker: keep what there is
    }
  }
  return finish();
}

/**
 * The APP2 segments for a JPEG ICC profile after filtering, or nothing when the profile is
 * dropped (pieces missing, repeated or out of range, or not a standard colour space).
 * @param {Array<{ seq: number, count: number, data: Buffer }>} pieces
 */
function iccSegments(pieces) {
  const count = pieces[0]?.count ?? 0;
  if (!count || pieces.length !== count) return Buffer.alloc(0);
  const ordered = [...pieces].sort((a, b) => a.seq - b.seq);
  if (ordered.some((p, k) => p.count !== count || p.seq !== k + 1)) return Buffer.alloc(0);
  const profile = cleanIccProfile(Buffer.concat(ordered.map((p) => p.data)));
  if (!profile) return Buffer.alloc(0);
  const n = Math.ceil(profile.length / ICC_SEGMENT_DATA);
  if (n > 255) return Buffer.alloc(0);
  /** @type {Buffer[]} */
  const segs = [];
  for (let k = 0; k < n; k++) {
    const data = profile.subarray(k * ICC_SEGMENT_DATA, (k + 1) * ICC_SEGMENT_DATA);
    const len = Buffer.alloc(2);
    len.writeUInt16BE(data.length + 16);
    segs.push(Buffer.from([0xff, 0xe2]), len, Buffer.from('ICC_PROFILE\0', 'latin1'), Buffer.from([k + 1, n]), data);
  }
  return Buffer.concat(segs);
}

/**
 * Descriptions of standard colour spaces (lower case, single spaces). A profile whose
 * description is anything else (a camera, a scanner, a person's own name for it) is dropped,
 * so device or owner text cannot ride along in it.
 */
const ICC_STANDARD_NAMES = new Set([
  'srgb', 'srgb iec61966-2.1', 'srgb iec61966-2-1', 'srgb iec 61966-2.1', 'srgb iec61966-2.1 black scaled',
  'srgb iec61966-2-1 black scaled', 'srgb built-in', 'srgb profile', 'srgb2014', 'srgb v4 icc preference perceptual intent beta',
  'srgb v4 icc appearance perceptual intent beta', 'linear srgb', 'srgb linear', 'scrgb',
  'display p3', 'p3', 'dci-p3', 'dci p3', 'p3 d65', 'display p3 (apple)', 'apple display p3',
  'adobe rgb (1998)', 'adobe rgb', 'compatible with adobe rgb (1998)', 'apple rgb', 'colormatch rgb', 'prophoto rgb',
  'romm rgb', 'romm-rgb', 'romm rgb: iso 22028-2:2013', 'ecirgb v2', 'ecirgb v4', 'smpte rp 431-2-2007 dci (p3)',
  'aces cg linear (academy color encoding system ap1)', 'acescg linear', 'aces cg linear',
  'generic rgb profile', 'generic gray profile', 'generic gray gamma 2.2 profile', 'generic cmyk profile',
  'generic lab profile', 'generic xyz profile', 'generic hdr profile', 'gray gamma 2.2', 'gray gamma 1.8', 'dot gain 20%',
  'rec. itu-r bt.709-5', 'rec. itu-r bt.2020-1', 'itu-r bt.709', 'itu-r bt.2020', 'bt.709', 'bt.2020', 'rec. 709',
  'rec.709', 'rec. 2020', 'rec.2020', 'rec. 2100 pq', 'rec. 2100 hlg', 'display p3 pq', 'display p3 hlg',
  'u.s. web coated (swop) v2', 'coated fogra39 (iso 12647-2:2004)', 'uncoated fogra29 (iso 12647-2:2004)',
  'japan color 2001 coated',
]);

/**
 * Copyright owners of standard profiles, after "Copyright", "(c)", years and punctuation are
 * taken out. A copyright tag that names anyone else (or adds any other words) is removed.
 */
const ICC_COPYRIGHT_OWNERS = new Set([
  'apple inc', 'apple computer inc', 'apple', 'hewlett packard company', 'international color consortium',
  'adobe systems incorporated', 'adobe systems inc', 'adobe inc', 'microsoft corporation', 'google inc', 'google llc',
  'eastman kodak company', 'kodak', 'no use freely', 'public domain', 'cc0', 'eci', 'fogra',
]);

/** @param {string} text */
const iccOwner = (text) => text.toLowerCase().replace(/copyright|\(c\)|©|all rights reserved|\d{4}|[.,:;-]/g, ' ').replace(/\s+/g, ' ').trim();

/** Tag types that hold text; only desc and cprt may be text, so a colour tag of these types is removed. */
const ICC_TEXT_TYPES = new Set(['text', 'desc', 'mluc', 'utf8', 'utf6', 'utf1', 'zut8', 'zxml', 'dict', 'meta']);

/**
 * ICC tags that describe colour (numbers only, apart from desc and cprt). Every other tag
 * (device maker and model, Apple's display make and model, private vendor tags, extra
 * text) is removed.
 */
const ICC_KEEP_TAGS = new Set([
  'desc', 'cprt', 'wtpt', 'bkpt', 'rXYZ', 'gXYZ', 'bXYZ', 'rTRC', 'gTRC', 'bTRC', 'kTRC', 'chad', 'chrm',
  'A2B0', 'A2B1', 'A2B2', 'B2A0', 'B2A1', 'B2A2', 'D2B0', 'D2B1', 'D2B2', 'D2B3', 'B2D0', 'B2D1', 'B2D2', 'B2D3',
  'gamt', 'lumi', 'meas', 'cicp', 'tech', 'rig0', 'rig2', 'ciis', 'clrt', 'clro', 'clot', 'view', 'pre0', 'pre1', 'pre2',
]);

/**
 * The strings of an ICC text tag ('desc', 'mluc' or 'text' type), or null when it cannot be read.
 * @param {Buffer} p @param {number} off @param {number} len
 * @returns {string[] | null}
 */
function iccStrings(p, off, len) {
  if (len < 12) return null;
  const end = off + len;
  const clean = (/** @type {string} */ s) => s.replace(/\0+$/, '');
  if (ascii(p, off, 'desc')) {
    const n = u32be(p, off + 8);
    if (off + 12 + n > end) return null;
    const out = [clean(p.toString('latin1', off + 12, off + 12 + n))];
    const u = off + 12 + n;
    if (u + 8 <= end) {
      const un = u32be(p, u + 4);
      if (un > 0) {
        if (u + 8 + un * 2 > end) return null;
        out.push(clean(Buffer.from(p.subarray(u + 8, u + 8 + un * 2)).swap16().toString('utf16le')));
      }
    }
    return out;
  }
  if (ascii(p, off, 'text')) return [clean(p.toString('latin1', off + 8, end))];
  if (ascii(p, off, 'mluc')) {
    if (len < 16) return null;
    const n = u32be(p, off + 8);
    const size = u32be(p, off + 12);
    if (n === 0 || n > 200 || size < 12 || off + 16 + n * size > end) return null;
    /** @type {string[]} */
    const out = [];
    for (let k = 0; k < n; k++) {
      const r = off + 16 + k * size;
      const sl = u32be(p, r + 4);
      const so = u32be(p, r + 8);
      if (sl % 2 || off + so + sl > end) return null;
      out.push(clean(Buffer.from(p.subarray(off + so, off + so + sl)).swap16().toString('utf16le')));
    }
    return out;
  }
  return null;
}

/** @param {string} s */
const iccName = (s) => s.toLowerCase().replace(/\s+/g, ' ').trim();

/**
 * A text tag rebuilt with only its text (no hidden bytes after it), in the same tag type.
 * @param {string} type 'desc', 'mluc' or 'text' @param {string} text
 */
function iccTextTag(type, text) {
  if (type === 'mluc') {
    const s = Buffer.from(text, 'utf16le').swap16();
    const head = Buffer.alloc(28);
    head.write('mluc', 0, 'latin1');
    head.writeUInt32BE(1, 8);
    head.writeUInt32BE(12, 12);
    head.write('enUS', 16, 'latin1');
    head.writeUInt32BE(s.length, 20);
    head.writeUInt32BE(28, 24);
    return Buffer.concat([head, s]);
  }
  const a = Buffer.from(`${text}\0`, 'latin1');
  if (type === 'text') return Buffer.concat([Buffer.from('text\0\0\0\0', 'latin1'), a]);
  const head = Buffer.alloc(12);
  head.write('desc', 0, 'latin1');
  head.writeUInt32BE(a.length, 8);
  return Buffer.concat([head, a, Buffer.alloc(4 + 4 + 2 + 1 + 67)]);
}

/**
 * Keep an ICC colour profile only when it describes a standard colour space (sRGB, Display
 * P3, Adobe RGB, Generic RGB...), and then only its colour tags: device maker and model
 * tags, vendor tags, extra text and any bytes between tags go, the description and
 * copyright are rewritten with only their text, and the header's device maker, model,
 * attributes, creator and profile ID are zeroed (zero means "not set" in ICC).
 * @param {Buffer} p the whole profile
 * @returns {Buffer | null} the cleaned profile, or null to drop it
 */
export function cleanIccProfile(p) {
  if (p.length < 132) return null;
  const size = u32be(p, 0);
  if (size < 132 || size > p.length || !ascii(p, 36, 'acsp')) return null;
  const n = u32be(p, 128);
  if (n > 200 || 132 + n * 12 > size) return null;
  /** @type {Array<{ sig: string, off: number, len: number }>} */
  const tags = [];
  for (let k = 0; k < n; k++) {
    const e = 132 + k * 12;
    const t = { sig: p.toString('latin1', e, e + 4), off: u32be(p, e + 4), len: u32be(p, e + 8) };
    if (t.off < 132 + n * 12 || t.len < 8 || t.off + t.len > size) return null;
    tags.push(t);
  }
  const desc = tags.filter((t) => t.sig === 'desc');
  if (desc.length !== 1) return null;
  const names = iccStrings(p, desc[0].off, desc[0].len);
  if (!names || !names[0] || !names.every((s) => s === '' || ICC_STANDARD_NAMES.has(iccName(s)))) return null;
  /** @type {Array<{ sig: string, data: Buffer }>} */
  const kept = [];
  /** @type {Map<string, Buffer>} the same data block is shared by several tags (like rTRC, gTRC, bTRC) */
  const shared = new Map();
  for (const t of tags) {
    if (!ICC_KEEP_TAGS.has(t.sig) || kept.some((k) => k.sig === t.sig)) continue;
    let data;
    if (t.sig === 'desc') {
      data = iccTextTag(p.toString('latin1', t.off, t.off + 4), names[0]);
    } else if (t.sig === 'cprt') {
      const text = iccStrings(p, t.off, t.len)?.[0] ?? '';
      if (!ICC_COPYRIGHT_OWNERS.has(iccOwner(text))) continue;
      data = iccTextTag(p.toString('latin1', t.off, t.off + 4), text);
    } else {
      if (ICC_TEXT_TYPES.has(p.toString('latin1', t.off, t.off + 4))) continue;
      const key = `${t.off}:${t.len}`;
      data = shared.get(key) ?? Buffer.from(p.subarray(t.off, t.off + t.len));
      shared.set(key, data);
    }
    kept.push({ sig: t.sig, data });
  }
  // Lay the profile out again: header, tag table, then each data block once, 4-byte aligned.
  const head = Buffer.from(p.subarray(0, 128));
  head.fill(0, 48, 64); // device manufacturer, model and attributes
  head.fill(0, 80, 100); // creator and profile ID
  const table = Buffer.alloc(4 + kept.length * 12);
  table.writeUInt32BE(kept.length, 0);
  /** @type {Buffer[]} */
  const blocks = [];
  /** @type {Map<Buffer, number>} */
  const at = new Map();
  let offset = 128 + table.length;
  kept.forEach((k, idx) => {
    let o = at.get(k.data);
    if (o === undefined) {
      o = offset;
      at.set(k.data, o);
      const pad = (4 - (k.data.length % 4)) % 4;
      blocks.push(k.data, Buffer.alloc(pad));
      offset += k.data.length + pad;
    }
    table.write(k.sig, 4 + idx * 12, 'latin1');
    table.writeUInt32BE(o, 8 + idx * 12);
    table.writeUInt32BE(k.data.length, 12 + idx * 12);
  });
  head.writeUInt32BE(offset, 0);
  return Buffer.concat([head, table, ...blocks]);
}

/** PNG chunks kept (an allow list): the picture, its colour, and animation. Text, EXIF, time, C2PA and private chunks go. */
const PNG_KEEP = new Set(['IHDR', 'PLTE', 'IDAT', 'IEND', 'tRNS', 'gAMA', 'cHRM', 'sRGB', 'iCCP', 'pHYs', 'sBIT', 'bKGD', 'acTL', 'fcTL', 'fdAT', 'cICP']);

/**
 * A PNG iCCP chunk with its profile filtered by cleanIccProfile and a plain name, or
 * nothing when the profile is dropped. The profile name is free text, so it is replaced.
 * @param {Buffer} data the chunk data
 */
function cleanPngIcc(data) {
  const nul = data.indexOf(0);
  if (nul < 1 || nul > 79 || data[nul + 1] !== 0) return Buffer.alloc(0);
  let profile;
  try {
    profile = zlib.inflateSync(data.subarray(nul + 2), { maxOutputLength: 4 * 1024 * 1024 });
  } catch {
    return Buffer.alloc(0);
  }
  const clean = cleanIccProfile(profile);
  if (!clean) return Buffer.alloc(0);
  const body = Buffer.concat([Buffer.from('iCCPICC Profile\0\0', 'latin1'), zlib.deflateSync(clean)]);
  const len = Buffer.alloc(4);
  len.writeUInt32BE(body.length - 4);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(zlib.crc32(body) >>> 0);
  return Buffer.concat([len, body, crc]);
}

/** PNG: keep only the chunks in PNG_KEEP (iCCP filtered by cleanIccProfile); stop after IEND. @param {Buffer} b */
function stripPng(b) {
  /** @type {Buffer[]} */
  const out = [b.subarray(0, 8)];
  let i = 8;
  while (i + 12 <= b.length) {
    const len = u32be(b, i);
    const type = b.toString('latin1', i + 4, i + 8);
    const end = i + 12 + len;
    if (end > b.length) throw damaged('PNG');
    if (type === 'iCCP') out.push(cleanPngIcc(b.subarray(i + 8, i + 8 + len)));
    else if (PNG_KEEP.has(type)) out.push(b.subarray(i, end));
    i = end;
    if (type === 'IEND') return Buffer.concat(out);
  }
  throw damaged('PNG');
}

/** WebP chunks kept at the top level (an allow list). EXIF, XMP and unknown chunks go. */
const WEBP_KEEP = new Set(['VP8 ', 'VP8L', 'VP8X', 'ALPH', 'ANIM', 'ANMF', 'ICCP']);
/** Sub-chunks kept inside an animation frame (ANMF), after its 16-byte frame header. */
const WEBP_FRAME_KEEP = new Set(['ALPH', 'VP8 ', 'VP8L']);

/** @param {string} id @param {Buffer} data */
function riffChunk(id, data) {
  const head = Buffer.alloc(8);
  head.write(id, 0, 'latin1');
  head.writeUInt32LE(data.length, 4);
  return Buffer.concat([head, data, Buffer.alloc(data.length % 2)]);
}

/**
 * The RIFF chunks in b[start, end), or a damaged error when one runs past the end.
 * @param {Buffer} b @param {number} start @param {number} end
 */
function riffChunks(b, start, end) {
  /** @type {Array<{ id: string, data: Buffer }>} */
  const out = [];
  let i = start;
  while (i + 8 <= end) {
    const len = u32le(b, i + 4);
    if (i + 8 + len > end) throw damaged('WebP');
    out.push({ id: b.toString('latin1', i, i + 4), data: b.subarray(i + 8, i + 8 + len) });
    i += 8 + len + (len % 2);
  }
  return out;
}

/**
 * WebP: keep only the chunks in WEBP_KEEP; inside each animation frame keep only its frame
 * header and ALPH, VP8 and VP8L. An ICC profile is filtered by cleanIccProfile. The VP8X
 * flags for EXIF and XMP are cleared, and the ICC flag too when the profile is dropped.
 * @param {Buffer} b
 */
function stripWebp(b) {
  if (!ascii(b, 0, 'RIFF') || !ascii(b, 8, 'WEBP')) throw damaged('WebP');
  const riffEnd = Math.min(b.length, 8 + u32le(b, 4));
  const chunks = riffChunks(b, 12, riffEnd);
  /** @type {Buffer | null} */
  let icc = null;
  for (const c of chunks) if (c.id === 'ICCP' && !icc) icc = cleanIccProfile(Buffer.from(c.data));
  /** @type {Buffer[]} */
  const out = [];
  let iccDone = false;
  for (const c of chunks) {
    if (!WEBP_KEEP.has(c.id)) continue;
    if (c.id === 'VP8X') {
      const data = Buffer.from(c.data);
      if (data.length > 0) data[0] &= ~(0x08 | 0x04 | (icc ? 0 : 0x20));
      out.push(riffChunk('VP8X', data));
    } else if (c.id === 'ICCP') {
      if (icc && !iccDone) out.push(riffChunk('ICCP', icc));
      iccDone = true;
    } else if (c.id === 'ANMF') {
      if (c.data.length < 16) throw damaged('WebP');
      const sub = riffChunks(c.data, 16, c.data.length).filter((s) => WEBP_FRAME_KEEP.has(s.id));
      out.push(riffChunk('ANMF', Buffer.concat([c.data.subarray(0, 16), ...sub.map((s) => riffChunk(s.id, s.data))])));
    } else {
      out.push(riffChunk(c.id, c.data));
    }
  }
  const body = Buffer.concat([Buffer.from('WEBP', 'latin1'), ...out]);
  const size = Buffer.alloc(4);
  size.writeUInt32LE(body.length, 0);
  return Buffer.concat([Buffer.from('RIFF', 'latin1'), size, body]);
}

/**
 * The blocks of a GIF after its header and global colour table (which end at `head`), in order.
 * @param {Buffer} b
 * @returns {{ head: number, blocks: Array<{ kind: 'ext', label: number, start: number, end: number, blocks: Buffer[] }
 *   | { kind: 'image', start: number, end: number, left: number, top: number, width: number, height: number }> }}
 */
function gifBlocks(b) {
  if (b.length < 13) throw damaged('GIF');
  let i = 13;
  const flags = b[10];
  if (flags & 0x80) i += 3 * (1 << ((flags & 0x07) + 1));
  /** Data sub-blocks starting at j: their contents and the index after the terminator. */
  const subBlocks = (/** @type {number} */ j) => {
    /** @type {Buffer[]} */
    const blocks = [];
    while (j < b.length) {
      const n = b[j];
      if (n === 0) return { blocks, end: j + 1 };
      if (j + 1 + n > b.length) break;
      blocks.push(b.subarray(j + 1, j + 1 + n));
      j += n + 1;
    }
    throw damaged('GIF');
  };
  const head = i;
  /** @type {ReturnType<typeof gifBlocks>['blocks']} */
  const out = [];
  while (i < b.length) {
    const kind = b[i];
    if (kind === 0x3b) return { head, blocks: out };
    if (kind === 0x21) {
      if (i + 2 > b.length) throw damaged('GIF');
      const { blocks, end } = subBlocks(i + 2);
      out.push({ kind: 'ext', label: b[i + 1], start: i, end, blocks });
      i = end;
      continue;
    }
    if (kind === 0x2c) {
      if (i + 10 > b.length) throw damaged('GIF');
      let j = i + 10;
      const f = b[i + 9];
      if (f & 0x80) j += 3 * (1 << ((f & 0x07) + 1));
      j += 1; // LZW minimum code size
      const { end } = subBlocks(j);
      out.push({ kind: 'image', start: i, end, left: u16le(b, i + 1), top: u16le(b, i + 3), width: u16le(b, i + 5), height: u16le(b, i + 7) });
      i = end;
      continue;
    }
    throw damaged('GIF');
  }
  throw damaged('GIF');
}

/** Application extensions that set looping; both are written back as NETSCAPE2.0. */
const GIF_LOOP_APPS = new Set(['NETSCAPE2.0', 'ANIMEXTS1.0']);

/**
 * GIF: keep the header, colour tables and frames; of the extensions keep only the graphic
 * control extension (its 4 bytes) and the looping extension, rewritten to its loop count
 * alone. Comments, plain text, XMP and every other extension go.
 * @param {Buffer} b
 */
function stripGif(b) {
  const { head, blocks } = gifBlocks(b);
  /** @type {Buffer[]} */
  const out = [b.subarray(0, head)];
  for (const k of blocks) {
    if (k.kind === 'image') { out.push(b.subarray(k.start, k.end)); continue; }
    if (k.label === 0xf9 && k.blocks[0]?.length === 4) {
      out.push(Buffer.from([0x21, 0xf9, 4]), k.blocks[0], Buffer.from([0]));
    } else if (k.label === 0xff && k.blocks[0]?.length === 11 && GIF_LOOP_APPS.has(k.blocks[0].toString('latin1'))) {
      const loop = k.blocks.slice(1).find((s) => s.length === 3 && s[0] === 1);
      if (loop) out.push(Buffer.from([0x21, 0xff, 11]), Buffer.from('NETSCAPE2.0', 'latin1'), Buffer.from([3, 1, loop[1], loop[2], 0]));
    }
  }
  out.push(Buffer.from([0x3b]));
  return Buffer.concat(out);
}

/**
 * Refuse a GIF with a frame that lies outside its screen or is over 50 million pixels,
 * before anything decodes it (a decoder may allocate the frame size, not the screen size).
 * @param {Buffer} b
 */
function checkGifFrames(b) {
  const sw = u16le(b, 6);
  const sh = u16le(b, 8);
  for (const k of gifBlocks(b).blocks) {
    if (k.kind !== 'image') continue;
    if (k.width * k.height > MAX_INPUT_PIXELS) {
      throw new ImageError(`A frame of this GIF is ${k.width} x ${k.height} pixels. Images over 50 million pixels are not opened. Export a smaller one.`, { status: 413, code: 'too-large' });
    }
    if (k.left + k.width > sw || k.top + k.height > sh) {
      throw new ImageError(`A frame of this GIF (${k.width} x ${k.height} at ${k.left}, ${k.top}) lies outside its ${sw} x ${sh} screen, so it is probably damaged. Export it again.`, { status: 415, code: 'damaged' });
    }
  }
}

/**
 * Remove metadata that can carry a location, a name or a device, by allow list: only the
 * parts a picture needs survive (see keepJpegSegment, PNG_KEEP, WEBP_KEEP and
 * WEBP_FRAME_KEEP, stripGif). ICC colour profiles stay only for standard colour spaces,
 * cleaned (cleanIccProfile). The orientation tag goes with the rest, so normaliseImage
 * turns the pixels upright first. Pure JavaScript.
 * @param {Uint8Array} bytes
 * @param {string} type png, jpg, webp or gif
 * @returns {Buffer}
 */
export function stripMetadata(bytes, type) {
  const b = Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (type === 'jpg' || type === 'jpeg') return stripJpeg(b);
  if (type === 'png') return stripPng(b);
  if (type === 'webp') return stripWebp(b);
  if (type === 'gif') return stripGif(b);
  throw new ImageError(`Cannot remove metadata from a ${type} image. Convert it to PNG or JPEG first.`, { status: 415, code: 'type' });
}

/**
 * @typedef {(file: string, args: string[], opts: { timeout: number, maxBuffer?: number }) => Promise<{ stdout: string, stderr: string }>} ExecFn
 */

/** @type {ExecFn} */
function execFileAsync(file, args, opts) {
  return new Promise((resolve, reject) => {
    nodeExecFile(file, args, { timeout: opts.timeout, maxBuffer: opts.maxBuffer ?? 1024 * 1024, encoding: 'utf8' }, (err, stdout, stderr) => {
      if (err) reject(Object.assign(err, { stdout, stderr }));
      else resolve({ stdout: String(stdout), stderr: String(stderr) });
    });
  });
}

/** The command a person runs outside Claude's sandbox. @param {string} cmd */
function outsideCommand(cmd) {
  const root = process.env.CLAUDE_PLUGIN_ROOT || PLUGIN_ROOT;
  return `! node ${path.join(root, 'packages', 'spage', 'bin', 'spage.js')} ${cmd}`;
}

/**
 * Run sips with an argument array (never a shell string).
 * @param {string[]} args
 * @param {{ exec?: ExecFn, retry?: string }} o
 */
async function runSips(args, o) {
  const exec = o.exec ?? execFileAsync;
  try {
    return await exec(SIPS, args, { timeout: TOOL_TIMEOUT_MS });
  } catch (e) {
    const err = /** @type {NodeJS.ErrnoException & { killed?: boolean, stderr?: string }} */ (e);
    if (err.code === 'ENOENT') {
      throw new ImageError('This image needs converting or shrinking, and sips (part of macOS) is not available. Save it as PNG or JPEG under 1 MB and 4096 pixels per side, then add it again.', { code: 'sips-missing' });
    }
    if (err.killed) throw new ImageError('sips took too long to convert the image. Try a smaller image.', { code: 'sips-timeout' });
    // Inside Claude's sandbox sips cannot write its own temporary file ("Cannot write to file /var/folders/...", exit 13).
    if (err.code === 'EPERM' || err.code === 'EACCES' || /** @type {unknown} */ (err.code) === 13 || /not permitted|sandbox|Cannot write to file/i.test(String(err.stderr ?? err.message))) {
      throw new ImageError(`Could not run sips from inside Claude's sandbox. Run: ${outsideCommand(o.retry ?? 'image add <page> <file>')}`, { code: 'sips-blocked' });
    }
    throw new ImageError(`sips could not convert the image: ${String(err.stderr || err.message).trim().split('\n')[0]}`, { code: 'sips-failed' });
  }
}

/**
 * @typedef {{ maxSide?: number, maxBytes?: number, tmpDir?: string, exec?: ExecFn, retry?: string }} NormaliseOptions
 * @typedef {{ bytes: Buffer, type: 'png' | 'jpg' | 'webp' | 'gif', width: number, height: number, notes: string[] }} NormalisedImage
 */

const TYPE_NAMES = /** @type {Record<string, string>} */ ({ png: 'PNG', jpg: 'JPEG', webp: 'WebP', gif: 'GIF', heic: 'HEIC', tiff: 'TIFF', bmp: 'BMP' });

/** Types stripMetadata can clean; the others (HEIC, TIFF, BMP) go to sips as they are. */
const STRIPPABLE = new Set(['png', 'jpg', 'webp', 'gif']);

/**
 * The sips steps that turn a picture with no orientation tag the way its EXIF orientation
 * says, one sips run per step (sips does not apply -r and -f in a fixed order within one run).
 * `-r` turns clockwise.
 * @type {Record<number, string[][]>}
 */
const ORIENT_STEPS = {
  2: [['-f', 'horizontal']],
  3: [['-r', '180']],
  4: [['-f', 'vertical']],
  5: [['-r', '90'], ['-f', 'horizontal']],
  6: [['-r', '90']],
  7: [['-r', '90'], ['-f', 'vertical']],
  8: [['-r', '270']],
};

const TURNED_NOTE = 'Turned the picture upright (the camera had stored it turned or mirrored).';

/** @param {number} n */
const mb = (n) => `${(n / 1_000_000).toFixed(1)} MB`;

/**
 * Make an image fit the page rules: PNG, JPEG, WebP or GIF, at most `maxSide` pixels per
 * side and `maxBytes` bytes, upright, with metadata removed. Refuses anything over 50
 * million pixels or 25 MB, and GIFs with a frame outside their screen, before decoding.
 * A photo whose orientation tag (JPEG, PNG or WebP EXIF; HEIC irot and imir) says to turn
 * or mirror it is turned with sips first, since stripping removes the tag. Converts HEIC,
 * TIFF and BMP to JPEG and shrinks with sips; keeps PNG when it fits under the limit after
 * shrinking, else JPEG at quality 85, then 75. Metadata is stripped last.
 * @param {Uint8Array} input
 * @param {NormaliseOptions} [opts]
 * @returns {Promise<NormalisedImage>}
 */
export async function normaliseImage(input, opts = {}) {
  const maxSide = opts.maxSide ?? IMAGE_LIMITS.maxSide;
  const maxBytes = opts.maxBytes ?? IMAGE_LIMITS.maxBytes;
  const bytes = Buffer.isBuffer(input) ? input : Buffer.from(input);
  if (bytes.length > MAX_INPUT_BYTES) {
    throw new ImageError(`The image is ${mb(bytes.length)}. Images over 25 MB are not opened. Export a smaller one.`, { status: 413, code: 'too-large' });
  }
  const info = sniffImage(bytes);
  if (!info) {
    const head = bytes.subarray(0, 256).toString('utf8');
    throw new ImageError(/<svg[\s>]/i.test(head)
      ? 'SVG files cannot go in img/. Export it as PNG, or draw the diagram in a ```mermaid block.'
      : 'This is not a PNG, JPEG, WebP or GIF image (HEIC, TIFF and BMP are converted).', { status: 415, code: 'type' });
  }
  const allowedType = /** @type {readonly string[]} */ (ALLOWED_IMAGE_TYPES).includes(info.type);
  if ((info.width === 0 || info.height === 0) && allowedType) {
    throw new ImageError('The image size could not be read from the file, so it is probably damaged. Export it again.', { status: 415, code: 'damaged' });
  }
  if (info.width * info.height > MAX_INPUT_PIXELS) {
    throw new ImageError(`The image is ${info.width} x ${info.height} pixels. Images over 50 million pixels are not opened. Export a smaller one.`, { status: 413, code: 'too-large' });
  }
  if (info.type === 'gif') checkGifFrames(bytes);
  const allowed = /** @type {readonly string[]} */ (ALLOWED_IMAGE_TYPES).includes(info.type);
  const fitsSide = info.width <= maxSide && info.height <= maxSide && info.width > 0 && info.height > 0;
  const orientation = readOrientation(bytes);
  const fits = allowed && fitsSide && bytes.length <= maxBytes;
  /** @type {string[]} */
  const notes = [];
  let removed = false;

  /** @type {{ bytes: Buffer, type: 'png' | 'jpg' | 'webp' | 'gif' }} */
  let result;
  if (fits && orientation === 1) {
    result = { bytes, type: /** @type {'png' | 'jpg' | 'webp' | 'gif'} */ (info.type) };
  } else {
    // PNG, JPEG, WebP and GIF are stripped before sips sees them, so no orientation tag (or
    // anything else) is carried into its output, and the turn is applied explicitly.
    // HEIC, TIFF and BMP go as they are: sips writes their orientation as an EXIF tag in its
    // output, which convertWithSips reads and applies.
    const strippable = STRIPPABLE.has(info.type);
    const src = strippable ? stripMetadata(bytes, info.type) : bytes;
    removed = src.length < bytes.length;
    result = await convertWithSips(src, info, {
      ...opts, maxSide, maxBytes, onlyTurn: fits,
      turn: strippable ? orientation : 1, expect: strippable ? 1 : orientation,
    }, notes);
  }
  const stripped = stripMetadata(result.bytes, result.type);
  if (removed || stripped.length < result.bytes.length) notes.push('Removed metadata (location, camera and text fields).');
  const after = sniffImage(stripped);
  if (!after) throw new ImageError('The converted image could not be read.', { code: 'sips-failed' });
  if (stripped.length > maxBytes) {
    throw new ImageError(`The image is still ${mb(stripped.length)} after shrinking. The limit is ${mb(maxBytes)}. Crop it or export it smaller.`, { status: 413, code: 'too-large' });
  }
  return { bytes: stripped, type: result.type, width: after.width, height: after.height, notes };
}

/**
 * @typedef {NormaliseOptions & { maxSide: number, maxBytes: number, onlyTurn?: boolean, turn?: number, expect?: number }} ConvertOptions
 * `turn`: the orientation to apply to `bytes`, which carry no orientation tag.
 * `expect`: the orientation the source said (HEIC, TIFF), checked against what sips wrote.
 * `onlyTurn`: the image already fits and is converted only to turn it.
 */

/**
 * @param {Buffer} bytes
 * @param {{ type: string, width: number, height: number }} info
 * @param {ConvertOptions} opts
 * @param {string[]} notes
 * @returns {Promise<{ bytes: Buffer, type: 'png' | 'jpg' }>}
 */
async function convertWithSips(bytes, info, opts, notes) {
  const base = opts.tmpDir ?? os.tmpdir();
  fs.mkdirSync(base, { recursive: true });
  const dir = fs.mkdtempSync(path.join(base, 'spage-img-'));
  let runs = 0;
  /** The orientation applied, for the notes. */
  let turned = 1;
  try {
    const src = path.join(dir, `in.${info.type}`);
    fs.writeFileSync(src, bytes);
    if (info.width === 0 || info.height === 0) {
      // The sniffer could not find the size (a TIFF or HEIC laid out differently): ask sips,
      // which reads only the header, and apply the pixel limit before converting.
      const { stdout } = await runSips(['-g', 'pixelWidth', '-g', 'pixelHeight', src], opts);
      const w = Number(/pixelWidth:\s*(\d+)/.exec(stdout)?.[1] ?? 0);
      const h = Number(/pixelHeight:\s*(\d+)/.exec(stdout)?.[1] ?? 0);
      if (!w || !h) throw new ImageError('The image size could not be read, so it is not converted. Export it as PNG or JPEG.', { status: 415, code: 'damaged' });
      if (w * h > MAX_INPUT_PIXELS) {
        throw new ImageError(`The image is ${w} x ${h} pixels. Images over 50 million pixels are not opened. Export a smaller one.`, { status: 413, code: 'too-large' });
      }
      info = { ...info, width: w, height: h };
    }
    const longest = Math.max(info.width, info.height);
    const shrink = longest > opts.maxSide || longest === 0;
    const sideArgs = (/** @type {number} */ side) => (shrink || side < opts.maxSide ? ['--resampleHeightWidthMax', String(side)] : []);
    /** @param {'png' | 'jpg'} type @param {number} [quality] */
    const formatArgs = (type, quality) => ['-s', 'format', type === 'png' ? 'png' : 'jpeg', ...(quality ? ['-s', 'formatOptions', String(quality)] : [])];
    /**
     * Turn picture bytes that carry no orientation tag, one sips run per step.
     * @param {Buffer} data @param {'png' | 'jpg'} type @param {number | undefined} quality @param {string[][]} steps
     */
    const turnSteps = async (data, type, quality, steps) => {
      let cur = data;
      for (const step of steps) {
        const from = path.join(dir, `turn-${++runs}.${type}`);
        const to = path.join(dir, `turn-${runs}-out.${type}`);
        fs.writeFileSync(from, cur);
        await runSips([...formatArgs(type, quality), ...step, from, '--out', to], opts);
        cur = fs.readFileSync(to);
      }
      return cur;
    };
    /**
     * sips writes the orientation of a HEIC or TIFF as an EXIF tag instead of turning the
     * pixels. Apply it, so stripping the tag later does not leave the picture sideways. If
     * sips wrote no tag although the source asked for a quarter turn and the sides are not
     * swapped, sips dropped it: apply the source's orientation.
     * @param {Buffer} data @param {'png' | 'jpg'} type @param {number | undefined} quality
     */
    const upright = async (data, type, quality) => {
      let o = readOrientation(data);
      const expect = opts.expect ?? 1;
      if (o === 1 && SWAPS_SIDES.has(expect)) {
        const s = sniffImage(data);
        if (s && s.width !== s.height && info.width !== info.height && (s.width > s.height) === (info.width > info.height)) o = expect;
      }
      if (o === 1) return data;
      turned = o;
      return turnSteps(stripMetadata(data, type), type, quality, ORIENT_STEPS[o] ?? []);
    };
    /** @param {'png' | 'jpg'} type @param {number} side @param {number} [quality] */
    const attempt = async (type, side, quality) => {
      const out = path.join(dir, `out-${type}-${side}-${quality ?? 0}.${type}`);
      const steps = ORIENT_STEPS[opts.turn ?? 1] ?? [];
      // The first turn goes into the same run as the conversion (shrinking is the same either way round).
      await runSips([...formatArgs(type, quality), ...sideArgs(side), ...(steps[0] ?? []), src, '--out', out], opts);
      let data = fs.readFileSync(out);
      if (steps.length) {
        turned = opts.turn ?? 1;
        data = await turnSteps(data, type, quality, steps.slice(1));
      }
      return upright(data, type, quality);
    };
    const from = TYPE_NAMES[info.type] ?? info.type;
    /** The size before, as the picture shows (sides swapped by a quarter turn). */
    const shown = () => (SWAPS_SIDES.has(turned) ? { width: info.height, height: info.width } : info);
    const finish = () => { if (turned !== 1) notes.push(TURNED_NOTE); };
    if (info.type === 'png' || info.type === 'gif' || (info.type === 'webp' && opts.onlyTurn)) {
      const png = await attempt('png', opts.maxSide);
      if (stripMetadata(png, 'png').length <= opts.maxBytes) {
        finish();
        note(notes, shown(), sniffImage(png), opts.maxSide, info.type === 'gif' ? 'Saved as PNG (a GIF animation keeps only its first frame).'
          : info.type === 'webp' ? 'Saved as PNG from WebP.' : null);
        return { bytes: png, type: 'png' };
      }
    }
    // Turning a JPEG that already fits re-encodes it once, at high quality.
    const jpegSteps = /** @type {Array<[number, number]>} */ (opts.onlyTurn && info.type === 'jpg' ? [[opts.maxSide, 92]] : [])
      .concat([[opts.maxSide, 85], [opts.maxSide, 75], [Math.round(opts.maxSide / 2), 75]]);
    /** @type {Buffer | null} */
    let last = null;
    for (const [side, quality] of jpegSteps) {
      last = await attempt('jpg', side, quality);
      if (stripMetadata(last, 'jpg').length <= opts.maxBytes || side < opts.maxSide) {
        finish();
        const plainTurn = opts.onlyTurn && info.type === 'jpg' && quality === 92;
        note(notes, shown(), sniffImage(last), opts.maxSide, plainTurn ? null : `Saved as JPEG (quality ${quality})${from !== 'JPEG' ? ` from ${from}` : ''} to stay under ${mb(opts.maxBytes)}.`);
        return { bytes: last, type: 'jpg' };
      }
    }
    finish();
    return { bytes: /** @type {Buffer} */ (last), type: 'jpg' };
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

/**
 * @param {string[]} notes
 * @param {{ width: number, height: number }} before
 * @param {{ width: number, height: number } | null} after
 * @param {number} maxSide
 * @param {string | null} extra
 */
function note(notes, before, after, maxSide, extra) {
  if (after && (after.width !== before.width || after.height !== before.height) && before.width > 0) {
    notes.push(`Shrunk from ${before.width} x ${before.height} to ${after.width} x ${after.height} pixels (at most ${maxSide} per side).`);
  }
  if (extra) notes.push(extra);
}

/**
 * A file name part: lowercase letters, digits and hyphens, at most 60 characters.
 * @param {string} s
 */
export function imageSlug(s) {
  const out = String(s ?? '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60).replace(/-+$/, '');
  return out || 'image';
}

const EXT = /** @type {Record<string, string>} */ ({ png: 'png', jpg: 'jpg', webp: 'webp', gif: 'gif' });

/**
 * The state folder for a page folder (`pages/<slug>` -> `pages/.spage`), for temporary files.
 * @param {string} pageDir
 */
function tmpDirFor(pageDir) {
  return path.join(path.dirname(path.resolve(pageDir)), '.spage', 'tmp');
}

/**
 * Add an image to a page: normalise it and write `img/<name>.<ext>` (with -2, -3 when
 * the name is taken). `input` is a file path or the bytes.
 * @param {string} pageDir the page folder (holds index.md)
 * @param {string | Uint8Array} input
 * @param {{ name?: string } & NormaliseOptions} [opts]
 * @returns {Promise<{ file: string, markdown: string, notes: string[], type: string, width: number, height: number }>}
 */
export async function addImage(pageDir, input, opts = {}) {
  /** @type {Buffer} */
  let bytes;
  let fromName = 'image';
  if (typeof input === 'string') {
    let st;
    try {
      st = fs.statSync(input);
    } catch {
      throw new ImageError(`No such file: ${input}`, { status: 400, code: 'missing' });
    }
    if (!st.isFile()) throw new ImageError(`${input} is not a file.`, { status: 400, code: 'missing' });
    if (st.size > MAX_INPUT_BYTES) {
      throw new ImageError(`The image is ${mb(st.size)}. Images over 25 MB are not opened. Export a smaller one.`, { status: 413, code: 'too-large' });
    }
    bytes = fs.readFileSync(input);
    fromName = path.basename(input).replace(/\.[^.]*$/, '');
  } else {
    bytes = Buffer.isBuffer(input) ? input : Buffer.from(input);
  }
  const img = path.join(pageDir, 'img');
  try {
    if (fs.lstatSync(img).isSymbolicLink()) throw new ImageError('The img/ folder is a symbolic link. Make it a real folder.', { code: 'img-link' });
  } catch (e) {
    if (e instanceof ImageError) throw e;
  }
  const normal = await normaliseImage(bytes, { tmpDir: tmpDirFor(pageDir), ...opts });
  fs.mkdirSync(img, { recursive: true });
  const base = imageSlug(opts.name ?? fromName);
  const ext = EXT[normal.type];
  for (let n = 1; n < 1000; n++) {
    const file = `${base}${n === 1 ? '' : `-${n}`}.${ext}`;
    try {
      fs.writeFileSync(path.join(img, file), normal.bytes, { flag: 'wx' });
      return { file, markdown: `![Describe the image](img/${file})`, notes: normal.notes, type: normal.type, width: normal.width, height: normal.height };
    } catch (e) {
      if (/** @type {NodeJS.ErrnoException} */ (e).code !== 'EEXIST') throw e;
    }
  }
  throw new ImageError(`Too many images named ${base} in img/. Pick another name.`, { code: 'name' });
}

/** JXA: the clipboard's PNG (or else TIFF) data as base64, or "none". */
const CLIPBOARD_SCRIPT = [
  "ObjC.import('AppKit');",
  'const pb = $.NSPasteboard.generalPasteboard;',
  'let data = pb.dataForType($.NSPasteboardTypePNG);',
  'if (data.isNil()) data = pb.dataForType($.NSPasteboardTypeTIFF);',
  "data.isNil() ? 'none' : data.base64EncodedStringWithOptions(0).js;",
].join('\n');

/**
 * The image on the macOS clipboard (PNG, else TIFF), or null when it holds no image.
 * @param {{ exec?: ExecFn, page?: string }} [opts] `page` names the page in the sandbox message
 * @returns {Promise<Buffer | null>}
 */
export async function readClipboardImage(opts = {}) {
  const exec = opts.exec ?? execFileAsync;
  let stdout;
  try {
    ({ stdout } = await exec(OSASCRIPT, ['-l', 'JavaScript', '-e', CLIPBOARD_SCRIPT], { timeout: 10_000, maxBuffer: 64 * 1024 * 1024 }));
  } catch (e) {
    if (/** @type {NodeJS.ErrnoException} */ (e).code === 'ENOENT') {
      throw new ImageError('Reading the clipboard needs macOS (osascript was not found). Save the image as a file and run spage image add instead.', { code: 'clipboard-missing' });
    }
    throw new ImageError(`Could not read the clipboard from inside Claude's sandbox. Run: ${outsideCommand(`image paste ${opts.page ?? '<page>'}`)}`, { code: 'clipboard-blocked' });
  }
  const text = String(stdout).trim();
  if (!text || text === 'none') return null;
  if (!/^[A-Za-z0-9+/=\s]+$/.test(text)) return null;
  const bytes = Buffer.from(text, 'base64');
  return bytes.length ? bytes : null;
}

/** Content types the mirror's upload route takes. */
export const UPLOAD_TYPES = Object.freeze(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);

/**
 * Save an image dropped or pasted into the mirror, and note it in `pages/.spage/inbox.jsonl`
 * so the user-prompt-submit hook tells Claude about it on the next message.
 * @param {string} root the folder that holds pages/
 * @param {string} slug
 * @param {Uint8Array} bytes
 * @param {{ contentType?: string, name?: string, now?: () => Date } & NormaliseOptions} [opts]
 * @returns {Promise<{ file: string, markdown: string, notes: string[] }>}
 */
export async function saveUpload(root, slug, bytes, opts = {}) {
  if (!isSlug(slug)) throw new ImageError('That is not a page name.', { status: 400, code: 'no-page' });
  if (opts.contentType !== undefined && !UPLOAD_TYPES.includes(String(opts.contentType).split(';')[0].trim().toLowerCase())) {
    throw new ImageError('Only PNG, JPEG, WebP and GIF images can be added.', { status: 415, code: 'type' });
  }
  const pageDir = path.join(pagesDir(root), slug);
  let real = false;
  try {
    const st = fs.lstatSync(pageDir);
    real = st.isDirectory() && !st.isSymbolicLink() && fs.realpathSync(pageDir) === path.join(fs.realpathSync(pagesDir(root)), slug);
  } catch {
    real = false;
  }
  if (!real) throw new ImageError(`No page "${slug}" under pages/.`, { status: 400, code: 'no-page' });
  const info = sniffImage(bytes);
  if (!info || !/** @type {readonly string[]} */ (ALLOWED_IMAGE_TYPES).includes(info.type)) {
    throw new ImageError('This is not a PNG, JPEG, WebP or GIF image.', { status: 415, code: 'type' });
  }
  const saved = await addImage(pageDir, bytes, {
    ...opts, name: opts.name ? opts.name.replace(/\.[A-Za-z0-9]{1,5}$/, '') : 'pasted-image',
    retry: `image add pages/${slug} <file>`,
  });
  const at = (opts.now ? opts.now() : new Date()).toISOString();
  try {
    fs.mkdirSync(stateDir(root), { recursive: true });
    fs.appendFileSync(path.join(stateDir(root), 'inbox.jsonl'), `${JSON.stringify({ slug, file: saved.file, at })}\n`);
  } catch {
    // the inbox only helps Claude notice the image; the image itself is saved
  }
  return { file: saved.file, markdown: saved.markdown, notes: saved.notes };
}
