// @ts-check
/**
 * `spage publish prepare|record` and `spage fonts fetch` (CONTRACTS.md 12.1). There is no
 * put step: the publish guard uploads each file itself after pages_upload_begin (12.2).
 * The integrator wires these into cli.js:
 *   case 'publish': return publishCommand(rest, ctx);
 *   case 'fonts':   return fontsCommand(rest, ctx);
 */
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { loadFormat, loadRenderer } from '../deps.js';
import { resolvePageArg } from '../pages.js';
import { safeTerminalText } from '../text.js';
import { formatBytes } from './bundle.js';
import { preparePage, uploadPlan } from './prepare.js';
import { recordPublished } from './record.js';

export { fontsCommand, fetchFonts, cachedFonts, fontMagicOk } from './fonts.js';
export { preparePage, uploadPlan, checkPublishedHtml } from './prepare.js';
export { putBytes, checkUploadUrl, UPLOAD_HOSTS } from './put.js';
export { recordPublished, setPublishedField } from './record.js';
export {
  verifyBundle, readManifest, findManifests, manifestProblem, bundleHashOf, sha256, sriSha384,
  MANIFEST_MAX_AGE_MS, bundleDir, manifestPath, readCurrent, currentPath,
} from './bundle.js';

/** The spage entry script, as the upload plan prints it in the record step. */
export const SPAGE_BIN = fileURLToPath(new URL('../../bin/spage.js', import.meta.url));

export const PUBLISH_USAGE = `Usage:
  spage publish prepare <page> [--project NAME] [--json]
  spage publish record <page>
  spage fonts fetch
`;

/**
 * @typedef {{
 *   io: { stdout: { write: (s: string) => unknown }, stderr: { write: (s: string) => unknown } },
 *   cwd?: string,
 *   env?: Record<string, string | undefined>,
 *   now?: () => Date,
 *   homedir?: string,
 *   getFormat?: () => Promise<import('../deps.js').FormatApi>,
 *   getRenderer?: () => Promise<any>,
 *   fetch?: typeof globalThis.fetch,
 *   loadImages?: () => Promise<import('./prepare.js').ImagesApi | null>,
 *   bin?: string,
 * }} PublishContext
 */

class UsageError extends Error {}

/**
 * @param {string[]} args
 * @param {Record<string, { type: 'string' | 'boolean' }>} options
 */
function parse(args, options) {
  return /** @type {{ values: Record<string, any>, positionals: string[] }} */ (parseArgs({ args, options, allowPositionals: true, strict: true }));
}

/**
 * `spage publish <sub> ...`. argv is everything after "publish".
 * Exit codes: 0 done, 1 usage or upload error, 2 refused (checks failed).
 * @param {string[]} argv
 * @param {PublishContext} ctx
 * @returns {Promise<number>}
 */
export async function publishCommand(argv, ctx) {
  const io = ctx.io;
  const cwd = ctx.cwd ?? process.cwd();
  const [sub, ...rest] = argv;
  try {
    if (sub === 'prepare') {
      const { values, positionals } = parse(rest, { project: { type: 'string' }, json: { type: 'boolean' } });
      if (positionals.length !== 1) throw new UsageError('Give one page: a page folder or its index.md.');
      const result = await preparePage({
        pageArg: positionals[0],
        cwd,
        ...(values.project !== undefined ? { project: values.project } : {}),
        ...(ctx.now ? { now: ctx.now } : {}),
        homedir: ctx.homedir ?? os.homedir(),
        getFormat: ctx.getFormat ?? loadFormat,
        getRenderer: ctx.getRenderer ?? loadRenderer,
        ...(ctx.loadImages ? { loadImages: ctx.loadImages } : {}),
      });
      if (!result.ok) {
        if (values.json) io.stdout.write(JSON.stringify({ ok: false, reasons: result.reasons }, null, 2) + '\n');
        io.stderr.write(`Not prepared.\n${result.reasons.join('\n')}\n`);
        return 2;
      }
      const pageDir = resolvePageArg(positionals[0], cwd).dir;
      const plan = uploadPlan({ manifest: result.manifest, pageDir, bin: ctx.bin ?? SPAGE_BIN });
      const m = result.manifest;
      if (values.json) {
        io.stdout.write(JSON.stringify({
          ok: true, slug: m.slug, project: m.project, bundle: result.dir, files: m.files.length, totalSize: result.totalSize,
          notes: result.notes, steps: plan.steps, record: plan.record,
        }, null, 2) + '\n');
        return 0;
      }
      io.stdout.write(`${safeTerminalText(`Prepared "${m.title}" (${m.type}, ${m.status}) for Stark Pages project "${m.project}": ${m.files.length} files, ${formatBytes(result.totalSize)}. Secret scan clean.`)}\n`);
      for (const n of result.notes) io.stdout.write(`${safeTerminalText(n)}\n`);
      io.stdout.write(`The bundle is good for 30 minutes.\n\n${plan.text}\n`);
      return 0;
    }

    if (sub === 'record') {
      const { values, positionals } = parse(rest, { url: { type: 'string' } });
      if (positionals.length !== 1) throw new UsageError('record needs a page: a page folder or its index.md.');
      const r = await recordPublished({
        pageArg: positionals[0], cwd, getFormat: ctx.getFormat ?? loadFormat, homedir: ctx.homedir ?? os.homedir(),
        ...(values.url !== undefined ? { url: values.url } : {}),
        ...(ctx.now ? { now: ctx.now } : {}),
      });
      if (!r.ok) {
        io.stderr.write(`${safeTerminalText(r.reason)}\n`);
        return r.code;
      }
      io.stdout.write(`Recorded in ${safeTerminalText(path.relative(cwd, r.file) || r.file)}.\n${safeTerminalText(r.url)}\n`);
      return 0;
    }
    throw new UsageError(sub ? `Unknown publish step "${sub}".` : 'Missing publish step.');
  } catch (e) {
    const usage = e instanceof UsageError || (e && typeof e === 'object' && 'code' in e && String(/** @type {any} */ (e).code).startsWith('ERR_PARSE_ARGS'));
    if (usage) {
      io.stderr.write(`${safeTerminalText(e instanceof Error ? e.message : String(e))}\n\n${PUBLISH_USAGE}`);
      return 1;
    }
    io.stderr.write(`spage publish: ${safeTerminalText(e instanceof Error ? e.message : String(e))}\n`);
    return 1;
  }
}
