// @ts-check
/**
 * `spage hook user-prompt-submit` (CONTRACTS.md 13.3): tell Claude about images the
 * user dropped or pasted into the mirror since the last message.
 *
 * The mirror appends `{ slug, file, at }` lines to `pages/.spage/inbox.jsonl`. This hook
 * reads the lines after `pages/.spage/inbox.cursor` (a byte offset), prints one
 * `additionalContext` note, and moves the cursor. The inbox file itself is never
 * rewritten, so an upload that lands while the hook runs is not lost.
 */
import fs from 'node:fs';
import path from 'node:path';
import { readStdin } from './hook.js';
import { isSlug, pagesDir, stateDir } from './pages.js';

/** At most this much new inbox text is read per prompt. */
const MAX_READ = 256 * 1024;
const MAX_ENTRIES = 40;
const FILE_RE = /^[a-z0-9][a-z0-9-]{0,80}\.(png|jpg|webp|gif)$/;

/**
 * @typedef {{
 *   io: { stdout: { write: (s: string) => unknown }, stderr?: { write: (s: string) => unknown }, stdin?: NodeJS.ReadableStream & { isTTY?: boolean } },
 *   env: Record<string, string | undefined>,
 *   cwd: string,
 *   now?: () => Date,
 * }} InboxContext
 * @typedef {{ slug: string, file: string, at: string }} InboxEntry
 */

/** @param {string} raw */
function parsePayload(raw) {
  if (!raw || !raw.trim()) return null;
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
  } catch {
    return null;
  }
}

/** @param {string} root */
function cursorFile(root) {
  return path.join(stateDir(root), 'inbox.cursor');
}

/** @param {string} root */
function readCursor(root) {
  try {
    const n = Number(JSON.parse(fs.readFileSync(cursorFile(root), 'utf8')).offset);
    return Number.isInteger(n) && n >= 0 ? n : 0;
  } catch {
    return 0;
  }
}

/** @param {string} root @param {number} offset */
function writeCursor(root, offset) {
  const file = cursorFile(root);
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify({ offset })}\n`);
  fs.renameSync(tmp, file);
}

/**
 * Entries added since the cursor, and the offset after the last complete line.
 * @param {string} root
 * @returns {{ entries: InboxEntry[], next: number } | null} null when there is no inbox
 */
export function readInbox(root) {
  const file = path.join(stateDir(root), 'inbox.jsonl');
  let st;
  try {
    st = fs.lstatSync(file);
  } catch {
    return null;
  }
  if (!st.isFile()) return null;
  let start = readCursor(root);
  if (start > st.size) start = 0; // the inbox was cleared: start again
  if (start === st.size) return { entries: [], next: start };
  const len = Math.min(st.size - start, MAX_READ);
  const buf = Buffer.alloc(len);
  const fd = fs.openSync(file, 'r');
  try {
    fs.readSync(fd, buf, 0, len, start);
  } finally {
    fs.closeSync(fd);
  }
  const lastNewline = buf.lastIndexOf(0x0a);
  if (lastNewline === -1) {
    // One huge or unfinished line: skip it when it is over the read limit, else wait for its end.
    return { entries: [], next: len === MAX_READ ? start + len : start };
  }
  /** @type {InboxEntry[]} */
  const entries = [];
  for (const line of buf.subarray(0, lastNewline).toString('utf8').split('\n')) {
    let v;
    try { v = JSON.parse(line); } catch { continue; }
    if (!v || typeof v !== 'object') continue;
    if (!isSlug(v.slug) || typeof v.file !== 'string' || !FILE_RE.test(v.file)) continue;
    const at = typeof v.at === 'string' && !Number.isNaN(Date.parse(v.at)) ? v.at : new Date(0).toISOString();
    entries.push({ slug: v.slug, file: v.file, at });
  }
  return { entries, next: start + lastNewline + 1 };
}

/**
 * The note for Claude, or '' when there is nothing new.
 * @param {string} root
 * @param {InboxEntry[]} entries
 */
export function inboxNote(root, entries) {
  /** @type {Map<string, InboxEntry[]>} */
  const bySlug = new Map();
  const seen = new Set();
  for (const e of entries) {
    const key = `${e.slug}/${e.file}`;
    if (seen.has(key)) continue;
    // Only images that are still there.
    try {
      const st = fs.lstatSync(path.join(pagesDir(root), e.slug, 'img', e.file));
      if (!st.isFile()) continue;
    } catch {
      continue;
    }
    seen.add(key);
    if (seen.size > MAX_ENTRIES) break;
    const list = bySlug.get(e.slug) ?? [];
    list.push(e);
    bySlug.set(e.slug, list);
  }
  if (bySlug.size === 0) return '';
  // Only facts the user saw in the mirror (it shows every upload): the page and the
  // cleaned file names. No instructions: any local program can use the upload route.
  return [...bySlug].map(([slug, list]) => {
    const n = list.length;
    return `${n} image${n === 1 ? ' was' : 's were'} added to page ${slug} from the mirror: ${list.map((e) => `img/${e.file}`).join(', ')}`;
  }).join('\n');
}

/**
 * The UserPromptSubmit hook body. Prints `hookSpecificOutput.additionalContext` when
 * images arrived since the last prompt, and nothing otherwise. Always exits 0.
 * @param {InboxContext} ctx
 * @returns {Promise<number>}
 */
export async function hookUserPromptSubmit(ctx) {
  try {
    const payload = parsePayload(await readStdin(ctx.io.stdin, { timeoutMs: 500 }));
    const fromPayload = payload && typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : null;
    const root = path.resolve(ctx.env.CLAUDE_PROJECT_DIR || fromPayload || ctx.cwd);
    const inbox = readInbox(root);
    if (!inbox || inbox.next === readCursor(root)) return 0;
    const note = inboxNote(root, inbox.entries);
    writeCursor(root, inbox.next);
    if (note) {
      ctx.io.stdout.write(`${JSON.stringify({ hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: note } })}\n`);
    }
    return 0;
  } catch {
    return 0;
  }
}
