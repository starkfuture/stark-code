---
schema: 1
type: report
title: Are people leaving the terminal?
owner: magomet
status: current
verified: 2026-10-13
reviewBy: null
sources:
  - agent_workspace/research/terminal-vs-app-2026-10/practitioners.md
  - agent_workspace/research/terminal-vs-app-2026-10/vendors.md
  - agent_workspace/research/terminal-vs-app-2026-10/enterprise.md
  - agent_workspace/prototypes/stark-app/plan/SYNTHESIS.md
supersedes: null
id: terminal-or-app
created: "2026-10-14T12:00:00Z"
author: claude
---

Where developers watch and steer coding agents in October 2026.

## Bottom line

Partly, and only at the frontier. In 2026 nearly every major vendor shipped a desktop agent manager and some well-known developers left terminal tabs, but no survey measures where developers run agents. The terminal stays as the engine: CLI downloads kept rising and most new apps wrap the same CLIs.

## Findings

```findings
- claim: Between February and June 2026 nearly every major vendor shipped a desktop agent manager, from the Codex app (Feb 2) to the GitHub Copilot app (generally available Jun 17).
  confidence: high
  sources: [vendors.md section 1]
- claim: No 2026 survey measures where developers run agents. Stack Overflow (Oct 6) and JetBrains (May to July) measure tools only.
  confidence: high
  sources: [practitioners.md sections 1 and 5]
- claim: The measured shift is from the IDE to agent harnesses. At work, Claude Code went from 18% to 39% of developers and Codex from 3% to 16% between January and May to July 2026.
  confidence: high
  sources: [practitioners.md section 2, JetBrains surveys]
- claim: The terminal is not dying as a runtime. CLI npm downloads kept rising through September 2026, and most new desktop apps wrap the same CLI harnesses.
  confidence: high
  sources: [practitioners.md section 1, vendors.md section 3]
- claim: Only OpenAI has ranked its surfaces. It says the Codex app became its most used surface, ahead of the VS Code extension and the CLI, in one post with no numbers.
  confidence: medium
  sources: [vendors.md section 1]
- claim: The loudest voices on both sides mostly build or sell the tool they praise. Independent switchers are few and not representative.
  confidence: medium
  sources: [practitioners.md section 5]
- claim: Many-agent work has a cognitive ceiling. Willison is "wiped out" by 11 AM with about four agents, and Hashimoto runs one agent at a time.
  confidence: medium
  sources: [practitioners.md sections 3 and 5]
- claim: Non-developers delegate from apps and chat, not the terminal. Only 8.7% of 1.2M sampled Cowork sessions were software development.
  confidence: medium
  sources: [enterprise.md section 1]
- claim: The deliverable is moving from chat text to typed outputs such as documents, decks, dashboards and pages, with chat as the steering channel.
  confidence: high
  sources: [enterprise.md section 1, SYNTHESIS.md section 1a]
```

## Evidence

**Desktop agent managers shipped in 2026** (vendors.md, section 1):

| Product | Date |
|---|---|
| Codex app | 2026-02-02 |
| JetBrains Air | 2026-03-09 |
| Cursor 3 Agents Window | 2026-04-02 |
| Claude Code desktop redesign | 2026-04-14 |
| VS Code Agents window | 2026-05-13 |
| Antigravity 2.0 | 2026-05-19 |
| Devin Desktop | 2026-06-02 |
| GitHub Copilot app (generally available) | 2026-06-17 |

**Tool use at work, JetBrains surveys** (practitioners.md, section 2). These measure tools, not where they run:

| Tool | January 2026 | May to July 2026 |
|---|---|---|
| Claude Code | 18% | 39% |
| Codex | 3% | 16% |
| Cursor | 18% | 12% |
| GitHub Copilot | 29% | 21% |

**The terminal as engine:**
- CLI npm downloads kept rising through September 2026: Claude Code about 56M a month, Codex about 90M, OpenCode about 10M (practitioners.md, section 1). These figures include CI, bots and wrapper installs (section 5).
- The CLIs added their own agent dashboards: `claude agents` in May and `codex agents` in August (practitioners.md, section 1).
- Copilot CLI usage was "nearly doubling month-over-month" (Nadella, 2026-04-29; vendors.md, section 2c).
- 69% of developers who review agent code do it in an IDE or code editor, the only survey number close to the question (practitioners.md, section 2).

**Who says they left, and who stayed** (practitioners.md, section 3):
- Left: Theo Browne (builds T3 Code) left a tmux setup of about 30 sessions (per episode summaries) for GUI agent managers. McKay Wrigley switched to the Claude Code desktop app on 2026-04-24.
- Stayed: Mitchell Hashimoto built a terminal multiplexer for long-lived sessions. DHH ships agent CLIs as Omarchy defaults.

**Non-developers** (enterprise.md, section 1): about 20% of OpenAI's 5M+ weekly Codex users are knowledge workers, and only 8.7% of 1.2M sampled Cowork sessions were software development. Both numbers are self-reported by the vendors.

## Open questions

- Where do developers actually run agents? No 2026 survey asks. JetBrains says more findings and anonymized raw data are coming, which could allow such a cut (practitioners.md, section 5).
- Is many-agent management a niche? About 31% of developers are "agentic coders" in JetBrains' data, and 26.2% use agents or automated workflows at work in Stack Overflow's (practitioners.md, section 5).
- Will app quality hold people? Reports of desktop app bugs and sluggishness are unverified beyond secondary summaries (practitioners.md, section 5).
- Do typed outputs stick? None of the new document, dashboard or page products has published usage or retention data (enterprise.md, section 5).

## Next steps

- Re-check when GitHub Octoverse 2026 is out, expected around 2026-10-28 (practitioners.md, section 2).
- Re-check when JetBrains publishes its raw survey data, for a split by surface.
- Keep the Stark layer thin and specific (Stark design, sources and ownership, Stark Pages as the record), because vendors will keep shipping generic typed outputs (SYNTHESIS.md, section 1a).
