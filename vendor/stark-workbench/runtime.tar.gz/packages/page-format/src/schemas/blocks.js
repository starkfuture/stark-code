// @ts-check
import { CONFIDENCE } from '../constants.js';

const STRING_LIST = { type: 'array', items: { type: 'string' } };

/** JSON Schema (2020-12) for an `options` block (decision pages). */
export const OPTIONS_SCHEMA = Object.freeze({
  $schema: 'https://json-schema.org/draft/2020-12/schema',
  $id: 'https://stark.local/schemas/options-block.json',
  title: 'Options block',
  type: 'array',
  minItems: 2,
  maxItems: 6,
  items: {
    type: 'object',
    required: ['name'],
    additionalProperties: false,
    properties: {
      name: { type: 'string', minLength: 1, maxLength: 80 },
      chosen: { type: 'boolean' },
      pros: STRING_LIST,
      cons: STRING_LIST,
      cost: { type: 'string', maxLength: 80 },
    },
  },
});

/** JSON Schema (2020-12) for a `findings` block (report pages). */
export const FINDINGS_SCHEMA = Object.freeze({
  $schema: 'https://json-schema.org/draft/2020-12/schema',
  $id: 'https://stark.local/schemas/findings-block.json',
  title: 'Findings block',
  type: 'array',
  minItems: 1,
  maxItems: 20,
  items: {
    type: 'object',
    required: ['claim', 'confidence'],
    additionalProperties: false,
    properties: {
      claim: { type: 'string', minLength: 1, maxLength: 400 },
      confidence: { type: 'string', enum: [...CONFIDENCE] },
      sources: STRING_LIST,
    },
  },
});

/** @type {Readonly<Record<string, object>>} */
export const BLOCK_SCHEMAS = Object.freeze({ options: OPTIONS_SCHEMA, findings: FINDINGS_SCHEMA });
