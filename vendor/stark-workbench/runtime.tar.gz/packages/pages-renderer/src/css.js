// @ts-check
// The Stark page stylesheet. Values follow the Stark design system
// (colors_and_type.css): black, white and greys, the red only as punctuation,
// Stark Sans uppercase headings, Universal Sans body, Fragment Mono for ids.
// Every rule is scoped under .sp-page or .sp-root so the CSS can sit inside a host page.

const FONT_BASE = 'https://assets.starkfuture.com/frontend-assets/fonts';

const FONTS = `
@font-face { font-family:'Stark Sans'; font-weight:400; font-style:normal; font-display:swap; src:url('${FONT_BASE}/stark-sans/StarkSans-Regular.otf') format('opentype'); }
@font-face { font-family:'Stark Sans'; font-weight:500; font-style:normal; font-display:swap; src:url('${FONT_BASE}/stark-sans/StarkSans-Medium.otf') format('opentype'); }
@font-face { font-family:'Universal Sans'; font-weight:400; font-style:normal; font-display:swap; src:url('${FONT_BASE}/universal-sans/Universal-Sans-Display-400.woff2') format('woff2'); }
@font-face { font-family:'Universal Sans'; font-weight:500; font-style:normal; font-display:swap; src:url('${FONT_BASE}/universal-sans/Universal-Sans-Display-500.woff2') format('woff2'); }
@font-face { font-family:'Fragment Mono'; font-weight:400; font-style:normal; font-display:swap; src:url('${FONT_BASE}/fragment-mono/FragmentMono-latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }
`;

// Dark is the default Stark mode.
const DARK = `
  color-scheme: dark;
  --sp-bg: #000000;
  --sp-sunken: #0A0A0A;
  --sp-text: #FFFFFF;
  --sp-text-2: #949494;
  --sp-text-3: #666666;
  --sp-line: #3D3D3D;
  --sp-line-2: #666666;
  --sp-line-strong: #FFFFFF;
  --sp-solid-bg: #FFFFFF;
  --sp-solid-fg: #000000;
  --sp-red: #FF1717;
`;

const LIGHT = `
  color-scheme: light;
  --sp-bg: #FFFFFF;
  --sp-sunken: #F5F5F5;
  --sp-text: #000000;
  --sp-text-2: #666666;
  --sp-text-3: #949494;
  --sp-line: #E5E5E5;
  --sp-line-2: #949494;
  --sp-line-strong: #000000;
  --sp-solid-bg: #000000;
  --sp-solid-fg: #FFFFFF;
  --sp-red: #EF1515;
`;

// Host theme: inherit the host's text and background; greys are mixed from the text colour.
const HOST = `
  --sp-bg: transparent;
  --sp-sunken: color-mix(in srgb, currentColor 5%, transparent);
  --sp-text: currentColor;
  --sp-text-2: color-mix(in srgb, currentColor 66%, transparent);
  --sp-text-3: color-mix(in srgb, currentColor 45%, transparent);
  --sp-line: color-mix(in srgb, currentColor 16%, transparent);
  --sp-line-2: color-mix(in srgb, currentColor 40%, transparent);
  --sp-line-strong: currentColor;
  --sp-solid-bg: transparent;
  --sp-solid-fg: currentColor;
  --sp-red: #EF1515;
`;

const RULES = `
.sp-theme-stark { ${DARK} }
@media (prefers-color-scheme: light) { .sp-theme-stark { ${LIGHT} } }
@media print { .sp-theme-stark { ${LIGHT} } }
.sp-theme-host { ${HOST} color: inherit; }

.sp-root, .sp-root body { margin: 0; padding: 0; background: var(--sp-bg); color: var(--sp-text); }

.sp-page {
  --sp-font-display: 'Stark Sans', system-ui, -apple-system, 'Segoe UI', sans-serif;
  --sp-font-sans: 'Universal Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  --sp-font-mono: 'Fragment Mono', ui-monospace, 'SF Mono', Menlo, Consolas, monospace;
  box-sizing: border-box;
  max-width: 76rem;
  margin: 0 auto;
  padding: 1.5rem 1rem 4rem;
  background: var(--sp-bg);
  color: var(--sp-text);
  font-family: var(--sp-font-sans);
  font-size: 0.9375rem;
  font-weight: 400;
  line-height: 1.55;
  letter-spacing: 0.01em;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  overflow-wrap: break-word;
  text-size-adjust: 100%;
}
.sp-page *, .sp-page *::before, .sp-page *::after { box-sizing: border-box; }
@media (min-width: 768px) { .sp-page { padding: 3.5rem 3.5rem 6rem; font-size: 1rem; } }

/* Type */
.sp-page :where(h1, h2, h3, h4, h5, h6) {
  font-family: var(--sp-font-display);
  font-weight: 500;
  text-transform: uppercase;
  color: var(--sp-text);
  margin: 0;
}
.sp-page :where(p) { margin: 0 0 1em; }
.sp-page :where(a) { color: inherit; text-decoration: underline; text-decoration-color: var(--sp-line-2); text-underline-offset: 0.2em; text-decoration-thickness: 1px; }
.sp-page :where(a):hover { text-decoration-color: currentColor; }
.sp-page :where(a):focus-visible { outline: 3px solid var(--sp-line-2); outline-offset: 2px; border-radius: 2px; }
.sp-page :where(strong) { font-weight: 500; }
.sp-page :where(code), .sp-id { font-family: var(--sp-font-mono); font-size: 0.875em; letter-spacing: 0; }
.sp-page :where(:not(pre) > code) { padding: 0.1em 0.35em; border: 1px solid var(--sp-line); border-radius: 0.25rem; }
.sp-label {
  display: block;
  margin: 0 0 0.5rem;
  font-family: var(--sp-font-display);
  font-weight: 500;
  font-size: 0.625rem;
  line-height: 1.4;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--sp-text-2);
}

/* Grid: header, body, then facts on narrow screens (bottom line first); facts move to a right column on wide screens. */
.sp-grid { display: grid; grid-template-columns: minmax(0, 1fr); grid-template-areas: "head" "body" "facts"; column-gap: 4rem; }
.sp-head { grid-area: head; }
.sp-facts { grid-area: facts; }
.sp-body { grid-area: body; min-width: 0; }
@media (min-width: 1024px) {
  .sp-grid { grid-template-columns: minmax(0, 1fr) 15rem; grid-template-areas: "head facts" "body facts"; }
  .sp-facts { align-self: start; padding-top: 0.25rem; }
}

/* Header */
.sp-head { padding-bottom: 2.5rem; }
.sp-eyebrow { display: flex; flex-wrap: wrap; align-items: center; gap: 0.75rem; margin: 0 0 1.25rem; }
.sp-eyebrow__text {
  display: inline-flex; align-items: center; gap: 0.625rem;
  font-family: var(--sp-font-display); font-weight: 500; font-size: 0.6875rem;
  letter-spacing: 0.14em; text-transform: uppercase; color: var(--sp-text-2);
}
.sp-mark { display: inline-block; width: 0.5rem; height: 0.5rem; background: var(--sp-red); flex: none; }
/* Design system h1: 20 to 24px Stark Sans Medium with wide tracking (32px and up would have to go Light). */
.sp-title { font-size: 1.25rem; line-height: 1.2; letter-spacing: 0.1em; overflow-wrap: anywhere; max-width: 46rem; }
@media (min-width: 768px) { .sp-title { font-size: 1.5rem; } }
.sp-subtitle { margin: 1rem 0 0; max-width: 42rem; font-size: 1.0625rem; line-height: 1.5; color: var(--sp-text-2); }
@media (min-width: 768px) { .sp-subtitle { font-size: 1.1875rem; } }

/* Pills */
.sp-pill {
  display: inline-flex; align-items: center; justify-content: center; flex: none;
  min-height: 1.375rem; padding: 0.125rem 0.625rem;
  border: 1px solid var(--sp-line-2); border-radius: 9999px;
  font-family: var(--sp-font-display); font-weight: 500; font-size: 0.625rem; line-height: 1;
  letter-spacing: 0.1em; text-transform: uppercase; color: var(--sp-text); white-space: nowrap;
}
.sp-pill--solid { background: var(--sp-solid-bg); color: var(--sp-solid-fg); border-color: var(--sp-line-strong); }
.sp-pill--muted { color: var(--sp-text-2); border-style: dashed; }

/* Notices and banners */
.sp-notice { margin: 0 0 2rem; padding: 1.25rem 1.5rem; border: 1px solid var(--sp-red); border-radius: 0.75rem; }
.sp-notice__title { margin: 0 0 0.25rem; font-family: var(--sp-font-display); font-weight: 500; font-size: 0.875rem; letter-spacing: 0.08em; text-transform: uppercase; }
.sp-notice__intro { color: var(--sp-text-2); font-size: 0.875rem; }
.sp-notice ul { list-style: none; margin: 0.75rem 0 0; padding: 0; }
.sp-notice li { display: grid; grid-template-columns: 4.5rem minmax(0, 1fr); gap: 0.25rem 0.75rem; padding: 0.625rem 0; border-top: 1px solid var(--sp-line); font-size: 0.875rem; }
.sp-notice__line { color: var(--sp-text-2); font-family: var(--sp-font-mono); font-size: 0.8125rem; }
.sp-notice__hint { display: block; color: var(--sp-text-2); }
.sp-notice__code { color: var(--sp-text-3); font-family: var(--sp-font-mono); font-size: 0.75rem; }
.sp-banners { display: grid; gap: 0.75rem; margin-top: 2rem; }
.sp-banner { display: flex; flex-wrap: wrap; align-items: baseline; gap: 0.25rem 0.75rem; margin: 0; padding: 0.75rem 1rem; border: 1px solid var(--sp-line-2); border-radius: 0.5rem; font-size: 0.875rem; }
.sp-banner--illustrative { border-style: dashed; color: var(--sp-text-2); }
.sp-banner .sp-label { display: inline; margin: 0; color: var(--sp-text); }

/* Facts column */
.sp-facts { margin: 2.5rem 0 0; padding: 0; font-size: 0.875rem; }
.sp-fact { display: grid; grid-template-columns: 7rem minmax(0, 1fr); gap: 0.75rem; padding: 0.625rem 0; border-top: 1px solid var(--sp-line); }
.sp-fact:last-child { border-bottom: 1px solid var(--sp-line); }
.sp-fact dt { margin: 0; padding-top: 0.2rem; font-family: var(--sp-font-display); font-weight: 500; font-size: 0.625rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--sp-text-2); }
.sp-fact dd { margin: 0; min-width: 0; overflow-wrap: anywhere; font-variant-numeric: tabular-nums; }
.sp-fact dd ul { list-style: none; margin: 0; padding: 0; }
.sp-fact dd li + li { margin-top: 0.375rem; }
.sp-muted { color: var(--sp-text-2); }
@media (min-width: 1024px) {
  .sp-facts { margin: 0; }
  .sp-fact { grid-template-columns: minmax(0, 1fr); gap: 0.25rem; padding: 0.875rem 0; }
}

/* Sections */
.sp-section { padding: 2.25rem 0 0.5rem; border-top: 1px solid var(--sp-line); scroll-margin-top: 1.5rem; }
.sp-section > h2 { margin: 0 0 1.25rem; font-size: 0.875rem; line-height: 1.4; letter-spacing: 0.1em; }
@media (min-width: 768px) { .sp-section > h2 { font-size: 1rem; letter-spacing: 0.1em; } }
.sp-prose > :where(p, ul:not(.sp-options), ol:not(.sp-findings), blockquote, h3, h4, h5, h6, .sp-pending, .sp-img-blocked) { max-width: 44rem; }
.sp-prose h3 { margin: 1.75rem 0 0.75rem; font-size: 0.8125rem; letter-spacing: 0.08em; }
.sp-prose h4, .sp-prose h5, .sp-prose h6 { margin: 1.5rem 0 0.5rem; font-size: 0.6875rem; letter-spacing: 0.1em; color: var(--sp-text-2); }
.sp-prose ul, .sp-prose ol { margin: 0 0 1em; padding-left: 1.25rem; }
.sp-prose li { margin: 0.3em 0; }
.sp-prose li::marker { color: var(--sp-text-2); }
.sp-prose blockquote { margin: 0 0 1em; padding: 0 0 0 1rem; border-left: 1px solid var(--sp-line-2); color: var(--sp-text-2); }
.sp-prose hr { border: 0; border-top: 1px solid var(--sp-line); margin: 2rem 0; }
.sp-prose img { display: block; max-width: 100%; height: auto; margin: 1.5rem 0; border-radius: 0.5rem; }
.sp-img-blocked { color: var(--sp-text-2); font-size: 0.875rem; }

/* Code */
.sp-code {
  margin: 0 0 1.25rem; padding: 1rem 1.125rem; overflow-x: auto;
  background: var(--sp-sunken); border: 1px solid var(--sp-line); border-radius: 0.5rem;
  font-family: var(--sp-font-mono); font-size: 0.8125rem; line-height: 1.6; letter-spacing: 0;
}
.sp-code code { font-size: inherit; padding: 0; border: 0; }
.sp-diagram, .sp-raw-block { margin: 0 0 1.5rem; }
.sp-diagram .sp-code, .sp-raw-block .sp-code { margin-bottom: 0.5rem; }
.sp-diagram figcaption, .sp-raw-block figcaption { font-size: 0.8125rem; color: var(--sp-text-2); }

/* Diagrams drawn as pictures: the sanitiser turns the drawing tool's colours into these classes. */
.sp-diagram--drawn { margin: 0.5rem 0 0.75rem; overflow-x: auto; }
.sp-diagram svg.sp-d { display: block; max-width: 100%; height: auto; margin: 0 0 0.5rem; }
/* Narrow screens and the app panel: keep the drawing's own size (readable text) and let the figure scroll. */
.sp-view-panel .sp-diagram svg.sp-d { max-width: none; }
@media (max-width: 600px) { .sp-diagram svg.sp-d { max-width: none; } }
.sp-d text, .sp-d tspan { font-family: var(--sp-font-sans); letter-spacing: 0; }
.sp-d .sp-d-node { fill: var(--sp-sunken); }
.sp-d .sp-d-bg { fill: var(--sp-bg); }
.sp-d .sp-d-head { fill: var(--sp-sunken); }
.sp-d .sp-d-text { fill: var(--sp-text); }
.sp-d .sp-d-text-2 { fill: var(--sp-text-2); }
.sp-d .sp-d-text-3 { fill: var(--sp-text-3); }
.sp-d .sp-d-arrow { fill: var(--sp-line-2); }
.sp-d .sp-d-soft { fill: var(--sp-line); }
.sp-d .sp-d-border { stroke: var(--sp-line-2); }
.sp-d .sp-d-line { stroke: var(--sp-line-2); }
.sp-d .sp-d-arrow-line { stroke: var(--sp-line-2); }
.sp-d .sp-d-soft-line { stroke: var(--sp-line); }
.sp-d .sp-d-text-line { stroke: var(--sp-text); }
.sp-d .sp-d-bg-line { stroke: var(--sp-bg); }
.sp-diagram__source { margin: 0 0 1.5rem; font-size: 0.8125rem; color: var(--sp-text-2); }
.sp-diagram__source summary { cursor: pointer; font-family: var(--sp-font-display); font-weight: 500; font-size: 0.625rem; letter-spacing: 0.1em; text-transform: uppercase; }
.sp-diagram__source .sp-code { margin: 0.5rem 0 0; color: var(--sp-text); }
.sp-diagram--error figcaption { color: var(--sp-text); }

/* Tables */
.sp-table { overflow-x: auto; margin: 0 0 1.5rem; }
.sp-table table { width: 100%; border-collapse: collapse; font-size: 0.875rem; font-variant-numeric: tabular-nums; }
.sp-table th { padding: 0.625rem 0.75rem 0.625rem 0; text-align: left; vertical-align: bottom; border-bottom: 1px solid var(--sp-line-2); font-family: var(--sp-font-display); font-weight: 500; font-size: 0.625rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--sp-text-2); }
.sp-table td { padding: 0.625rem 0.75rem 0.625rem 0; vertical-align: top; border-bottom: 1px solid var(--sp-line); }

/* Pending */
.sp-pending { margin: 0 0 1.5rem; padding: 1rem 1.25rem; border: 1px dashed var(--sp-line-2); border-radius: 0.5rem; color: var(--sp-text-2); }
.sp-pending__label { display: block; margin-bottom: 0.375rem; font-family: var(--sp-font-display); font-weight: 500; font-size: 0.625rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--sp-text); }
.sp-pending__label::after { content: ":"; }
.sp-pending p { margin: 0; white-space: pre-line; }

/* Callouts: Decision and Bottom line */
.sp-callout { padding: 1.5rem; border: 1px solid var(--sp-line-2); border-radius: 0.75rem; }
.sp-callout { max-width: 52rem; }
.sp-callout > :last-child { margin-bottom: 0; }
.sp-callout--lead { font-size: 1.0625rem; line-height: 1.5; }
@media (min-width: 768px) { .sp-callout { padding: 1.75rem 2rem; } .sp-callout--lead { font-size: 1.1875rem; } }

/* Options */
.sp-options { list-style: none; margin: 0.5rem 0 1.5rem; padding: 0; display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(min(100%, 15rem), 1fr)); }
.sp-option { display: flex; flex-direction: column; gap: 1rem; padding: 1.25rem; border: 1px solid var(--sp-line); border-radius: 0.75rem; }
.sp-option--chosen { border-color: var(--sp-line-strong); }
.sp-option__head { display: flex; align-items: flex-start; justify-content: space-between; gap: 0.75rem; }
.sp-option__name { font-size: 0.8125rem; line-height: 1.4; letter-spacing: 0.08em; overflow-wrap: anywhere; }
.sp-option__group .sp-label { margin-bottom: 0.375rem; }
.sp-marks { list-style: none; margin: 0; padding: 0; font-size: 0.875rem; }
.sp-marks li { position: relative; padding-left: 1.125rem; margin: 0.25rem 0; }
.sp-marks li::before { position: absolute; left: 0; top: 0; color: var(--sp-text-2); font-family: var(--sp-font-mono); }
.sp-marks--pros li::before { content: "+"; }
.sp-marks--cons li::before { content: "\\2212"; }
.sp-option__cost { display: flex; flex-wrap: wrap; align-items: baseline; gap: 0.25rem 0.75rem; margin: auto 0 0; padding-top: 0.75rem; border-top: 1px solid var(--sp-line); font-size: 0.875rem; }
.sp-option__cost .sp-label { display: inline; margin: 0; }

/* Findings */
.sp-findings { list-style: none; margin: 0.5rem 0 1.5rem; padding: 0; }
.sp-finding { display: grid; grid-template-columns: 2rem minmax(0, 1fr) auto; gap: 0.5rem 1rem; align-items: start; padding: 1rem 0; border-top: 1px solid var(--sp-line); }
.sp-finding:last-child { border-bottom: 1px solid var(--sp-line); }
.sp-finding__num { padding-top: 0.2rem; color: var(--sp-text-3); font-size: 0.75rem; }
.sp-finding__claim { margin: 0; }
.sp-finding__sources { margin: 0.5rem 0 0; font-size: 0.8125rem; color: var(--sp-text-2); }
.sp-finding__sources .sp-label { display: inline; margin: 0 0.375rem 0 0; }
.sp-finding .sp-pill { margin-top: 0.125rem; }
@media (max-width: 479px) {
  .sp-finding { grid-template-columns: 1.75rem minmax(0, 1fr); }
  .sp-finding .sp-pill { grid-column: 2; justify-self: start; grid-row: 1; margin: 0 0 0.25rem; }
  .sp-finding__body { grid-column: 2; }
}

/* Panel view (spage /panel, renderPage view: 'panel'): the narrow layout at any width. */
.sp-page.sp-view-panel { padding: 1.5rem 1rem 3rem; font-size: 0.9375rem; }
.sp-view-panel .sp-grid { grid-template-columns: minmax(0, 1fr); grid-template-areas: "head" "body" "facts"; }
.sp-view-panel .sp-facts { margin: 2.5rem 0 0; padding-top: 0; }
.sp-view-panel .sp-fact { grid-template-columns: 7rem minmax(0, 1fr); gap: 0.75rem; padding: 0.625rem 0; }
.sp-view-panel .sp-options { grid-template-columns: minmax(0, 1fr); }
.sp-view-panel .sp-title { font-size: 1.25rem; }

/* Footer */
.sp-foot { margin-top: 3rem; padding-top: 1.25rem; border-top: 1px solid var(--sp-line); display: flex; flex-wrap: wrap; gap: 0.5rem 1.5rem; font-size: 0.75rem; color: var(--sp-text-3); }

@media print {
  .sp-page { max-width: none; padding: 0; }
  .sp-page a { text-decoration: none; }
}
`;

/** The full stylesheet: font faces plus scoped rules. */
export const STARK_CSS = `${FONTS}${RULES}`.replace(/\n{2,}/g, '\n').trim();

/**
 * The Stark font files, as in colors_and_type.css. `dir` is the folder under the
 * assets.starkfuture.com font base; a custom `fontBase` (a published bundle) holds
 * the files flat, so the URL is `<fontBase>/<file>`.
 */
export const FONT_FILES = Object.freeze([
  { family: 'Stark Sans', weight: 400, dir: 'stark-sans', file: 'StarkSans-Regular.otf', format: 'opentype' },
  { family: 'Stark Sans', weight: 500, dir: 'stark-sans', file: 'StarkSans-Medium.otf', format: 'opentype' },
  { family: 'Universal Sans', weight: 400, dir: 'universal-sans', file: 'Universal-Sans-Display-400.woff2', format: 'woff2' },
  { family: 'Universal Sans', weight: 500, dir: 'universal-sans', file: 'Universal-Sans-Display-500.woff2', format: 'woff2' },
  { family: 'Fragment Mono', weight: 400, dir: 'fragment-mono', file: 'FragmentMono-latin.woff2', format: 'woff2',
    unicodeRange: 'U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD' },
]);

export const DEFAULT_FONT_BASE = FONT_BASE;

// Table cell alignment as classes: markdown-it writes style="text-align:..." on
// aligned cells, and a published page has no style attributes (CONTRACTS.md 12.1).
const ALIGN_RULES = `
.sp-page .sp-align-left { text-align: left; }
.sp-page .sp-align-center { text-align: center; }
.sp-page .sp-align-right { text-align: right; }
`;

/**
 * The page stylesheet with @font-face URLs under `fontBase` (CONTRACTS.md 12.4).
 * Without `fontBase` the URLs are the assets.starkfuture.com ones (as in STARK_CSS).
 * `fonts` limits the @font-face rules to these file names (a bundle without a font
 * cache passes [] and the CSS falls back to the system stacks).
 * @param {{ fontBase?: string, fonts?: string[] }} [opts]
 * @returns {string}
 */
export function pageCss(opts = {}) {
  const custom = typeof opts.fontBase === 'string' && opts.fontBase.length > 0;
  const base = custom ? String(opts.fontBase).replace(/\/+$/, '') : FONT_BASE;
  if (/['"()\\\s;{}<>]/.test(base)) throw new Error('fontBase must be a plain URL or path without quotes, spaces or brackets.');
  const only = Array.isArray(opts.fonts) ? new Set(opts.fonts) : null;
  const faces = FONT_FILES.filter((f) => !only || only.has(f.file)).map((f) => {
    const url = custom ? `${base}/${f.file}` : `${base}/${f.dir}/${f.file}`;
    const range = f.unicodeRange ? ` unicode-range: ${f.unicodeRange};` : '';
    return `@font-face { font-family:'${f.family}'; font-weight:${f.weight}; font-style:normal; font-display:swap; src:url('${url}') format('${f.format}');${range} }`;
  });
  return `${faces.join('\n')}\n${RULES}${ALIGN_RULES}`.replace(/\n{2,}/g, '\n').trim() + '\n';
}
