// @ts-check
/**
 * Starting the mirror, its state file (pages/.spage/mirror.json), and the client side
 * used by `spage notify` and the hooks. Only `startMirror` binds a port.
 */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { BASE_HEADERS, createMirrorHandler } from './mirror.js';
import { stateDir } from './pages.js';

/** saveUpload from ./images.js, loaded on the first upload so hooks that import this file stay fast. */
const lazyImages = {
  /** @type {import('./mirror.js').ImagesApi['saveUpload']} */
  saveUpload: async (root, slug, bytes, o) => (await import('./images.js')).saveUpload(root, slug, bytes, o),
};

export const DEFAULT_PORT = 4317;
export const LAST_PORT = 4337;
export const HOST = '127.0.0.1';
export const BIN = fileURLToPath(new URL('../bin/spage.js', import.meta.url));

/** @typedef {{ port: number, token: string, pid: number, startedAt: string }} MirrorState */

/** @param {string} root */
export function mirrorFile(root) {
  return path.join(stateDir(root), 'mirror.json');
}

/** @param {number} port */
export function followUrl(port) {
  return `http://${HOST}:${port}/follow`;
}

/**
 * Make sure pages/.spage exists and is ignored by git in any repo
 * (a .gitignore with `*` inside the state folder ignores the folder itself).
 * @param {string} root
 */
export function ensureStateDir(root) {
  const dir = stateDir(root);
  fs.mkdirSync(dir, { recursive: true });
  const gi = path.join(dir, '.gitignore');
  if (!fs.existsSync(gi)) fs.writeFileSync(gi, '*\n');
  return dir;
}

/**
 * @param {string} root
 * @returns {MirrorState | null}
 */
export function readMirrorState(root) {
  try {
    const s = JSON.parse(fs.readFileSync(mirrorFile(root), 'utf8'));
    if (s && Number.isInteger(s.port) && typeof s.token === 'string' && Number.isInteger(s.pid)) return s;
  } catch {
    // no state, or unreadable
  }
  return null;
}

/** @param {string} root @param {MirrorState} state */
export function writeMirrorState(root, state) {
  ensureStateDir(root);
  const file = mirrorFile(root);
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2) + '\n', { mode: 0o600 });
  fs.chmodSync(tmp, 0o600);
  fs.renameSync(tmp, file);
}

/** @param {string} root @param {number} pid */
export function removeMirrorState(root, pid) {
  const s = readMirrorState(root);
  if (s && s.pid === pid) {
    try { fs.unlinkSync(mirrorFile(root)); } catch { /* already gone */ }
  }
}

/** @param {number} pid */
export function pidAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return /** @type {NodeJS.ErrnoException} */ (e).code === 'EPERM';
  }
}

/**
 * One small HTTP request to the local mirror. Never sends an Origin header.
 * `timeoutMs` is a deadline for the whole request, not only for an idle socket.
 * @param {{ port: number, method?: string, path: string, headers?: Record<string, string>, body?: string, timeoutMs?: number }} o
 * @returns {Promise<{ status: number, body: string }>}
 */
export function localRequest(o) {
  return new Promise((resolve, reject) => {
    const ms = o.timeoutMs ?? 1000;
    const req = http.request(
      {
        host: HOST,
        port: o.port,
        method: o.method ?? 'GET',
        path: o.path,
        headers: { ...(o.headers ?? {}), ...(o.body ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(o.body) } : {}) },
        timeout: ms,
        signal: AbortSignal.timeout(ms),
      },
      (res) => {
        let data = '';
        res.setEncoding('utf8');
        res.on('data', (c) => { if (data.length < 1e6) data += c; });
        res.on('end', () => resolve({ status: res.statusCode ?? 0, body: data }));
      },
    );
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    if (o.body) req.write(o.body);
    req.end();
  });
}

/**
 * The live mirror recorded for root, or null. Live = the process exists and its
 * /health answers our token with this same root. (A pid can be reused by another
 * process, and the port by another folder's mirror.)
 * @param {string} root
 * @param {{ timeoutMs?: number, request?: typeof localRequest }} [opts]
 * @returns {Promise<MirrorState | null>}
 */
export async function liveMirror(root, opts = {}) {
  const s = readMirrorState(root);
  if (!s || !pidAlive(s.pid)) return null;
  const request = opts.request ?? localRequest;
  try {
    const r = await request({ port: s.port, path: '/health', headers: { 'X-Spage-Token': s.token }, timeoutMs: opts.timeoutMs ?? 800 });
    if (r.status !== 200) return null;
    const body = JSON.parse(r.body);
    return body && path.resolve(String(body.root)) === path.resolve(root) ? s : null;
  } catch {
    return null;
  }
}

/**
 * Tell the mirror for root to show a page. Resolves to a short result; never throws.
 * @param {string} root
 * @param {string} slug
 * @param {{ timeoutMs?: number }} [opts]
 * @returns {Promise<{ sent: boolean, reason?: string }>}
 */
export async function notifyMirror(root, slug, opts = {}) {
  const s = readMirrorState(root);
  if (!s) return { sent: false, reason: 'no mirror recorded' };
  if (!pidAlive(s.pid)) return { sent: false, reason: 'mirror not running' };
  try {
    const r = await localRequest({
      port: s.port,
      method: 'POST',
      path: '/notify',
      headers: { 'X-Spage-Token': s.token },
      body: JSON.stringify({ slug }),
      timeoutMs: opts.timeoutMs ?? 1500,
    });
    if (r.status === 200) return { sent: true };
    return { sent: false, reason: `mirror answered ${r.status}: ${r.body.trim()}` };
  } catch (e) {
    return { sent: false, reason: e instanceof Error ? e.message : String(e) };
  }
}

/**
 * Listen on the first free port in [from, to]. `server` only needs listen/once/off,
 * so tests can pass a fake.
 * @param {{ listen: (port: number, host: string) => unknown, once: (ev: string, fn: (...a: any[]) => void) => unknown, off: (ev: string, fn: (...a: any[]) => void) => unknown }} server
 * @param {number} from
 * @param {number} to
 * @returns {Promise<number>}
 */
export async function listenOnFreePort(server, from = DEFAULT_PORT, to = LAST_PORT) {
  for (let port = from; port <= to; port++) {
    const ok = await new Promise((resolve, reject) => {
      /** @param {NodeJS.ErrnoException} err */
      const onError = (err) => {
        server.off('listening', onListening);
        if (err.code === 'EADDRINUSE') resolve(false);
        else reject(err);
      };
      const onListening = () => {
        server.off('error', onError);
        resolve(true);
      };
      server.once('error', onError);
      server.once('listening', onListening);
      server.listen(port, HOST);
    });
    if (ok) return port;
  }
  throw new Error(`Ports ${from} to ${to} are all taken. Stop another mirror or pass --port.`);
}

/**
 * Open a URL with the system browser. Never throws.
 * @param {string} url
 */
export function openUrl(url) {
  const cmd = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'cmd' : 'xdg-open';
  const args = process.platform === 'win32' ? ['/c', 'start', '""', url] : [url];
  try {
    const child = spawn(cmd, args, { detached: true, stdio: 'ignore' });
    child.on('error', () => {});
    child.unref();
    return true;
  } catch {
    return false;
  }
}

/** @param {string} root */
export function lockFile(root) {
  return path.join(stateDir(root), 'mirror.lock');
}

export class MirrorLockedError extends Error {
  /** @param {number} pid */
  constructor(pid) {
    super(`Another mirror for this folder is starting or running (process ${pid}). Run "spage doctor" to get its address.`);
    this.code = 'ELOCKED';
    this.pid = pid;
  }
}

/**
 * Take pages/.spage/mirror.lock (O_EXCL) so two sessions starting at once do not both
 * start a mirror. A lock whose owner is gone is removed and taken again.
 * @param {string} root
 * @param {{ pid?: number, alive?: (pid: number) => boolean }} [opts]
 * @returns {() => void} release
 */
export function acquireMirrorLock(root, opts = {}) {
  const pid = opts.pid ?? process.pid;
  const alive = opts.alive ?? pidAlive;
  ensureStateDir(root);
  const file = lockFile(root);
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const fd = fs.openSync(file, 'wx', 0o600);
      fs.writeSync(fd, `${pid}\n`);
      fs.closeSync(fd);
      return () => {
        try {
          if (Number(fs.readFileSync(file, 'utf8').trim()) === pid) fs.unlinkSync(file);
        } catch {
          // already gone
        }
      };
    } catch (e) {
      if (/** @type {NodeJS.ErrnoException} */ (e).code !== 'EEXIST') throw e;
      let owner = NaN;
      try { owner = Number(fs.readFileSync(file, 'utf8').trim()); } catch { /* removed meanwhile */ }
      if (Number.isInteger(owner) && owner > 0 && owner !== pid && alive(owner)) throw new MirrorLockedError(owner);
      try { fs.unlinkSync(file); } catch { /* removed meanwhile */ }
    }
  }
  throw new MirrorLockedError(NaN);
}

/** No followers and no /notify for this long: the mirror exits by itself. */
export const IDLE_EXIT_MS = 8 * 60 * 60 * 1000;

/**
 * Whether an idle mirror should exit.
 * @param {{ clients: number, lastActivity: number, now: number, idleMs?: number }} o
 */
export function shouldIdleExit(o) {
  return o.clients === 0 && o.now - o.lastActivity >= (o.idleMs ?? IDLE_EXIT_MS);
}

/**
 * Start the mirror server (binds a port). Writes mirror.json; removes it on exit.
 * Exits by itself after 8 hours with no followers and no /notify.
 * `images` provides saveUpload for dropped and pasted images (default: ./images.js).
 * @param {{ root: string, render: import('./mirror.js').RenderFn, port?: number, log?: (s: string) => void, idleMs?: number, images?: import('./mirror.js').ImagesApi }} o
 */
export async function startMirror(o) {
  const root = path.resolve(o.root);
  const token = crypto.randomBytes(32).toString('hex');
  const releaseLock = acquireMirrorLock(root);
  /** @type {number | undefined} */
  let boundPort;
  /** @type {ReturnType<typeof createMirrorHandler> | null} */
  let handler = null;
  let lastActivity = Date.now();
  const server = http.createServer((req, res) => {
    if (!handler) { res.writeHead(503, { ...BASE_HEADERS, 'Content-Length': 0 }); res.end(); return; }
    void handler(req, res);
  });
  server.keepAliveTimeout = 5000;
  let port;
  try {
    port = o.port ? await listenOnFreePort(server, o.port, o.port) : await listenOnFreePort(server);
  } catch (e) {
    releaseLock();
    throw e;
  }
  boundPort = port;
  handler = createMirrorHandler({
    root, token, render: o.render, port: boundPort, onActivity: () => { lastActivity = Date.now(); },
    images: o.images ?? lazyImages,
    ...(o.log ? { log: o.log } : {}),
  });
  const state = { port, token, pid: process.pid, startedAt: new Date().toISOString() };
  writeMirrorState(root, state);
  const cleanup = () => { removeMirrorState(root, process.pid); releaseLock(); };
  process.once('exit', cleanup);
  for (const sig of /** @type {const} */ (['SIGINT', 'SIGTERM', 'SIGHUP'])) {
    process.once(sig, () => { cleanup(); process.exit(0); });
  }
  const h = handler;
  const idleTimer = setInterval(() => {
    if (shouldIdleExit({ clients: h.broadcaster.size, lastActivity, now: Date.now(), idleMs: o.idleMs })) {
      o.log?.('No followers and no pages for 8 hours. The mirror stops.');
      h.broadcaster.close();
      server.close();
      cleanup();
      process.exit(0);
    }
  }, Math.min(10 * 60 * 1000, o.idleMs ?? IDLE_EXIT_MS));
  idleTimer.unref();
  return {
    server,
    port,
    url: followUrl(port),
    close() {
      clearInterval(idleTimer);
      handler?.broadcaster.close();
      server.close();
      cleanup();
    },
  };
}

/**
 * Start `spage serve` for root as a detached background process.
 * @param {string} root
 * @param {{ open?: boolean }} [opts]
 */
export function spawnDetachedMirror(root, opts = {}) {
  if (process.env.STARK_WORKBENCH_MANAGED_MIRROR === "1") return false;
  const args = [BIN, 'serve', '--root', root, ...(opts.open ? ['--open'] : [])];
  try {
    ensureStateDir(root);
    const logFd = fs.openSync(path.join(stateDir(root), 'mirror.log'), 'a', 0o600);
    const child = spawn(process.execPath, args, { detached: true, stdio: ['ignore', logFd, logFd], cwd: root });
    child.on('error', () => {});
    child.unref();
    fs.closeSync(logFd);
    return true;
  } catch {
    return false;
  }
}
