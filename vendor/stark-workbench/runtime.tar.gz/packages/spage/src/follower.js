// @ts-check
/**
 * The follower page: a thin Stark bar plus the current page in a same-origin frame.
 * The only script is inline and carries a per-response nonce.
 */

/** @param {string} s */
export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] ?? c);
}

/**
 * JSON safe to place inside a <script type="application/json"> element.
 * @param {unknown} v
 */
export function jsonForScript(v) {
  return JSON.stringify(v)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

const FONT = 'https://assets.starkfuture.com/frontend-assets/fonts';

/** @param {string} nonce */
export function followerCsp(nonce) {
  return [
    "default-src 'none'",
    `script-src 'nonce-${nonce}'`,
    "style-src 'unsafe-inline'",
    'font-src https://assets.starkfuture.com',
    "connect-src 'self'",
    "frame-src 'self'",
    "img-src 'self' data:",
    "base-uri 'none'",
    "form-action 'none'",
    "frame-ancestors 'self'",
  ].join('; ');
}

/**
 * @typedef {{ slug: string, title: string, type: string, status: string, rev: number, at: string }} ShowEvent
 */

// ---------------------------------------------------------------------------
// Image drop and paste (CONTRACTS.md section 13.3), shared by /follow and /panel.
// The functions below run in the browser: their source is placed in the inline
// script with String(fn), so the tests exercise the same code the page runs.
// They use only each other and browser globals.
// ---------------------------------------------------------------------------

/** Image types the upload route accepts. */
export const UPLOAD_TYPES = Object.freeze(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);
/** Largest upload body in bytes. */
export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;

/**
 * Why a file cannot be uploaded, or null when it can.
 * @param {{ type?: string, size?: number, name?: string } | null | undefined} file
 * @param {{ slug: string } | null | undefined} page
 * @returns {string | null}
 */
export function uploadProblem(file, page) {
  var types = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];
  if (!page || !page.slug) return 'Open a page first, then add the image.';
  if (!file) return 'No image found.';
  if (types.indexOf(String(file.type || '').toLowerCase()) === -1) {
    var kind = String(file.type || '').toLowerCase();
    var convertible = /^image\/(?:heic|heif|tiff|bmp|x-ms-bmp)$/.test(kind);
    return 'Only PNG, JPEG, WebP and GIF images can be added' + (file.type ? ' (this one is ' + String(file.type).slice(0, 40) + ').' : '.')
      + (convertible ? ' Ask Claude to add it from the file instead; it converts HEIC, TIFF and BMP.' : '');
  }
  if (!(Number(file.size) > 0)) return 'This image is empty.';
  if (Number(file.size) > 10 * 1024 * 1024) return 'This image is over 10 MB. Make it smaller first.';
  return null;
}

/**
 * Upload URL for a page; the name is the file name without its extension.
 * @param {string} slug
 * @param {string | null | undefined} fileName
 */
export function uploadUrl(slug, fileName) {
  var name = String(fileName || '').replace(/\.[A-Za-z0-9]{1,5}$/, '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 60);
  return '/p/' + encodeURIComponent(slug) + '/img' + (name ? '?name=' + encodeURIComponent(name) : '');
}

/**
 * Wire the drop zone, paste and the status toast. Browser only.
 * @param {any} win window
 * @param {any} doc document
 * @param {{ csrf: string, current: () => ({ slug: string, title?: string } | null), frame: () => any, agent?: () => string, canPublish?: () => boolean }} cfg
 * @returns {((added: { slug?: unknown, file?: unknown }) => void) | undefined} shows an upload the
 *   mirror announced (its "added" event), so uploads from other programs are seen too
 */
export function installDropZone(win, doc, cfg) {
  var zone = doc.getElementById('drop');
  var zoneText = doc.getElementById('drop-text');
  var toast = doc.getElementById('toast');
  if (!zone || !zoneText || !toast || !cfg || !cfg.csrf) return;
  var toastTimer = 0;
  var lastOver = 0;
  var queue = [];
  var busy = false;
  var mine = {};
  function say(msg, bad) {
    toast.textContent = msg;
    toast.className = bad ? 'toast bad' : 'toast';
    toast.hidden = false;
    win.clearTimeout(toastTimer);
    toastTimer = win.setTimeout(function () { toast.hidden = true; }, bad ? 9000 : 6000);
  }
  function hasFiles(e) {
    var t = e && e.dataTransfer && e.dataTransfer.types;
    if (!t) return false;
    for (var i = 0; i < t.length; i++) if (t[i] === 'Files') return true;
    return false;
  }
  function showZone() {
    var p = cfg.current();
    zoneText.textContent = p ? 'Drop to add to ' + (p.title || p.slug) : 'Open a page first, then drop the image here';
    zone.hidden = false;
    lastOver = Date.now();
  }
  function hideZone() { zone.hidden = true; }
  function next() {
    if (busy || !queue.length) return;
    var file = queue.shift();
    var p = cfg.current();
    var problem = uploadProblem(file, p);
    if (problem) { say(problem, true); next(); return; }
    busy = true;
    say('Adding ' + String(file.name || 'image').slice(0, 80) + ' ...', false);
    win.fetch(uploadUrl(p.slug, file.name), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': String(file.type).toLowerCase(), 'X-Spage-Csrf': cfg.csrf },
      body: file,
    }).then(function (r) {
      if (r.ok) {
        return r.json().then(function (j) {
          var needsPlacement = (cfg.agent && cfg.agent() === 'codex') || (cfg.canPublish && cfg.canPublish() === false);
          var placed = needsPlacement ? ' Ask the agent to place it.' : ' Claude will place it on your next message.';
          mine[String(j && j.file || '')] = true;
          say('Added img/' + String(j && j.file || '').slice(0, 120) + '.' + placed, false);
        });
      }
      return r.text().then(function (t) {
        say('Could not add the image: ' + String(t || ('error ' + r.status)).trim().slice(0, 300), true);
      });
    }).catch(function () {
      say('Could not reach the mirror. Is it still running?', true);
    }).then(function () { busy = false; next(); });
  }
  function add(files) {
    for (var i = 0; i < files.length && i < 20; i++) queue.push(files[i]);
    next();
  }
  function onEnter(e) {
    if (!hasFiles(e)) return;
    e.preventDefault();
    showZone();
  }
  function onOver(e) {
    if (!hasFiles(e)) return;
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
    if (zone.hidden) showZone();
    lastOver = Date.now();
  }
  function onDrop(e) {
    if (!hasFiles(e)) return;
    e.preventDefault();
    hideZone();
    var files = e.dataTransfer && e.dataTransfer.files;
    if (files && files.length) add(files);
  }
  function onPaste(e) {
    var items = e && e.clipboardData && e.clipboardData.items;
    if (!items) return;
    var files = [];
    for (var i = 0; i < items.length; i++) {
      if (items[i].kind === 'file' && /^image\//.test(items[i].type)) {
        var f = items[i].getAsFile();
        if (f) files.push(f);
      }
    }
    if (!files.length) return;
    e.preventDefault();
    add(files);
  }
  // The zone covers the whole window once shown, so it gets every later drag event.
  zone.addEventListener('dragleave', function (e) { if (e.target === zone) hideZone(); });
  zone.addEventListener('dragover', onOver);
  zone.addEventListener('drop', onDrop);
  win.addEventListener('dragenter', onEnter);
  win.addEventListener('dragover', onOver);
  win.addEventListener('drop', onDrop);
  win.addEventListener('dragend', hideZone);
  win.addEventListener('blur', function () { win.setTimeout(function () { if (Date.now() - lastOver > 400) hideZone(); }, 500); });
  doc.addEventListener('paste', onPaste);
  win.addEventListener('keydown', function (e) { if (e.key === 'Escape') hideZone(); });
  // A drag that ends outside the window sends no event here; hide a stale zone.
  win.setInterval(function () { if (!zone.hidden && Date.now() - lastOver > 1500) hideZone(); }, 500);
  // Drags and pastes that start over the page frame go to the frame's document. The frame
  // is same-origin, so listen there too (best effort: some browsers keep these events from
  // reaching a listener in a frame without scripts; dragging over the top bar always works).
  var frame = cfg.frame();
  if (frame) {
    frame.addEventListener('load', function () {
      try {
        var d = frame.contentDocument;
        if (!d) return;
        d.addEventListener('dragenter', onEnter);
        d.addEventListener('dragover', onOver);
        d.addEventListener('drop', onDrop);
        d.addEventListener('paste', onPaste);
      } catch (err) { /* not reachable: keep the top-level listeners only */ }
    });
  }
  return function (added) {
    var file = String(added && added.file || '').slice(0, 120);
    if (!file || mine[file]) return; // this tab's own upload already said so
    say('1 image was added to page ' + String(added.slug || '').slice(0, 64) + ' from the mirror: img/' + file, false);
  };
}

/** The browser helpers above as script source, for an inline script. */
export function dropZoneSource() {
  return [uploadProblem, uploadUrl, installDropZone].map(String).join('\n');
}

/** Styles for the drop zone and the toast (needs --bg, --fg, --line, --red, --sans). */
export const DROP_CSS = `.drop{position:fixed;inset:0;z-index:10;display:flex;align-items:center;justify-content:center;padding:24px;background:rgb(0 0 0/.78)}
.drop[hidden]{display:none}
.drop *{pointer-events:none}
.drop-box{max-width:420px;padding:32px 24px;border:1px dashed var(--fg);border-radius:12px;text-align:center;font:500 14px/1.4 var(--sans);color:var(--fg);overflow-wrap:anywhere}
.toast{position:fixed;left:12px;right:12px;bottom:12px;z-index:11;max-width:480px;margin:0 auto;padding:10px 14px;border:1px solid var(--line);border-radius:12px;background:var(--bg);color:var(--fg);font-size:13px;line-height:1.4;overflow-wrap:anywhere}
.toast.bad{border-color:var(--red)}
.toast[hidden]{display:none}
@media (prefers-color-scheme: light){.drop{background:rgb(255 255 255/.85)}}`;

/** Markup for the drop zone and the toast. */
export const DROP_HTML = `<div class="drop" id="drop" hidden><div class="drop-box" id="drop-text">Drop to add to this page</div></div>
<div class="toast" id="toast" role="status" aria-live="polite" hidden></div>`;

/**
 * @param {{ nonce: string, initial: ShowEvent | null, csrf?: string }} opts
 * `csrf` is the upload token (section 13.3); without it the drop zone is off.
 */
export function renderFollower({ nonce, initial, csrf }) {
  const n = escapeHtml(nonce);
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<title>Stark mirror</title>
<style>
@font-face{font-family:'Stark Sans';font-weight:500;font-style:normal;font-display:swap;src:url('${FONT}/stark-sans/StarkSans-Medium.otf') format('opentype')}
@font-face{font-family:'Universal Sans';font-weight:400;font-style:normal;font-display:swap;src:url('${FONT}/universal-sans/Universal-Sans-Display-400.woff2') format('woff2')}
@font-face{font-family:'Universal Sans';font-weight:500;font-style:normal;font-display:swap;src:url('${FONT}/universal-sans/Universal-Sans-Display-500.woff2') format('woff2')}
@font-face{font-family:'Fragment Mono';font-weight:400;font-style:normal;font-display:swap;src:url('${FONT}/fragment-mono/FragmentMono-latin.woff2') format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
:root{color-scheme:dark;--bg:#000;--fg:#fff;--muted:#949494;--line:#3D3D3D;--chip:rgb(255 255 255/.16);--btn-border:rgb(255 255 255/.16);--red:#FF1717;
--display:'Stark Sans',system-ui,sans-serif;--sans:'Universal Sans',-apple-system,BlinkMacSystemFont,sans-serif}
@media (prefers-color-scheme: light){:root{color-scheme:light;--bg:#fff;--fg:#000;--muted:#666;--line:#E5E5E5;--chip:rgb(0 0 0/.08);--btn-border:rgb(0 0 0/.16);--red:#EF1515}}
*{box-sizing:border-box}
html,body{margin:0;height:100%;background:var(--bg);color:var(--fg);font:14px/1.4 var(--sans)}
body{display:flex;flex-direction:column}
.bar{display:flex;align-items:center;gap:12px;min-height:44px;padding:0 20px;border-bottom:1px solid var(--line);white-space:nowrap}
.mark{width:8px;height:8px;background:var(--red);flex:none}
.label{font:500 10px/1 var(--display);text-transform:uppercase;letter-spacing:.14em}
.title{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;font-weight:500}
.chip{font-size:12px;padding:2px 10px;border-radius:9999px;background:var(--chip)}
.chip[hidden]{display:none}
.muted{color:var(--muted);font-size:12px}
button{font:500 12px/1 var(--sans);color:var(--fg);background:transparent;border:1px solid var(--btn-border);border-radius:9999px;padding:6px 12px;cursor:pointer}
button:hover{background:var(--chip)}
button[hidden]{display:none}
main{flex:1;min-height:0;position:relative}
iframe{border:0;width:100%;height:100%;display:block;background:var(--bg)}
iframe[hidden]{display:none}
.empty{max-width:560px;margin:15vh auto 0;padding:0 20px}
.empty[hidden]{display:none}
.empty h1{font:500 20px/1.25 var(--display);text-transform:uppercase;letter-spacing:.1em;margin:0 0 16px}
.empty p{margin:0 0 12px;color:var(--muted)}
.empty code{font-family:'Fragment Mono',ui-monospace,'SF Mono',Menlo,monospace;font-size:13px;color:var(--fg)}
@media (max-width:640px){.bar{padding:0 12px;gap:8px}.hide-sm{display:none}}
${DROP_CSS}
</style>
</head>
<body>
<header class="bar">
  <span class="mark" aria-hidden="true"></span>
  <span class="label" id="mode">Following</span>
  <span class="title" id="title">Waiting for a page</span>
  <span class="chip" id="status" hidden></span>
  <span class="muted hide-sm" id="ago"></span>
  <span class="muted hide-sm" id="conn">connecting</span>
  <button type="button" id="next" hidden></button>
  <button type="button" id="pause">Pause</button>
  <button type="button" id="resume" hidden>Resume</button>
</header>
<main>
  <iframe id="view" title="Current page" sandbox="allow-same-origin allow-popups allow-popups-to-escape-sandbox" hidden></iframe>
  <section class="empty" id="empty">
    <h1>No pages yet</h1>
    <p>Ask Claude to make this a page, or run <code>/stark-workbench:page</code>.</p>
    <p>This tab updates by itself when a page is written.</p>
  </section>
</main>
${DROP_HTML}
<script type="application/json" id="initial">${jsonForScript(initial)}</script>
<script type="application/json" id="csrf">${jsonForScript(csrf ?? null)}</script>
<script nonce="${n}">
(function () {
${dropZoneSource()}
  var $ = function (id) { return document.getElementById(id); };
  var paused = false, waiting = null, lastAt = 0, current = null;
  function statusLabel(s) {
    if (!s) return '';
    return s.charAt(0).toUpperCase() + s.slice(1);
  }
  function show(p) {
    if (!p || !p.slug) return;
    current = { slug: p.slug, title: p.title || p.slug };
    $('view').src = '/p/' + encodeURIComponent(p.slug) + '/?rev=' + encodeURIComponent(String(p.rev || 0));
    $('view').hidden = false;
    $('empty').hidden = true;
    $('title').textContent = p.title || p.slug;
    $('status').textContent = statusLabel(p.status);
    $('status').hidden = !p.status;
    document.title = (p.title || p.slug) + ' \\u00b7 Stark mirror';
    lastAt = Date.parse(p.at) || Date.now();
    waiting = null;
    $('next').hidden = true;
    tick();
  }
  function tick() {
    if (!lastAt) { $('ago').textContent = ''; return; }
    var s = Math.max(0, Math.round((Date.now() - lastAt) / 1000));
    $('ago').textContent = s < 60 ? 'updated ' + s + ' s ago'
      : s < 3600 ? 'updated ' + Math.round(s / 60) + ' min ago'
      : 'updated ' + Math.round(s / 3600) + ' h ago';
  }
  function setPaused(v) {
    paused = v;
    $('pause').hidden = v;
    $('resume').hidden = !v;
    $('mode').textContent = v ? 'Paused' : 'Following';
    if (!v && waiting) show(waiting);
  }
  $('pause').addEventListener('click', function () { setPaused(true); });
  $('resume').addEventListener('click', function () { setPaused(false); });
  $('next').addEventListener('click', function () { if (waiting) show(waiting); });
  var initial = null;
  try { initial = JSON.parse($('initial').textContent || 'null'); } catch (e) { initial = null; }
  var csrf = null;
  try { csrf = JSON.parse($('csrf').textContent || 'null'); } catch (e) { csrf = null; }
  var onAdded = csrf ? installDropZone(window, document, { csrf: csrf, current: function () { return current; }, frame: function () { return $('view'); } }) : null;
  if (initial) show(initial);
  setInterval(tick, 1000);
  if (typeof EventSource !== 'function') { $('conn').textContent = 'no live updates in this browser'; return; }
  // "since" lets the mirror replay a page shown between this page load and the connect.
  var es = new EventSource('/events?since=' + encodeURIComponent(String((initial && initial.rev) || 0)));
  es.addEventListener('open', function () { $('conn').textContent = 'live'; });
  es.addEventListener('error', function () { $('conn').textContent = 'reconnecting'; });
  es.addEventListener('added', function (e) {
    var a;
    try { a = JSON.parse(e.data); } catch (err) { return; }
    if (onAdded) onAdded(a);
  });
  es.addEventListener('show', function (e) {
    var p;
    try { p = JSON.parse(e.data); } catch (err) { return; }
    if (paused) {
      waiting = p;
      $('next').textContent = 'New: ' + (p.title || p.slug);
      $('next').hidden = false;
      return;
    }
    show(p);
  });
})();
</script>
</body>
</html>
`;
}
