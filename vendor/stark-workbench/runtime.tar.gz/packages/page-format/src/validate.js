// @ts-check
import * as nodeFs from 'node:fs';
import * as nodePath from 'node:path';
import { parsePage, splitLines, sectionKey, classifyLines, bodyStartIndex, normaliseDates } from './parse.js';
import {
  PAGE_TYPES, REQUIRED_SECTIONS, REQUIRED_BLOCKS, KNOWN_FIELDS, MAX_PAGE_BYTES,
  BOTTOM_LINE_MAX_CHARS, BOTTOM_LINE_MAX_SENTENCES, SHRINK_THRESHOLD, PLACEHOLDERS,
} from './constants.js';
import { HEADER_SCHEMA } from './schemas/header.js';
import { BLOCK_SCHEMAS } from './schemas/blocks.js';
import { checkSchema, describeValue, closest } from './schema-check.js';
import { collectRefs, linkSafety, imageTarget } from './links.js';
import { checkImages } from './images.js';
import { checkMermaid } from './mermaid-subset.js';

/**
 * @typedef {import('./parse.js').PageDoc} PageDoc
 * @typedef {import('./parse.js').Issue} Issue
 * @typedef {import('./parse.js').Block} Block
 * @typedef {import('./parse.js').Section} Section
 * @typedef {{ ok: boolean, errors: Issue[], warnings: Issue[], doc: PageDoc }} ValidationResult
 * @typedef {{ existsSync?: (p: string) => boolean, statSync?: (p: string) => unknown, readFileSync?: (p: string) => Uint8Array | string }} FsLike
 * @typedef {{ path?: string | null, previousText?: string | null, strict?: boolean, fs?: FsLike }} ValidateOptions
 */

const TYPES_TEXT = PAGE_TYPES.join(', ');
const SLUG_TEXT = 'a page slug (lowercase letters, digits and hyphens, 3 to 64 characters)';

/** Plain description of what each header field must be, and an example line. */
const HEADER_FIELDS = /** @type {Record<string, { expected: string, example: string }>} */ ({
  schema: { expected: 'the number 1', example: 'schema: 1' },
  type: { expected: `one of ${TYPES_TEXT}`, example: 'type: decision' },
  title: { expected: 'text of 3 to 120 characters on one line', example: 'title: How we get Codex next to Claude' },
  owner: { expected: 'a name or username of 1 to 80 characters', example: 'owner: your-username' },
  status: { expected: 'one of draft, current, superseded', example: 'status: draft' },
  verified: { expected: 'a date like 2026-10-14, or null', example: 'verified: 2026-10-14' },
  reviewBy: { expected: 'a date like 2026-12-01, or null', example: 'reviewBy: 2026-12-01' },
  sources: { expected: 'a list of sources, each 1 to 300 characters', example: 'sources: [research/notes.md, https://example.com/report]' },
  supersedes: { expected: `${SLUG_TEXT}, or null`, example: 'supersedes: old-page-slug' },
  id: { expected: SLUG_TEXT, example: 'id: my-page' },
  created: { expected: 'a date and time like 2026-10-14T09:30:00Z', example: 'created: 2026-10-14T09:30:00Z' },
  author: { expected: 'one of claude, codex, human', example: 'author: claude' },
  session: { expected: 'text of up to 120 characters', example: 'session: abc123' },
  supersededBy: { expected: `${SLUG_TEXT}, or null`, example: 'supersededBy: new-page-slug' },
  published: { expected: 'a list of entries with target, url and at (date and time)', example: 'published: []' },
});

/** Plain description of each typed block item field. */
const BLOCK_FIELDS = /** @type {Record<string, Record<string, string>>} */ ({
  options: {
    name: 'text of 1 to 80 characters',
    chosen: 'true or false',
    pros: 'a list of text items',
    cons: 'a list of text items',
    cost: 'text of up to 80 characters',
  },
  findings: {
    claim: 'text of 1 to 400 characters',
    confidence: 'one of high, medium, low',
    sources: 'a list of text items',
  },
});
const BLOCK_NOUN = /** @type {Record<string, [string, string]>} */ ({
  options: ['Option', 'options'],
  findings: ['Finding', 'findings'],
});
const BLOCK_LIMITS = /** @type {Record<string, string>} */ ({ options: '2 to 6', findings: '1 to 20' });

/**
 * @param {string} code
 * @param {'error' | 'warning'} severity
 * @param {number | null} line
 * @param {string | null} field
 * @param {string} message
 * @param {{ expected?: string, found?: string, hint?: string }} [extra]
 * @returns {Issue}
 */
function issue(code, severity, line, field, message, extra = {}) {
  /** @type {Issue} */
  const out = { code, severity, line, field, message };
  if (extra.expected !== undefined) out.expected = extra.expected;
  if (extra.found !== undefined) out.found = extra.found;
  if (extra.hint !== undefined) out.hint = extra.hint;
  return out;
}

/** Line number of a top-level header field, or null. */
function headerFieldLine(/** @type {string[]} */ lines, /** @type {PageDoc} */ doc, /** @type {string} */ field) {
  if (!doc.headerLines) return null;
  const re = new RegExp(`^(["']?)${escapeRe(field)}\\1\\s*:`);
  for (let i = doc.headerLines.start; i < doc.headerLines.end - 1; i++) {
    if (re.test(lines[i])) return i + 1;
  }
  return null;
}

/** @param {string} field @param {number | string} [index] */
function fieldPath(field, index) {
  return index === undefined ? field : `${field}[${index}]`;
}

/**
 * @param {PageDoc} doc
 * @param {string[]} lines
 * @param {Issue[]} out
 */
function checkHeader(doc, lines, out) {
  const header = doc.header;
  if (!header) return;
  const endLine = doc.headerLines ? doc.headerLines.end : 1;

  for (const key of Object.keys(header)) {
    if (KNOWN_FIELDS.includes(key)) continue;
    const guess = closest(key, KNOWN_FIELDS);
    out.push(issue('header-unknown-field', 'warning', headerFieldLine(lines, doc, key), key,
      `Unknown header field "${key}". It is ignored.`,
      { hint: guess ? `Did you mean "${guess}"?` : 'Remove it, or check the spelling.' }));
  }

  const problems = checkSchema(HEADER_SCHEMA, header);
  const reported = new Set();
  for (const p of problems) {
    if (p.kind === 'required' && p.path.length === 0) {
      const f = /** @type {string} */ (p.prop);
      const spec = HEADER_FIELDS[f];
      out.push(issue('header-field', 'error', endLine, f, `The header is missing "${f}".`, {
        expected: spec?.expected, found: 'nothing',
        hint: spec ? `Add "${spec.example}" to the header.` : `Add "${f}" to the header.`,
      }));
      continue;
    }
    const top = /** @type {string} */ (p.path[0]);
    const spec = HEADER_FIELDS[top];
    if (!spec) continue;
    const line = headerFieldLine(lines, doc, top);
    const value = header[top];
    if (top === 'type' && p.keyword === 'enum' && typeof value === 'string') {
      if (reported.has('type')) continue;
      reported.add('type');
      const guess = closest(value, PAGE_TYPES);
      out.push(issue('type-unsupported', 'error', line, 'type', `Page type "${value}" is not supported.`, {
        expected: spec.expected, found: describeValue(value),
        hint: guess ? `Did you mean "type: ${guess}"?` : `Use one of: ${TYPES_TEXT}.`,
      }));
      continue;
    }
    // One issue per field (or per list item for sources/published).
    const idx = p.path.length > 1 && typeof p.path[1] === 'number' ? p.path[1] : undefined;
    const where = fieldPath(top, idx);
    if (reported.has(where)) continue;
    reported.add(where);
    if (top === 'sources' && idx !== undefined) {
      out.push(issue('header-field', 'error', line, where,
        `Source ${idx + 1} must be text of 1 to 300 characters.`, {
          expected: 'text of 1 to 300 characters', found: describeValue(/** @type {unknown[]} */ (value)[idx]),
          hint: 'Write each source as a file path or a URL. Put quotes around it if it contains a colon followed by a space.',
        }));
      continue;
    }
    if (top === 'published' && idx !== undefined) {
      const sub = p.kind === 'required' ? `is missing "${p.prop}"` : 'is not valid';
      out.push(issue('header-field', 'error', line, where, `Published entry ${idx + 1} ${sub}.`, {
        expected: spec.expected, hint: 'Leave "published" for spage to fill, or set it to [].',
      }));
      continue;
    }
    const isText = ['title', 'owner', 'session'].includes(top);
    out.push(issue('header-field', 'error', line, top,
      `Header field "${top}" must be ${spec.expected}. Found ${describeValue(value)}.`, {
        expected: spec.expected, found: describeValue(value),
        hint: isText && typeof value !== 'string'
          ? `Put the value in quotes, like ${top}: "${String(value)}".`
          : `Write it like "${spec.example}".`,
      }));
  }

  if (Array.isArray(header.sources) && header.sources.length === 0) {
    out.push(issue('no-sources', 'warning', headerFieldLine(lines, doc, 'sources'), 'sources',
      'Illustrative page: no sources listed', {
        hint: 'List the files or links the facts come from under "sources:". Without them the page shows an "Illustrative" banner.',
      }));
  }
}

/**
 * Longest increasing subsequence over `ranks`; returns the set of positions kept.
 * @param {number[]} ranks
 */
function lisPositions(ranks) {
  const n = ranks.length;
  const len = new Array(n).fill(1);
  const prev = new Array(n).fill(-1);
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < i; j++) {
      if (ranks[j] < ranks[i] && len[j] + 1 > len[i]) { len[i] = len[j] + 1; prev[i] = j; }
    }
  }
  let best = -1;
  for (let i = 0; i < n; i++) if (best === -1 || len[i] > len[best]) best = i;
  const keep = new Set();
  for (let i = best; i !== -1; i = prev[i]) keep.add(i);
  return keep;
}

/**
 * Required sections and their order.
 * @param {PageDoc} doc
 * @param {string} type
 * @param {Issue[]} out
 */
function checkSections(doc, type, out) {
  const required = REQUIRED_SECTIONS[type];
  if (!required) return;
  const reqKeys = required.map(sectionKey);
  const keys = doc.sections.map((s) => sectionKey(s.heading));
  const orderText = required.join(', ');

  /** @type {{ rank: number, pos: number }[]} */
  const present = [];
  reqKeys.forEach((k, rank) => {
    const pos = keys.indexOf(k);
    if (pos !== -1) present.push({ rank, pos });
  });
  present.sort((a, b) => a.pos - b.pos);
  const keep = lisPositions(present.map((p) => p.rank));
  /** @type {Map<number, number>} rank -> doc position, for in-order sections */
  const inOrder = new Map();
  present.forEach((p, i) => {
    if (keep.has(i)) { inOrder.set(p.rank, p.pos); return; }
    const s = doc.sections[p.pos];
    out.push(issue('section-order', 'error', s.line, null,
      `The "${required[p.rank]}" section is out of order.`, {
        expected: orderText, found: doc.sections.map((x) => x.heading).join(', '),
        hint: `Move "## ${required[p.rank]}" so the required sections come in this order: ${orderText}.`,
      }));
  });

  // Missing sections: group them by the slot between in-order neighbours.
  /** @type {Map<string, { ranks: number[], from: number, to: number }>} */
  const slots = new Map();
  const presentRanks = new Set(present.map((p) => p.rank));
  for (let r = 0; r < required.length; r++) {
    if (presentRanks.has(r)) continue;
    let from = -1;
    for (let q = r - 1; q >= 0; q--) if (inOrder.has(q)) { from = /** @type {number} */ (inOrder.get(q)); break; }
    let to = doc.sections.length;
    for (let q = r + 1; q < required.length; q++) if (inOrder.has(q)) { to = /** @type {number} */ (inOrder.get(q)); break; }
    const id = `${from}:${to}`;
    const slot = slots.get(id) ?? { ranks: [], from, to };
    slot.ranks.push(r);
    slots.set(id, slot);
  }
  // A required section written as "# Name" is already reported as h1-not-allowed.
  const h1Keys = new Set((doc.parseIssues ?? [])
    .filter((i) => i.code === 'h1-not-allowed' && i.found)
    .map((i) => sectionKey(String(i.found).replace(/^#\s*/, ''))));
  for (const slot of slots.values()) {
    slot.ranks = slot.ranks.filter((r) => !h1Keys.has(reqKeys[r]));
    if (slot.ranks.length === 0) continue;
    const extras = [];
    for (let pos = slot.from + 1; pos < slot.to; pos++) {
      if (!reqKeys.includes(keys[pos])) extras.push(pos);
    }
    if (extras.length === slot.ranks.length) {
      slot.ranks.forEach((r, i) => {
        const s = doc.sections[extras[i]];
        out.push(issue('section-order', 'error', s.line, null,
          `Found "${s.heading}" where "${required[r]}" was expected.`, {
            expected: required[r], found: s.heading,
            hint: `Rename the heading to "## ${required[r]}".`,
          }));
      });
      continue;
    }
    for (const r of slot.ranks) {
      const before = r > 0 ? required[r - 1] : null;
      const nextPos = slot.to < doc.sections.length ? slot.to : -1;
      out.push(issue('section-missing', 'error', nextPos >= 0 ? doc.sections[nextPos].line : null, null,
        `The "${required[r]}" section is missing.`, {
          expected: required[r], found: 'nothing',
          hint: before
            ? `Add a "## ${required[r]}" section after "## ${before}".`
            : `Add "## ${required[r]}" as the first section.`,
        }));
    }
  }

  // The typed block that must sit in a section.
  const need = REQUIRED_BLOCKS[type];
  if (need) {
    const pos = keys.indexOf(sectionKey(need.section));
    if (pos !== -1) {
      const section = doc.sections[pos];
      if (!section.blocks.some((b) => b.lang === need.block)) {
        const elsewhere = doc.blocks.some((b) => b.lang === need.block);
        out.push(issue('block-missing', 'error', section.line, need.block,
          `The "${need.section}" section has no \`\`\`${need.block} block.`, {
            expected: `a \`\`\`${need.block} block`, found: elsewhere ? 'one in another part of the page' : 'nothing',
            hint: elsewhere
              ? `Move the \`\`\`${need.block} block into the "## ${need.section}" section.`
              : `Add a fenced block that starts with \`\`\`${need.block} inside "## ${need.section}".`,
          }));
      }
    }
  }
}

/** @type {Map<string, { lines: string[], items: number[] }>} */
const itemOffsetsCache = new Map();

/**
 * 0-based line offsets (inside the block content) where each top-level list item starts.
 * Cached per content: a block with thousands of bad items asks for this once per issue.
 * @param {string} content
 */
function itemOffsets(content) {
  const hit = itemOffsetsCache.get(content);
  if (hit) return hit;
  const result = computeItemOffsets(content);
  if (itemOffsetsCache.size > 64) itemOffsetsCache.clear();
  itemOffsetsCache.set(content, result);
  return result;
}

/** @param {string} content */
function computeItemOffsets(content) {
  const ls = content.split('\n');
  /** @type {{ at: number, indent: number }[]} */
  const starts = [];
  ls.forEach((l, i) => {
    const m = /^(\s*)-(\s|$)/.exec(l);
    if (m) starts.push({ at: i, indent: m[1].length });
  });
  if (starts.length === 0) return { lines: ls, items: [] };
  const min = Math.min(...starts.map((s) => s.indent));
  return { lines: ls, items: starts.filter((s) => s.indent === min).map((s) => s.at) };
}

/**
 * File line for item `index` (and optionally its field) inside a block.
 * @param {Block} block
 * @param {number | undefined} index
 * @param {string | undefined} field
 */
function blockItemLine(block, index, field) {
  if (index === undefined) return block.line;
  const { lines, items } = itemOffsets(block.content);
  if (index >= items.length) return block.line + 1;
  const start = items[index];
  const end = index + 1 < items.length ? items[index + 1] : lines.length;
  if (field) {
    const re = new RegExp(`^\\s*(-\\s+)?["']?${escapeRe(field)}["']?\\s*:`);
    for (let i = start; i < end; i++) if (re.test(lines[i])) return block.line + 1 + i;
  }
  return block.line + 1 + start;
}

/**
 * Schema check for one typed block.
 * @param {Block} block
 * @param {Issue[]} out
 */
function checkBlock(block, out) {
  const schema = BLOCK_SCHEMAS[block.lang];
  if (!schema || block.parseError !== undefined) return;
  const [Noun, plural] = BLOCK_NOUN[block.lang];
  const fields = BLOCK_FIELDS[block.lang];
  const firstField = Object.keys(fields)[0];
  const data = block.data === undefined ? null : block.data;
  const problems = checkSchema(schema, data);
  const seen = new Set();
  for (const p of problems) {
    const idx = typeof p.path[0] === 'number' ? p.path[0] : undefined;
    const sub = typeof p.path[1] === 'string' ? p.path[1] : undefined;
    const fieldName = idx === undefined ? block.lang : `${block.lang}[${idx}]${sub ? `.${sub}` : p.prop ? `.${p.prop}` : ''}`;
    const dedupe = `${p.kind}|${fieldName}`;
    if (seen.has(dedupe)) continue;
    seen.add(dedupe);

    if (idx === undefined) {
      if (Array.isArray(data)) {
        const n = data.length;
        out.push(issue('block-schema', 'error', block.line, block.lang,
          `The ${block.lang} block has ${n} ${n === 1 ? Noun.toLowerCase() : plural}. It needs ${BLOCK_LIMITS[block.lang]}.`, {
            expected: `${BLOCK_LIMITS[block.lang]} items`, found: String(n),
            hint: n === 0 ? `Add items that start with "- ${firstField}:".` : `Add or remove items so there are ${BLOCK_LIMITS[block.lang]}.`,
          }));
      } else {
        out.push(issue('block-schema', 'error', block.line, block.lang,
          `The ${block.lang} block must be a list. Each item starts with "- ${firstField}:".`, {
            expected: 'a list', found: describeValue(data),
            hint: `Write one item per entry, starting with "- ${firstField}:".`,
          }));
      }
      continue;
    }
    const item = /** @type {unknown[]} */ (data)[idx];
    const label = `${Noun} ${idx + 1}`;
    if (p.kind === 'required') {
      const f = /** @type {string} */ (p.prop);
      out.push(issue('block-schema', 'error', blockItemLine(block, idx, undefined), fieldName,
        `${label} has no "${f}".`, {
          expected: fields[f], found: 'nothing', hint: `Add "${f}:" to ${label.toLowerCase()}.`,
        }));
    } else if (p.kind === 'unknown') {
      const f = /** @type {string} */ (p.prop);
      // The validator also lists known fields that failed their own rule here; those are reported separately.
      if (Object.hasOwn(fields, f)) continue;
      const guess = closest(f, Object.keys(fields));
      out.push(issue('block-schema', 'error', blockItemLine(block, idx, f), fieldName,
        `${label} has an unknown field "${f}".`, {
          expected: Object.keys(fields).join(', '), found: f,
          hint: guess ? `Did you mean "${guess}"?` : `Use only these fields: ${Object.keys(fields).join(', ')}.`,
        }));
    } else if (sub === undefined) {
      out.push(issue('block-schema', 'error', blockItemLine(block, idx, undefined), fieldName,
        `${label} must be a group of fields, not ${describeValue(item)}.`, {
          expected: 'a group of fields', found: describeValue(item),
          hint: `Start the item with "- ${firstField}:" and put its other fields on the lines below, indented by two spaces.`,
        }));
    } else {
      const value = item && typeof item === 'object' ? /** @type {Record<string, unknown>} */ (item)[sub] : undefined;
      const expected = fields[sub] ?? 'a valid value';
      out.push(issue('block-schema', 'error', blockItemLine(block, idx, sub), fieldName,
        `${label}: "${sub}" must be ${expected}. Found ${describeValue(value)}.`, {
          expected, found: describeValue(value),
          hint: expected.startsWith('text') ? `Put quotes around the value of "${sub}" if it is a number, a date or yes/no.`
            : expected.startsWith('a list') ? `Write it like ${sub}: [first item, second item].`
              : `Change "${sub}" to ${expected}.`,
        }));
    }
  }
}

/**
 * Exactly one option must be chosen when the page is current; never more than one.
 * @param {Block} block
 * @param {Record<string, unknown> | null} header
 * @param {Issue[]} out
 */
function checkChosen(block, header, out) {
  if (block.lang !== 'options' || !Array.isArray(block.data)) return;
  const chosen = [];
  block.data.forEach((item, i) => {
    if (item && typeof item === 'object' && /** @type {any} */ (item).chosen === true) chosen.push(i);
  });
  if (chosen.length > 1) {
    out.push(issue('options-chosen', 'error', blockItemLine(block, chosen[1], 'chosen'), 'options',
      `${chosen.length} options are marked "chosen: true". Only one can be chosen.`, {
        expected: '1', found: String(chosen.length),
        hint: 'Keep "chosen: true" on the option you picked and remove it from the others.',
      }));
  } else if (chosen.length === 0 && header && header.status === 'current') {
    out.push(issue('options-chosen', 'error', block.line, 'options',
      'This decision is marked current, but no option has "chosen: true".', {
        expected: '1', found: '0',
        hint: 'Add "chosen: true" to the option you picked, or set "status: draft" until you decide.',
      }));
  }
}

/**
 * Strip markdown down to plain prose for counting. The link patterns are bounded,
 * so a line of "[[[...]((((" cannot make the regex engine backtrack for seconds.
 */
function plainProse(/** @type {string[]} */ ls) {
  return ls.join(' ')
    .replace(/!\[([^\]\n]{0,200})\]\(([^)\s]{0,1000})\)/g, '$1')
    .replace(/\[([^\]\n]{0,200})\]\(([^)\s]{0,1000})\)/g, '$1')
    .replace(/`([^`]{0,2000})`/g, '$1')
    .replace(/(^|\s)(?:[-*+]|\d+[.)]|>|#{3,6})\s+/g, '$1')
    .replace(/[*_~]+/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Count sentences: text split on . ! ? followed by space or end. */
function countSentences(/** @type {string} */ prose) {
  return prose.split(/(?<=[.!?])["')\]]*\s+/).filter((s) => /[\p{L}\p{N}]/u.test(s)).length;
}

/**
 * Prose lines of a section (fenced blocks removed).
 * @param {Section} section
 * @param {string[]} kinds
 * @param {string[]} lines
 * @param {number} endLine 1-based line after the section
 */
function sectionProse(section, kinds, lines, endLine) {
  const out = [];
  for (let ln = section.line + 1; ln < endLine; ln++) if (kinds[ln - 1] === 'text') out.push(lines[ln - 1]);
  return out;
}

/** @param {string} text */
function sectionLengths(text) {
  const doc = parsePage(text);
  /** @type {Map<string, { heading: string, len: number }>} */
  const m = new Map();
  for (const s of doc.sections) {
    const key = sectionKey(s.heading);
    if (!m.has(key)) m.set(key, { heading: s.heading, len: s.body.replace(/\s+/g, ' ').trim().length });
  }
  return m;
}

/**
 * Check a page. `input` is page text or a PageDoc from parsePage.
 * @param {string | PageDoc} input
 * @param {ValidateOptions} [opts]
 * @returns {ValidationResult}
 */
export function validatePage(input, opts = {}) {
  const { previousText = null, strict = false } = opts;
  const fs = opts.fs ?? nodeFs;
  /** @type {PageDoc} */
  const doc = typeof input === 'string' || input == null
    ? parsePage(/** @type {string} */ (input ?? ''), { path: opts.path ?? null })
    : {
      ...input,
      // A PageDoc built elsewhere may carry Date objects; normalise them like parsePage does.
      header: input.header ? /** @type {Record<string, unknown>} */ (normaliseDates(input.header)) : input.header ?? null,
    };
  const path = opts.path ?? doc.path ?? null;
  const text = doc.text ?? '';
  const lines = splitLines(text);
  /** @type {Issue[]} */
  const all = [...(doc.parseIssues ?? [])];

  const bytes = new TextEncoder().encode(text).length;
  if (bytes > MAX_PAGE_BYTES) {
    all.push(issue('size', 'error', null, null,
      `The page is ${Math.ceil(bytes / 1024)} KB. The limit is 200 KB.`, {
        expected: 'at most 200 KB', found: `${Math.ceil(bytes / 1024)} KB`,
        hint: 'Move large tables or data into a separate file under the page folder, or split the page in two.',
      }));
  }
  // A binary file gives screens of nonsense errors; report it once and stop.
  if (text.slice(0, 8192).includes('\u0000')) {
    const errors = [...all.filter((i) => i.code === 'size'), issue('not-text', 'error', null, null, 'index.md is not a text file.', {
      hint: 'Write the page as plain markdown text. Put images and other files in the img/ folder.',
    })];
    return { ok: false, errors, warnings: [], doc };
  }

  checkHeader(doc, lines, all);

  const type = doc.header && typeof doc.header.type === 'string' ? doc.header.type : null;
  if (type) checkSections(doc, type, all);

  for (const block of doc.blocks) {
    if (block.lang === 'pending') {
      all.push(issue('pending', strict ? 'error' : 'warning', block.line, null,
        'This part is not written yet (pending block).', {
          hint: strict
            ? 'Write the missing content and remove the pending block. Pages with pending parts cannot be published.'
            : 'Write the missing content and remove the pending block before publishing.',
        }));
      continue;
    }
    if (block.lang === 'mermaid') {
      checkDiagram(block, all);
      continue;
    }
    checkBlock(block, all);
    checkChosen(block, doc.header, all);
  }

  // Links and images in prose (preamble and sections, not code).
  const kinds = classifyLines(lines, bodyStartIndex(doc.headerLines));
  const refs = collectRefs(lines, kinds);
  // ...and in the text fields of options and findings, which render as inline markdown.
  for (const block of doc.blocks) refs.push(...blockRefs(block));
  for (const ref of refs) reportRef(ref, all, path, fs);
  // Alt text, count, type and size of images (CONTRACTS.md 13.1).
  checkImages(refs, {
    path, fs, issue, target: imageTarget, join: (p, file) => nodePath.join(nodePath.dirname(p), file),
  }, all);

  checkPlaceholders(doc, lines, strict, all);

  // Report bottom line length.
  if (type === 'report') {
    const idx = doc.sections.findIndex((s) => sectionKey(s.heading) === 'bottom line');
    if (idx !== -1) {
      const s = doc.sections[idx];
      const endLine = idx + 1 < doc.sections.length ? doc.sections[idx + 1].line : lines.length + 1;
      const prose = plainProse(sectionProse(s, kinds, lines, endLine));
      const sentences = countSentences(prose);
      if (prose.length > BOTTOM_LINE_MAX_CHARS || sentences > BOTTOM_LINE_MAX_SENTENCES) {
        all.push(issue('bottom-line-long', 'warning', s.line, null,
          `The bottom line is ${sentences} ${sentences === 1 ? 'sentence' : 'sentences'} and ${prose.length} characters. Keep it to ${BOTTOM_LINE_MAX_SENTENCES} sentences and ${BOTTOM_LINE_MAX_CHARS} characters.`, {
            expected: `at most ${BOTTOM_LINE_MAX_SENTENCES} sentences and ${BOTTOM_LINE_MAX_CHARS} characters`,
            found: `${sentences} sentences, ${prose.length} characters`,
            hint: 'Say the answer in one or two sentences. Move details to "## Findings".',
          }));
      }
    }
  }

  // Sections that shrank compared with the previous version.
  if (typeof previousText === 'string') {
    const before = sectionLengths(previousText);
    for (const [key, prev] of before) {
      if (prev.len === 0) continue;
      const cur = doc.sections.find((s) => sectionKey(s.heading) === key);
      const curLen = cur ? cur.body.replace(/\s+/g, ' ').trim().length : 0;
      const drop = (prev.len - curLen) / prev.len;
      if (drop > SHRINK_THRESHOLD) {
        const pct = Math.round(drop * 100);
        all.push(issue('section-shrank', 'warning', cur ? cur.line : null, null,
          cur
            ? `The "${cur.heading}" section shrank by ${pct}% compared with the previous version.`
            : `The "${prev.heading}" section was removed since the previous version.`, {
            expected: `at most ${Math.round(SHRINK_THRESHOLD * 100)}% shorter`, found: `${pct}% shorter`,
            hint: 'Check that nothing was deleted by mistake.',
          }));
      }
    }
  }

  const errors = sortIssues(all.filter((i) => i.severity === 'error'));
  const warnings = sortIssues(all.filter((i) => i.severity === 'warning'));
  return { ok: errors.length === 0, errors, warnings, doc };
}

/**
 * Diagram rules for a mermaid block (CONTRACTS.md 14.2).
 * @param {Block} block
 * @param {Issue[]} out
 */
function checkDiagram(block, out) {
  const check = checkMermaid(block.content, { firstLine: block.line + 1 });
  for (const p of check.problems) {
    out.push(issue('diagram', p.severity, block.line + 1 + p.offset, null, p.message, {
      hint: p.hint ?? 'Diagrams use only the statements in the Stark page format (FORMAT.md 6.1).',
    }));
  }
}

/** Fields of typed-block items that the renderer shows as inline markdown. */
const MARKDOWN_FIELDS = /** @type {Record<string, string[]>} */ ({
  options: ['pros', 'cons', 'cost'],
  findings: ['claim'],
});

/**
 * Links and images inside the text fields of an options or findings block.
 * @param {Block} block
 * @returns {import('./links.js').Ref[]}
 */
function blockRefs(block) {
  const fields = MARKDOWN_FIELDS[block.lang];
  if (!fields || !Array.isArray(block.data)) return [];
  /** @type {import('./links.js').Ref[]} */
  const out = [];
  block.data.forEach((item, idx) => {
    if (!item || typeof item !== 'object') return;
    for (const field of fields) {
      const raw = /** @type {Record<string, unknown>} */ (item)[field];
      for (const v of Array.isArray(raw) ? raw : [raw]) {
        if (typeof v !== 'string' || !/[\]<]/.test(v)) continue;
        const ls = splitLines(v);
        for (const ref of collectRefs(ls, ls.map(() => 'text'))) {
          out.push({ ...ref, line: blockItemLine(block, idx, field) });
        }
      }
    }
  });
  return out;
}

/**
 * Report one link or image found in the page.
 * @param {import('./links.js').Ref} ref
 * @param {Issue[]} all
 * @param {string | null} path
 * @param {FsLike} fs
 */
function reportRef(ref, all, path, fs) {
  if (ref.kind === 'link') {
    const safety = linkSafety(ref.url);
    if (safety === 'ok') return;
    all.push(issue('link-unsafe', safety, ref.line, null,
      safety === 'error'
        ? `Link "${shorten(ref.url)}" is not allowed. javascript:, data: and file: links are blocked.`
        : `Link "${shorten(ref.url)}" uses an unusual address type.`, {
        expected: 'an http: or https: URL, a mailto: address, an #anchor or a relative path',
        found: shorten(ref.url),
        hint: safety === 'error'
          ? 'Remove the link, or point it to an https:// page or a file in the page folder.'
          : 'Use a full https:// address, a mailto: address, an #anchor or a relative path.',
      }));
    return;
  }
  const target = imageTarget(ref.url);
  if (target.kind === 'remote') {
    all.push(issue('image-remote', 'error', ref.line, null,
      `Image "${shorten(ref.url)}" is a remote or embedded address. Images must be files in the page's img/ folder.`, {
        expected: 'img/<file>', found: shorten(ref.url),
        hint: 'Save the image as a file in img/ next to index.md and write ![description](img/<file>).',
      }));
  } else if (target.kind === 'outside') {
    all.push(issue('image-outside-img', 'error', ref.line, null,
      `Image "${shorten(ref.url)}" is not directly in the page's img/ folder.`, {
        expected: 'img/<file>', found: shorten(ref.url),
        hint: 'Move the image into the img/ folder next to index.md (no subfolders) and write ![description](img/<file>).',
      }));
  } else if (path && target.file) {
    const full = nodePath.join(nodePath.dirname(path), target.file);
    if (!fileExists(fs, full)) {
      all.push(issue('image-missing', 'error', ref.line, null,
        `Image "${shorten(ref.url)}" does not exist.`, {
          expected: target.file, found: 'no such file',
          hint: `Add the file at ${target.file} next to index.md, or fix the path.`,
        }));
    }
  }
}

/**
 * Template text left in the page: the template title, "First option", the sample claims.
 * @param {PageDoc} doc
 * @param {string[]} lines
 * @param {boolean} strict
 * @param {Issue[]} all
 */
function checkPlaceholders(doc, lines, strict, all) {
  const severity = strict ? 'error' : 'warning';
  const hint = strict
    ? 'Replace the template text with real content. Pages with template text cannot be published.'
    : 'Replace the template text with real content.';
  const title = doc.header && typeof doc.header.title === 'string' ? doc.header.title.trim() : '';
  if (title && PLACEHOLDERS.titles.includes(title)) {
    all.push(issue('placeholder', severity, headerFieldLine(lines, doc, 'title'), 'title',
      `The title is still the template text "${title}".`, { found: title, hint }));
  }
  for (const block of doc.blocks) {
    if (!Array.isArray(block.data)) continue;
    const [field, list] = block.lang === 'options' ? ['name', PLACEHOLDERS.optionNames]
      : block.lang === 'findings' ? ['claim', PLACEHOLDERS.claims] : [null, null];
    if (!field || !list) continue;
    block.data.forEach((item, idx) => {
      const v = item && typeof item === 'object' ? /** @type {Record<string, unknown>} */ (item)[field] : undefined;
      if (typeof v !== 'string' || !list.includes(v.trim())) return;
      all.push(issue('placeholder', severity, blockItemLine(block, idx, field), `${block.lang}[${idx}].${field}`,
        `${BLOCK_NOUN[block.lang][0]} ${idx + 1} still has the template text "${v.trim()}".`, { found: v.trim(), hint }));
    });
  }
}

/** @param {string} s */
function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** @param {string} s */
function shorten(s) {
  return s.length > 60 ? `${s.slice(0, 57)}...` : s;
}

/** @param {FsLike} fs @param {string} p */
function fileExists(fs, p) {
  try {
    if (typeof fs.existsSync === 'function') return fs.existsSync(p);
    if (typeof fs.statSync === 'function') { fs.statSync(p); return true; }
  } catch {
    return false;
  }
  return true;
}

/** Stable order: by line (unknown lines last), keeping discovery order otherwise. */
export function sortIssues(/** @type {Issue[]} */ list) {
  return list
    .map((x, i) => ({ x, i }))
    .sort((a, b) => {
      const la = a.x.line ?? Number.MAX_SAFE_INTEGER;
      const lb = b.x.line ?? Number.MAX_SAFE_INTEGER;
      return la - lb || a.i - b.i;
    })
    .map((e) => e.x);
}
