// @ts-check
/**
 * `spage publish prepare <page> --project <root>` (CONTRACTS.md 12.1): check a page
 * strictly, scan it for secrets, and build the bundle and manifest the publish guard
 * accepts. It never touches the network.
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { isRealPageFile, readPageText, resolvePageArg, stateDir } from '../pages.js';
import { printableRuns, scanSecrets } from '../secrets.js';
import { safeTerminalText } from '../text.js';
import {
  bundleDir, bundleHashOf, contentTypeFor, formatBytes, hashedFontName, manifestPath, publishConfigPath, publishDir,
  sha256, sriSha384, writeCurrent, PROJECT_RE,
} from './bundle.js';
import { cachedFonts } from './fonts.js';

/** The spage entry script (for the paste-ready fonts hint). */
const SPAGE_BIN_PATH = fileURLToPath(new URL('../../bin/spage.js', import.meta.url));

/**
 * @typedef {import('./bundle.js').Manifest} Manifest
 * @typedef {{ path: string, data: Buffer, contentType: string }} BundleEntry
 * @typedef {{
 *   sniffImage: (bytes: Uint8Array) => { type: string, width: number, height: number } | null,
 *   stripMetadata: (bytes: Uint8Array, type: string) => Uint8Array,
 *   readOrientation?: (bytes: Uint8Array) => number,
 * }} ImagesApi
 * @typedef {{
 *   pageArg: string,
 *   cwd: string,
 *   project?: string,
 *   now?: () => Date,
 *   homedir?: string,
 *   getFormat: () => Promise<import('../deps.js').FormatApi>,
 *   getRenderer: () => Promise<any>,
 *   loadImages?: () => Promise<ImagesApi | null>,
 * }} PrepareOptions
 * @typedef {{ ok: false, reasons: string[] }
 *   | { ok: true, root: string, slug: string, dir: string, manifest: Manifest, notes: string[], totalSize: number }} PrepareResult
 * @typedef {{ ok: false, reasons: string[] }
 *   | { ok: true, root: string, slug: string, dir: string, manifest: Manifest, notes: string[], totalSize: number, entries: BundleEntry[], images: number }} BuildResult
 */

/** Largest image a bundle takes (FORMAT 9.3: 1 MB). */
const MAX_IMAGE_BYTES = 1_000_000;
const IMAGE_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
/** sniffImage type to content type. */
const IMAGE_TYPES = /** @type {Record<string, string>} */ ({
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif',
});

/** @returns {Promise<ImagesApi | null>} */
async function defaultLoadImages() {
  try {
    const m = /** @type {any} */ (await import(new URL('../images.js', import.meta.url).href));
    return typeof m.sniffImage === 'function' && typeof m.stripMetadata === 'function' ? m : null;
  } catch {
    return null;
  }
}

/** @param {string} s */
function decodeEntities(s) {
  return s.replace(/&(amp|quot|#39|lt|gt);/g, (_, e) => ({ amp: '&', quot: '"', '#39': "'", lt: '<', gt: '>' })[/** @type {string} */ (e)] ?? _);
}

/**
 * Check a published index.html: no styles, no scripts, no event handlers, and every
 * reference either external (links only), an in-page anchor, the stylesheet or an image.
 * @param {string} html
 * @param {{ cssHref: string }} o
 * @returns {{ problems: string[], images: string[] }}
 */
export function checkPublishedHtml(html, o) {
  /** @type {string[]} */
  const problems = [];
  /** @type {Set<string>} */
  const images = new Set();
  if (/<style[\s>]/i.test(html)) problems.push('The page has a <style> element.');
  if (/<[a-z][^>]*\sstyle\s*=/i.test(html)) problems.push('The page has a style= attribute.');
  if (/<script[\s>]/i.test(html)) problems.push('The page has a <script> element.');
  if (/<[a-z][^>]*\son[a-z]+\s*=/i.test(html)) problems.push('The page has an event handler attribute.');
  if (/<(?:iframe|object|embed|form|base|frame)[\s>]/i.test(html)) problems.push('The page has an element a published page may not have.');
  for (const m of html.matchAll(/<([a-z][a-z0-9:-]*)\b([^>]*)>/gi)) {
    const tag = m[1].toLowerCase();
    for (const a of m[2].matchAll(/\s(href|src|srcset|xlink:href|poster|action|formaction|data)\s*=\s*"([^"]*)"/gi)) {
      const attr = a[1].toLowerCase();
      const value = decodeEntities(a[2]);
      if (tag === 'a' && attr === 'href') {
        if (/^(?:https?:|mailto:|#)/i.test(value)) continue;
        problems.push(`A link points to "${value}", which is not in the published page. Use a full https link, or remove it.`);
        continue;
      }
      if (tag === 'link' && attr === 'href' && value === o.cssHref) continue;
      if (tag === 'img' && attr === 'src' && /^img\/[^/]+$/.test(value)) {
        images.add(value.slice(4));
        continue;
      }
      problems.push(`<${tag} ${attr}="${value}"> refers to something outside the bundle.`);
    }
  }
  return { problems, images: [...images] };
}

/** @param {string} s */
function show(s) {
  return safeTerminalText(s);
}

/**
 * Build the bundle for a page and write it with its manifest.
 * @param {PrepareOptions} o
 * @returns {Promise<PrepareResult>}
 */
export async function preparePage(o) {
  const r = await buildBundle(o);
  if (!r.ok) return r;
  writeBundle(r.root, r.slug, r.entries, r.manifest);
  // The guard lets Claude upload only the bundle prepared last (CONTRACTS.md 12.2).
  writeCurrent(r.root, {
    slug: r.slug, root: r.root, project: r.manifest.project, bundleHash: r.manifest.bundleHash, createdAt: r.manifest.createdAt,
  });
  try {
    fs.writeFileSync(publishConfigPath(r.root), JSON.stringify({ project: r.manifest.project }, null, 2) + '\n');
  } catch {
    // remembering the project is a convenience
  }
  return { ok: true, root: r.root, slug: r.slug, dir: r.dir, manifest: r.manifest, notes: r.notes, totalSize: r.totalSize };
}

/**
 * Build the bundle for a page in memory, writing nothing but the diagram cache. The
 * publish guard calls this too, to check that a manifest really is what prepare makes
 * from the page today (CONTRACTS.md 12.2).
 * @param {PrepareOptions} o
 * @returns {Promise<BuildResult>}
 */
export async function buildBundle(o) {
  const now = o.now ?? (() => new Date());
  const ref = resolvePageArg(o.pageArg, o.cwd);
  const root = ref.root;
  /** @type {string[]} */
  const reasons = [];
  /** @type {string[]} */
  const notes = [];

  if (path.basename(path.dirname(ref.dir)) !== 'pages') {
    return { ok: false, reasons: [`${show(ref.dir)} is not in a pages/<slug>/ folder. Only pages in pages/ can be published.`] };
  }
  if (!isRealPageFile(root, ref.slug)) {
    return { ok: false, reasons: [`No page at ${show(ref.file)} (or it is a symlink). Give a page folder or its index.md.`] };
  }

  // The project: --project, else the one remembered from last time.
  let project = o.project;
  if (project === undefined) {
    try {
      const saved = JSON.parse(fs.readFileSync(publishConfigPath(root), 'utf8'));
      if (typeof saved.project === 'string') project = saved.project;
    } catch {
      // first publish
    }
  }
  if (!project) return { ok: false, reasons: ['No Stark Pages project given. Ask the user which project, then pass --project <name>.'] };
  if (!PROJECT_RE.test(project)) {
    return { ok: false, reasons: [`"${show(project)}" is not a valid project name. Use the name pages_list_projects shows (letters, digits, spaces, dots, underscores, hyphens).`] };
  }

  const read = readPageText(ref.file);
  if (!read.ok) return { ok: false, reasons: [`${show(read.issue.message)}`] };
  const text = read.text;
  const pageHash = sha256(fs.readFileSync(ref.file));

  const format = await o.getFormat();
  const renderer = await o.getRenderer();
  const doc = format.parsePage(text, { path: ref.file });
  const result = format.validatePage(doc, { path: ref.file, strict: true });
  if (!result.ok) {
    reasons.push(result.errors.length === 1
      ? 'The page has 1 error in the strict check. Fix it first:'
      : `The page has ${result.errors.length} errors in the strict check. Fix them first:`);
    reasons.push(format.formatIssues(result, { file: path.relative(o.cwd, ref.file) || 'index.md' }).trimEnd());
    return { ok: false, reasons };
  }
  const header = /** @type {Record<string, unknown>} */ (doc.header ?? {});
  const type = String(header.type ?? '');
  if (type === 'mock') return { ok: false, reasons: ['Mock pages are not published. Change the type, or keep it as a draft.'] };

  const pageHits = scanSecrets(text, { file: 'index.md' });
  if (pageHits.length) return { ok: false, reasons: [secretReason(pageHits)] };

  // Diagrams: drawn and sanitised by the renderer (section 14), or kept as source text.
  const hasMermaid = Array.isArray(doc.blocks) && doc.blocks.some((/** @type {any} */ b) => b && b.lang === 'mermaid');
  /** @type {Map<number, any> | undefined} */
  let diagrams;
  if (hasMermaid) {
    if (typeof renderer.drawDiagrams === 'function') {
      try {
        diagrams = await renderer.drawDiagrams(doc, { cacheDir: path.join(stateDir(root), 'diagrams') });
      } catch (e) {
        return { ok: false, reasons: [`A diagram could not be drawn: ${show(e instanceof Error ? e.message : String(e))}`] };
      }
      for (const [index, d] of diagrams ?? []) {
        if (d && typeof d === 'object' && 'error' in d) {
          const line = doc.blocks[index]?.line;
          reasons.push(`Diagram${line ? ` on line ${line}` : ''} could not be drawn: ${show(String(d.error))}`);
        }
      }
      if (reasons.length) return { ok: false, reasons };
    } else {
      notes.push('Diagrams are published as source text: this renderer cannot draw them yet.');
    }
  }

  // Fonts from ~/.stark/fonts only (the project folder is Claude's to write, the home cache
  // is not); without them the CSS falls back to system fonts.
  const fontFiles = Array.isArray(renderer.FONT_FILES) ? renderer.FONT_FILES : undefined;
  const cache = cachedFonts(root, { homedir: o.homedir ?? os.homedir(), ...(fontFiles ? { files: fontFiles } : {}) });
  if (cache.fonts.length === 0) {
    notes.push(`No Stark fonts cached, so this page uses system fonts. To fix it once for all projects, run in your own terminal: node ${JSON.stringify(SPAGE_BIN_PATH)} fonts fetch`);
  }

  const version = String(renderer.RENDERER_VERSION ?? '0.0.0');
  // Fonts are content-addressed too: each published name carries a short hash of its bytes,
  // so a later publish with other font bytes never overwrites a font an earlier page uses.
  const fonts = cache.fonts.map((f) => ({ ...f, published: hashedFontName(f.file, sha256(f.bytes)) }));
  let cssText = String(renderer.pageCss({ fontBase: '../../fonts', fonts: fonts.map((f) => f.file) }));
  for (const f of fonts) {
    const from = `url('../../fonts/${f.file}')`;
    if (cssText.split(from).length !== 2) {
      return { ok: false, reasons: [`The stylesheet does not name the font ${show(f.file)} exactly once, so its published name cannot be set. Update spage.`] };
    }
    cssText = cssText.replace(from, `url('../../fonts/${f.published}')`);
  }
  const css = Buffer.from(cssText, 'utf8');
  // The folder name carries the stylesheet's own hash: pages in one Pages project share
  // _stark/, and a page published later (other fonts cached, a newer stylesheet) must never
  // overwrite the file an earlier page pinned with its integrity hash.
  const cssPath = `_stark/r/${version}-${sha256(css).slice(0, 12)}/page.css`;
  const cssHref = `../${cssPath}`;
  const cssIntegrity = sriSha384(css);
  const html = String(renderer.renderPage(doc, {
    mode: 'document', theme: 'stark', css: 'external', cssHref, cssIntegrity, ...(diagrams ? { diagrams } : {}),
  }));

  const checked = checkPublishedHtml(html, { cssHref });
  if (checked.problems.length) return { ok: false, reasons: checked.problems };

  /** @type {BundleEntry[]} */
  const images = [];
  if (checked.images.length) {
    const api = await (o.loadImages ?? defaultLoadImages)();
    if (!api) return { ok: false, reasons: ['Images cannot be published yet: the image module (images.js) is missing, so metadata cannot be stripped.'] };
    for (const name of checked.images) {
      const problem = await addImage(ref.dir, ref.slug, name, api, images);
      if (problem) reasons.push(problem);
    }
    if (reasons.length) return { ok: false, reasons };
  }

  const textHits = [
    ...scanSecrets(html, { file: `${ref.slug}/index.html`, html: true }),
    ...scanSecrets(css.toString('utf8'), { file: cssPath }),
    // Fonts are binary: scan the readable runs (a key appended to a font file).
    ...fonts.flatMap((f) => scanSecrets(printableRuns(f.bytes), { file: `_stark/fonts/${f.published}` })),
  ];
  if (textHits.length) return { ok: false, reasons: [secretReason(textHits)] };

  /** @type {BundleEntry[]} */
  const entries = [
    ...fonts.map((f) => ({ path: `_stark/fonts/${f.published}`, data: f.bytes, contentType: /** @type {string} */ (contentTypeFor(f.file)) })),
    { path: cssPath, data: css, contentType: 'text/css' },
    ...images,
    { path: `${ref.slug}/index.html`, data: Buffer.from(html, 'utf8'), contentType: 'text/html' },
  ];
  const files = entries.map((e) => ({
    path: e.path, local: `files/${e.path}`, sha256: sha256(e.data), size: e.data.length, contentType: e.contentType,
  }));
  /** @type {Manifest} */
  const manifest = {
    v: 1,
    slug: ref.slug,
    title: String(header.title ?? ''),
    type,
    status: String(header.status ?? ''),
    project,
    pageHash,
    createdAt: now().toISOString(),
    bundleHash: bundleHashOf(files),
    files,
  };

  const totalSize = files.reduce((n, f) => n + f.size, 0);
  return { ok: true, root, slug: ref.slug, dir: bundleDir(root, ref.slug), manifest, notes, totalSize, entries, images: images.length };
}

/**
 * Check one referenced image, strip its metadata again and scan what is left.
 * @param {string} pageDir @param {string} slug @param {string} name
 * @param {ImagesApi} api @param {BundleEntry[]} out
 * @returns {Promise<string | null>} a problem, or null
 */
async function addImage(pageDir, slug, name, api, out) {
  if (!IMAGE_NAME.test(name)) return `Rename img/${show(name)}: use letters, digits, dots, underscores and hyphens only.`;
  const file = path.join(pageDir, 'img', name);
  let bytes;
  try {
    const st = fs.lstatSync(file);
    if (st.isSymbolicLink() || !st.isFile()) return `img/${name} is not a plain file in the page's img/ folder.`;
    if (st.size > 25 * 1024 * 1024) return `img/${name} is too big.`;
    bytes = fs.readFileSync(file);
  } catch {
    return `img/${name} is missing.`;
  }
  const sniffed = api.sniffImage(bytes);
  const contentType = sniffed ? IMAGE_TYPES[sniffed.type] : undefined;
  if (!sniffed || !contentType) return `img/${name} is not a PNG, JPEG, WebP or GIF image.`;
  if (contentTypeFor(name) !== contentType) return `img/${name} is really ${sniffed.type.toUpperCase()}: rename it with the right extension.`;
  // A photo stored turned (EXIF orientation not 1) would publish sideways: stripping drops
  // the tag and prepare cannot turn pixels. "image add" turns it with sips (R8).
  if (typeof api.readOrientation === 'function' && api.readOrientation(bytes) !== 1) {
    return `img/${name} is a photo stored turned, so it would show sideways once published. Turn it upright in your own terminal: node ${JSON.stringify(SPAGE_BIN_PATH)} image add ${JSON.stringify(pageDir)} ${JSON.stringify(file)} --name ${JSON.stringify(name.replace(/\.[^.]+$/, '') + '-upright')}, then use the new file on the page.`;
  }
  const stripped = Buffer.from(api.stripMetadata(bytes, sniffed.type));
  if (stripped.length > MAX_IMAGE_BYTES) return `img/${name} is over 1 MB. Run "spage image add" to shrink it.`;
  const hits = scanSecrets(printableRuns(stripped), { file: `img/${name}` });
  if (hits.length) return secretReason(hits);
  out.push({ path: `${slug}/img/${name}`, data: stripped, contentType });
  return null;
}

/** @param {import('../secrets.js').SecretHit[]} hits */
function secretReason(hits) {
  const lines = hits.slice(0, 10).map((h) => `  ${show(h.file ?? '')}:${h.line}  ${h.rule}  ${show(h.preview)}`);
  return [
    `The secret scan found ${hits.length} possible secret${hits.length === 1 ? '' : 's'}. Remove ${hits.length === 1 ? 'it' : 'them'} from the page, then prepare again:`,
    ...lines,
  ].join('\n');
}

/**
 * Write the bundle into a fresh folder and swap it in, so a half-written bundle is never used.
 * @param {string} root @param {string} slug @param {BundleEntry[]} entries @param {Manifest} manifest
 */
function writeBundle(root, slug, entries, manifest) {
  const base = publishDir(root);
  fs.mkdirSync(base, { recursive: true });
  const tmp = path.join(base, `.${slug}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`);
  try {
    for (const e of entries) {
      const abs = path.join(tmp, 'files', ...e.path.split('/'));
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, e.data);
    }
    fs.writeFileSync(path.join(tmp, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
    fs.rmSync(bundleDir(root, slug), { recursive: true, force: true });
    fs.renameSync(tmp, bundleDir(root, slug));
  } catch (e) {
    fs.rmSync(tmp, { recursive: true, force: true });
    throw e;
  }
}

/**
 * The upload plan Claude follows, one block per file: the shared _stark/ files first, then
 * the images, then index.html last, so the page goes live only once everything it needs is
 * there. Claude only calls the two Pages tools: the publish guard uploads each file itself
 * right after pages_upload_begin returns, so no upload URL ever reaches Claude. The user is
 * asked once per page file (each image and index.html); shared style files ask nothing.
 * @param {{ manifest: Manifest, pageDir: string, bin: string }} o
 * @returns {{ text: string, steps: Array<{ path: string, begin: Record<string, unknown>, commit: string, asks: boolean }>, record: string }}
 */
export function uploadPlan(o) {
  const m = o.manifest;
  const commit = 'pages_upload_commit with the upload_id it returned';
  const rank = (/** @type {string} */ p) => (p.startsWith('_stark/') ? 0 : p === `${m.slug}/index.html` ? 2 : 1);
  const ordered = m.files.map((f, i) => ({ f, i })).sort((a, b) => rank(a.f.path) - rank(b.f.path) || a.i - b.i).map((x) => x.f);
  const steps = ordered.map((f) => ({
    path: f.path,
    begin: { root: m.project, path: f.path, content_type: f.contentType, size: f.size },
    commit,
    asks: rank(f.path) !== 0,
  }));
  const asks = steps.filter((s) => s.asks).length;
  const record = `node ${JSON.stringify(o.bin)} publish record ${JSON.stringify(o.pageDir)}`;
  const lines = [
    'Upload plan. For each file, in this order:',
    '  a. call pages_upload_begin with exactly these arguments. Stark then uploads the file itself',
    '     and tells you when it is done (you never handle an upload URL);',
    `  b. call ${commit}.`,
    `The user is asked ${asks === 1 ? 'once' : `${asks} times`}: once per page file (each image and index.html). Shared Stark style files ask nothing.`,
    '',
  ];
  steps.forEach((s, i) => {
    lines.push(`${i + 1}. ${s.path}${s.asks ? ' (the user is asked)' : ' (shared style file, no prompt)'}`);
    lines.push(`   pages_upload_begin ${JSON.stringify(s.begin)}`);
    lines.push(`   then ${commit}`);
  });
  lines.push('');
  lines.push('Then record where the page went (it reads the public URL Stark kept from the commit):');
  lines.push(`   ${record}`);
  return { text: lines.map(show).join('\n'), steps, record };
}

export { manifestPath };
