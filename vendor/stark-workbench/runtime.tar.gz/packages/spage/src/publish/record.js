// @ts-check
/**
 * `spage publish record <page>` (CONTRACTS.md 12.1): add the published URL to the page
 * header's `published` list. The URL is the public_url the publish guard kept from the
 * commit of <slug>/index.html (~/.stark/guard/approvals.json), never one Claude types.
 * It refuses unless every file of the prepared bundle was uploaded by Stark (the bytes the
 * guard checked) and committed, and the page is unchanged since prepare.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { approvalsFile, committedUploads, readApprovals } from '../guard.js';
import { resolvePageArg } from '../pages.js';
import { readManifest, sha256 } from './bundle.js';

/**
 * @typedef {{ target: string, platform: string, project: string, url: string, at: string, hash: string }} PublishedEntry
 */

/** @param {string} raw */
export function checkPublicUrl(raw) {
  if (typeof raw !== 'string' || raw.length > 2048 || /[\s"'<>\\\u0000-\u001f\u007f]/.test(raw)) return null;
  try {
    const u = new URL(raw);
    if (u.protocol !== 'https:' || u.username || u.password) return null;
    return u;
  } catch {
    return null;
  }
}

/**
 * Replace (or add) the `published:` field of a YAML header with a one-line JSON list.
 * The old value's continuation lines (indented, or "- " items) go with it.
 * @param {string} text
 * @param {unknown[]} list
 */
export function setPublishedField(text, list) {
  const eol = text.includes('\r\n') ? '\r\n' : '\n';
  const lines = text.split(/\r?\n/);
  if (lines[0]?.trim() !== '---') throw new Error('The page has no YAML header.');
  const end = lines.findIndex((l, i) => i > 0 && /^(?:---|\.\.\.)\s*$/.test(l));
  if (end < 0) throw new Error('The page header is not closed with ---.');
  const line = `published: ${JSON.stringify(list)}`;
  const at = lines.findIndex((l, i) => i > 0 && i < end && /^published\s*:/.test(l));
  if (at < 0) {
    lines.splice(end, 0, line);
  } else {
    let stop = at + 1;
    while (stop < end && (/^[ \t]/.test(lines[stop]) || /^-(\s|$)/.test(lines[stop]) || lines[stop].trim() === '')) stop++;
    lines.splice(at, stop - at, line);
  }
  return lines.join(eol);
}

/**
 * @param {{ pageArg: string, url?: string, cwd: string, now?: () => Date, homedir?: string,
 *   getFormat: () => Promise<import('../deps.js').FormatApi> }} o
 * @returns {Promise<{ ok: true, url: string, file: string } | { ok: false, code: 1 | 2, reason: string }>}
 */
export async function recordPublished(o) {
  const ref = resolvePageArg(o.pageArg, o.cwd);
  const manifest = readManifest(ref.root, ref.slug);
  if (!manifest) return { ok: false, code: 2, reason: `No prepared bundle for ${ref.slug}. Publish it first: spage publish prepare, then the upload plan.` };
  const home = o.homedir ?? os.homedir();
  try {
    fs.readFileSync(approvalsFile(home));
  } catch (e) {
    if (!(e && typeof e === 'object' && 'code' in e && e.code === 'ENOENT')) {
      return { ok: false, code: 2, reason: 'Cannot read what Stark uploaded (~/.stark/guard/approvals.json). Run this command again with the sandbox off.' };
    }
  }
  const store = readApprovals(home);
  const bundle = { root: ref.root, project: manifest.project, bundleHash: manifest.bundleHash, files: manifest.files };
  const done = committedUploads(store, bundle);
  if (done.size === 0) return { ok: false, code: 2, reason: `Stark did not upload the bundle prepared for ${ref.slug}. Finish the upload plan first.` };
  let bytes;
  try {
    if (fs.lstatSync(ref.file).isSymbolicLink()) throw new Error('symlink');
    bytes = fs.readFileSync(ref.file);
  } catch {
    return { ok: false, code: 1, reason: `Cannot read ${ref.file}.` };
  }
  const text = bytes.toString('utf8');
  if (sha256(bytes) !== manifest.pageHash) {
    return { ok: false, code: 2, reason: 'index.md changed since prepare, so the published page is not this text. Prepare and publish it again.' };
  }
  const missing = manifest.files.filter((f) => !done.has(f.path)).map((f) => f.path);
  if (missing.length) {
    return { ok: false, code: 2, reason: `Not every file of ${ref.slug} was uploaded by Stark and committed: ${missing.slice(0, 5).join(', ')}${missing.length > 5 ? ', ...' : ''}. Finish the upload plan first.` };
  }
  const stored = done.get(`${ref.slug}/index.html`)?.public_url;
  const u = typeof stored === 'string' ? checkPublicUrl(stored) : null;
  if (!u) return { ok: false, code: 2, reason: `The commit of ${ref.slug}/index.html returned no public URL, so there is nothing to record.` };
  if (o.url !== undefined && o.url !== stored) {
    return { ok: false, code: 2, reason: `That is not the URL Pages returned for ${ref.slug}/index.html. Run the command without --url.` };
  }
  const format = await o.getFormat();
  const header = format.parsePage(text, { path: ref.file }).header ?? {};
  const old = Array.isArray(header.published) ? header.published.filter((/** @type {unknown} */ e) => e && typeof e === 'object') : [];
  const samePlace = (/** @type {any} */ e) => {
    const platform = e.platform ?? e.target;
    if (platform !== 'stark-pages' || e.project !== manifest.project) return false;
    try {
      const prev = new URL(String(e.url));
      return prev.host === u.host && prev.pathname === u.pathname;
    } catch {
      return false;
    }
  };
  /** @type {PublishedEntry} */
  const entry = {
    // `target` keeps the slice-1 header schema (target, url, at) valid; `platform` is the 12.1 name.
    target: 'stark-pages',
    platform: 'stark-pages',
    project: manifest.project,
    url: u.href,
    at: (o.now ?? (() => new Date()))().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    hash: manifest.pageHash,
  };
  const list = [...old.filter((/** @type {any} */ e) => !samePlace(e)), entry];
  const next = setPublishedField(text, list);
  const tmp = path.join(path.dirname(ref.file), `.index.md.${process.pid}.tmp`);
  fs.writeFileSync(tmp, next);
  fs.renameSync(tmp, ref.file);
  return { ok: true, url: u.href, file: ref.file };
}
