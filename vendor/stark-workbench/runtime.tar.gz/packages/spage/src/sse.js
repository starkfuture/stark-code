// @ts-check
/**
 * Server-Sent Events broadcaster for the mirror.
 * Framing: `event: <name>\ndata: <json>\n\n`; keep-alive is a comment line `: ping`.
 */

/**
 * @typedef {{ write: (chunk: string) => unknown, end?: () => unknown, writableEnded?: boolean, destroyed?: boolean }} SseClient
 */

/**
 * Format one SSE event. Data is JSON on a single line (JSON.stringify never emits raw newlines).
 * @param {string} event
 * @param {unknown} data
 * @param {number | string} [id]
 */
export function formatEvent(event, data, id) {
  if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(event)) throw new Error(`bad SSE event name: ${event}`);
  let out = `event: ${event}\n`;
  if (id !== undefined) out += `id: ${String(id).replace(/[\r\n]/g, '')}\n`;
  out += `data: ${JSON.stringify(data)}\n\n`;
  return out;
}

export const PING = ': ping\n\n';

/** A client whose writes report a full buffer this many times in a row is dropped. */
export const MAX_BLOCKED_WRITES = 20;

/**
 * @param {{ pingMs?: number, maxBlocked?: number, setInterval?: typeof globalThis.setInterval, clearInterval?: typeof globalThis.clearInterval }} [opts]
 */
export function createBroadcaster(opts = {}) {
  const pingMs = opts.pingMs ?? 20_000;
  const maxBlocked = opts.maxBlocked ?? MAX_BLOCKED_WRITES;
  /** @type {WeakMap<SseClient, number>} writes in a row that returned false */
  const blocked = new WeakMap();
  const setI = opts.setInterval ?? globalThis.setInterval;
  const clearI = opts.clearInterval ?? globalThis.clearInterval;
  /** @type {Set<SseClient>} */
  const clients = new Set();
  /** @type {ReturnType<typeof setInterval> | null} */
  let timer = null;

  /** @param {SseClient} c @param {string} chunk */
  function safeWrite(c, chunk) {
    if (c.writableEnded || c.destroyed) { clients.delete(c); return; }
    try {
      if (c.write(chunk) === false) {
        const n = (blocked.get(c) ?? 0) + 1;
        blocked.set(c, n);
        // A follower that stopped reading: end its stream instead of buffering forever.
        if (n > maxBlocked) {
          clients.delete(c);
          try { c.end?.(); } catch { /* already closed */ }
        }
      } else {
        blocked.delete(c);
      }
    } catch {
      clients.delete(c);
    }
  }

  function ensureTimer() {
    if (timer || pingMs <= 0) return;
    timer = setI(() => ping(), pingMs);
    // do not keep the process alive just for pings
    if (timer && typeof timer === 'object' && 'unref' in timer) timer.unref();
  }

  function stopTimerIfIdle() {
    if (timer && clients.size === 0) { clearI(timer); timer = null; }
  }

  function ping() {
    for (const c of [...clients]) safeWrite(c, PING);
    stopTimerIfIdle();
  }

  return {
    /** @param {SseClient} client */
    add(client) {
      clients.add(client);
      safeWrite(client, 'retry: 2000\n\n');
      ensureTimer();
      return () => { clients.delete(client); stopTimerIfIdle(); };
    },
    /** @param {string} event @param {unknown} data @param {number|string} [id] */
    send(event, data, id) {
      const chunk = formatEvent(event, data, id);
      for (const c of [...clients]) safeWrite(c, chunk);
      return clients.size;
    },
    ping,
    get size() { return clients.size; },
    close() {
      if (timer) clearI(timer);
      timer = null;
      clients.clear();
    },
  };
}

/** @typedef {ReturnType<typeof createBroadcaster>} Broadcaster */
