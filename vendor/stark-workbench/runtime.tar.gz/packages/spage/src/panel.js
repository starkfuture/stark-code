// @ts-check
/**
 * The page panel (CONTRACTS.md section 11): a follower made for a narrow side panel in
 * the Stark Code app. It frames `/p/<slug>?view=panel`, talks to the app with
 * postMessage (section 11.3) and accepts dropped or pasted images (section 13.3).
 *
 * The functions marked "browser" run in the panel: their source goes into the inline
 * script with String(fn), so the tests check the same code the panel runs. They use
 * only each other and browser globals.
 */
import { DROP_CSS, DROP_HTML, dropZoneSource, escapeHtml, jsonForScript } from './follower.js';
import { frameAncestors } from './embed.js';

/** String caps for messages (section 11.3). */
export const CAPS = Object.freeze({ slug: 120, title: 200, url: 2048, root: 4096, word: 40 });

/** Text of the panel's empty state (section 11.1). */
export const PANEL_EMPTY_TEXT = 'No pages yet. Ask Claude for a decision or a report, or run /stark-workbench:page.';

/**
 * Browser. Cap a value to a string of at most n characters.
 * @param {unknown} s @param {number} n
 */
export function capText(s, n) {
  var t = typeof s === 'string' ? s : s === null || s === undefined ? '' : String(s);
  return t.length > n ? t.slice(0, n) : t;
}

/**
 * Browser. Whether an origin is an allowed embed origin: an exact match, or a scheme
 * source (`starkcode:`) matching the origin's scheme. The opaque origin "null" never matches.
 * @param {unknown} origin @param {readonly string[]} allowed
 */
export function originMatches(origin, allowed) {
  if (typeof origin !== 'string' || !origin || origin === 'null' || !allowed) return false;
  var o = origin.toLowerCase();
  for (var i = 0; i < allowed.length; i++) {
    var a = allowed[i];
    if (typeof a !== 'string' || !a) continue;
    if (a.charAt(a.length - 1) === ':') {
      if (o.indexOf(a + '//') === 0 && o.length > a.length + 2) return true;
    } else if (o === a) {
      return true;
    }
  }
  return false;
}

/**
 * Browser. The parent's origin when the panel is framed by an allowed origin, else null.
 * Uses location.ancestorOrigins[0] (Chromium; Electron is Chromium).
 * @param {{ ancestorOrigins?: ArrayLike<string> } | null | undefined} loc
 * @param {{ parent?: unknown } | null | undefined} win
 * @param {readonly string[]} allowed
 * @returns {string | null}
 */
export function pickParentOrigin(loc, win, allowed) {
  if (!win || !win.parent || win.parent === win) return null;
  var list = loc && loc.ancestorOrigins;
  if (!list || !list.length) return null;
  var o = list[0];
  return originMatches(o, allowed) ? o : null;
}

/**
 * Browser. A message from the app, checked and normalised, or null to ignore it.
 * Accepted only from the parent window and from the parent's checked origin.
 * @param {{ source?: unknown, origin?: unknown, data?: any } | null | undefined} event
 * @param {unknown} parentWin
 * @param {string | null} parentOrigin
 * @returns {{ type: 'show', slug: string } | { type: 'pause' } | { type: 'resume' } | { type: 'host', canPublish: boolean, agent: 'claude' | 'codex' } | null}
 */
export function readHostMessage(event, parentWin, parentOrigin) {
  if (!event || !parentOrigin || !parentWin) return null;
  if (event.source !== parentWin || event.origin !== parentOrigin) return null;
  var d = event.data;
  if (!d || typeof d !== 'object' || d.v !== 1 || d.source !== 'stark-host' || typeof d.type !== 'string') return null;
  if (d.type === 'pause') return { type: 'pause' };
  if (d.type === 'resume') return { type: 'resume' };
  if (d.type === 'host') {
    // What the thread can do: a Codex thread cannot publish (no Stark plugin or guard there).
    return { type: 'host', canPublish: d.canPublish !== false, agent: d.agent === 'codex' ? 'codex' : 'claude' };
  }
  if (d.type === 'show') {
    if (typeof d.slug !== 'string' || d.slug.length > 120 || !/^[a-z0-9-]{3,64}$/.test(d.slug)) return null;
    return { type: 'show', slug: d.slug };
  }
  return null;
}

/**
 * Browser. Build a message for the app, with every string capped. Unknown type: null.
 * @param {string} type
 * @param {any} body
 */
export function panelMessage(type, body) {
  var b = body || {};
  /** @type {Record<string, unknown>} */
  var m = { v: 1, source: 'stark-pages', type: type };
  if (type === 'ready') {
    m.root = capText(b.root, 4096);
    m.port = Number(b.port) > 0 && Number(b.port) < 65536 ? Math.floor(Number(b.port)) : 0;
  } else if (type === 'show') {
    var p = b.page || {};
    m.page = {
      slug: capText(p.slug, 120),
      title: capText(p.title, 200),
      type: capText(p.type, 40),
      status: capText(p.status, 40),
      rev: Number.isFinite(Number(p.rev)) ? Number(p.rev) : 0,
    };
  } else if (type === 'publish-request') {
    var q = b.page || {};
    m.page = { slug: capText(q.slug, 120), title: capText(q.title, 200) };
  } else if (type === 'open-external' || type === 'open-link') {
    m.url = capText(b.url, 2048);
  } else {
    return null;
  }
  return m;
}

/**
 * Browser. The "Open in browser" URL: always the follower on 127.0.0.1 (section 11.3).
 * @param {number} port @param {string} slug
 */
export function externalUrl(port, slug) {
  return 'http://127.0.0.1:' + port + '/follow' + (slug ? '?slug=' + encodeURIComponent(slug) : '');
}

/**
 * Browser. Whether the framed page looks publishable: a rendered page without the
 * error notice and without the renderer's "not publishable" marker (mock pages, pending
 * blocks, template text). Only a hint for the Publish button; the publish guard decides.
 * @param {{ querySelector: (s: string) => unknown } | null | undefined} doc
 */
export function publishableFromDocument(doc) {
  try {
    return !!(doc && doc.querySelector('article.sp-page') && !doc.querySelector('.sp-notice')
      && !doc.querySelector('article.sp-page[data-publishable="false"]'));
  } catch (e) {
    return false;
  }
}

/**
 * Browser. The URL a link in the page should open in the user's browser, or null to let
 * the click be: only http and https links to another site, with no user name or password.
 * Links inside the mirror (anchors, images) stay in the panel.
 * @param {unknown} href @param {string} selfOrigin
 * @returns {string | null}
 */
export function externalLinkUrl(href, selfOrigin) {
  if (typeof href !== 'string' || !href || href.length > 2048) return null;
  try {
    var u = new URL(href);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    if (u.username || u.password) return null;
    if (u.origin === selfOrigin) return null;
    return u.href.length > 2048 ? null : u.href;
  } catch (e) {
    return null;
  }
}

/** The browser helpers as script source. */
export function panelHelpersSource() {
  return [capText, originMatches, pickParentOrigin, readHostMessage, panelMessage, externalUrl, publishableFromDocument, externalLinkUrl]
    .map(String).join('\n');
}

/**
 * CSP for /panel: like the follower, but the allowed embed origins may frame it.
 * @param {string} nonce @param {readonly string[]} embedOrigins
 */
export function panelCsp(nonce, embedOrigins) {
  return [
    "default-src 'none'",
    `script-src 'nonce-${nonce}'`,
    "style-src 'unsafe-inline'",
    'font-src https://assets.starkfuture.com',
    "connect-src 'self'",
    "frame-src 'self'",
    "img-src 'self' data:",
    "base-uri 'none'",
    "form-action 'none'",
    frameAncestors(embedOrigins),
  ].join('; ');
}

const FONT = 'https://assets.starkfuture.com/frontend-assets/fonts';

/**
 * @typedef {import('./follower.js').ShowEvent} ShowEvent
 * @typedef {{
 *   nonce: string, initial: ShowEvent | null, csrf?: string,
 *   embedOrigins: readonly string[], port: number, root: string,
 * }} PanelOptions
 */

/**
 * The /panel document.
 * @param {PanelOptions} o
 */
export function renderPanel(o) {
  const n = escapeHtml(o.nonce);
  const config = {
    initial: o.initial,
    csrf: o.csrf ?? null,
    allowed: [...o.embedOrigins],
    port: o.port,
    root: o.root,
  };
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta name="color-scheme" content="dark light">
<title>Stark pages</title>
<style>
@font-face{font-family:'Stark Sans';font-weight:500;font-style:normal;font-display:swap;src:url('${FONT}/stark-sans/StarkSans-Medium.otf') format('opentype')}
@font-face{font-family:'Universal Sans';font-weight:400;font-style:normal;font-display:swap;src:url('${FONT}/universal-sans/Universal-Sans-Display-400.woff2') format('woff2')}
@font-face{font-family:'Universal Sans';font-weight:500;font-style:normal;font-display:swap;src:url('${FONT}/universal-sans/Universal-Sans-Display-500.woff2') format('woff2')}
:root{color-scheme:dark;--bg:#000;--fg:#fff;--muted:#949494;--line:#3D3D3D;--chip:rgb(255 255 255/.16);--btn-border:rgb(255 255 255/.16);--red:#FF1717;
--display:'Stark Sans',system-ui,sans-serif;--sans:'Universal Sans',-apple-system,BlinkMacSystemFont,sans-serif}
@media (prefers-color-scheme: light){:root{color-scheme:light;--bg:#fff;--fg:#000;--muted:#666;--line:#E5E5E5;--chip:rgb(0 0 0/.08);--btn-border:rgb(0 0 0/.16);--red:#EF1515}}
*{box-sizing:border-box}
html,body{margin:0;height:100%;overflow-x:hidden;background:var(--bg);color:var(--fg);font:13px/1.4 var(--sans)}
body{display:flex;flex-direction:column;min-width:0}
.bar{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;padding:8px 12px;border-bottom:.5px solid var(--line);position:relative}
.line1{display:flex;align-items:center;gap:8px;flex:1 1 180px;min-width:min(180px,100%)}
.mark{width:8px;height:8px;background:var(--red);flex:none}
.title{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500}
.chip{flex:none;font:500 10px/1 var(--display);text-transform:uppercase;letter-spacing:.1em;padding:4px 8px;border-radius:9999px;background:var(--chip);white-space:nowrap}
.chip[hidden]{display:none}
.actions{display:flex;flex-wrap:wrap;align-items:center;gap:6px;min-width:0}
@media (max-width:359px){.actions{flex-basis:100%}}
button,.btn{font:500 12px/1 var(--sans);color:var(--fg);background:transparent;border:1px solid var(--btn-border);border-radius:9999px;padding:6px 10px;cursor:pointer;text-decoration:none;white-space:nowrap}
button:hover,.btn:hover{background:var(--chip)}
button:focus-visible,.btn:focus-visible{outline:3px solid color-mix(in srgb,var(--fg) 35%,transparent);outline-offset:1px}
#publish{background:var(--chip);border-color:transparent}
button[hidden],.btn[hidden]{display:none}
.menu{position:absolute;z-index:5;top:100%;left:12px;right:12px;max-width:420px;max-height:60vh;overflow:auto;margin:4px 0 0;padding:4px;list-style:none;background:var(--bg);border:1px solid var(--line);border-radius:12px}
.menu[hidden]{display:none}
.menu button{display:block;width:100%;text-align:left;border:0;border-radius:8px;padding:8px 10px;white-space:normal;line-height:1.3}
.menu .meta{display:block;margin-top:2px;color:var(--muted);font-weight:400;font-size:11px}
.menu .none{padding:8px 10px;color:var(--muted)}
main{flex:1;min-height:0;position:relative}
iframe{border:0;width:100%;height:100%;display:block;background:var(--bg)}
iframe[hidden]{display:none}
.empty{padding:24px 16px;color:var(--muted);max-width:420px}
.empty .eyebrow{display:block;margin:0 0 8px;font:500 10px/1 var(--display);text-transform:uppercase;letter-spacing:.1em;color:var(--fg)}
.empty[hidden]{display:none}
${DROP_CSS}
</style>
</head>
<body>
<header class="bar">
  <div class="line1">
    <span class="mark" aria-hidden="true"></span>
    <span class="title" id="title">Waiting for a page</span>
    <span class="chip" id="status" hidden></span>
  </div>
  <div class="actions">
    <button type="button" id="pick" aria-haspopup="true" aria-expanded="false" aria-controls="menu">Pages</button>
    <a class="btn" id="open" href="/follow" target="_blank" rel="noopener noreferrer" title="Open in browser" aria-label="Open in browser">Open</a>
    <button type="button" id="publish" hidden>Publish</button>
    <button type="button" id="next" hidden></button>
    <button type="button" id="pause">Pause</button>
    <button type="button" id="resume" hidden>Resume</button>
  </div>
  <ul class="menu" id="menu" aria-label="Pages, newest first" hidden></ul>
</header>
<main>
  <iframe id="view" title="Current page" sandbox="allow-same-origin allow-popups allow-popups-to-escape-sandbox" hidden></iframe>
  <p class="empty" id="empty"><span class="eyebrow">No pages yet</span>${escapeHtml(PANEL_EMPTY_TEXT.replace(/^No pages yet\. /, ''))}</p>
</main>
${DROP_HTML}
<script type="application/json" id="config">${jsonForScript(config)}</script>
<script nonce="${n}">
(function () {
${dropZoneSource()}
${panelHelpersSource()}
  var $ = function (id) { return document.getElementById(id); };
  var cfg = {};
  try { cfg = JSON.parse($('config').textContent || '{}') || {}; } catch (e) { cfg = {}; }
  var allowed = Array.isArray(cfg.allowed) ? cfg.allowed : [];
  var parentOrigin = pickParentOrigin(window.location, window, allowed);
  var embedded = !!parentOrigin;
  var paused = false, waiting = null, current = null, pages = null, canPublish = true, agent = 'claude', lastOk = false;
  var frame = $('view');

  function post(type, body) {
    if (!embedded) return;
    var m = panelMessage(type, body);
    if (m) window.parent.postMessage(m, parentOrigin);
  }
  function statusLabel(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }
  function show(p) {
    if (!p || !p.slug) return;
    current = { slug: p.slug, title: p.title || p.slug, type: p.type || '', status: p.status || '', rev: p.rev || 0 };
    $('publish').hidden = true;
    frame.src = '/p/' + encodeURIComponent(p.slug) + '/?view=panel&rev=' + encodeURIComponent(String(p.rev || 0));
    frame.hidden = false;
    $('empty').hidden = true;
    $('title').textContent = current.title;
    $('title').title = current.title;
    $('status').textContent = statusLabel(current.status);
    $('status').hidden = !current.status;
    $('open').href = externalUrl(cfg.port, p.slug);
    document.title = current.title + ' \\u00b7 Stark pages';
    waiting = null;
    $('next').hidden = true;
    post('show', { page: current });
  }
  frame.addEventListener('load', function () {
    var ok = false;
    try { ok = publishableFromDocument(frame.contentDocument); } catch (e) { ok = false; }
    lastOk = ok;
    $('publish').hidden = !(embedded && current && ok && canPublish);
    // In the app, the panel may not open popups, so links in the page would do nothing:
    // send them to the app, which opens them in the default browser.
    if (!embedded) return;
    try {
      var d = frame.contentDocument;
      if (d && d.addEventListener) {
        d.addEventListener('click', function (e) {
          var t = e && e.target;
          var a = t && t.closest ? t.closest('a[href]') : null;
          if (!a) return;
          var url = externalLinkUrl(a.href, window.location.origin);
          if (!url) return;
          e.preventDefault();
          post('open-link', { url: url });
        });
      }
    } catch (e) { /* not same-origin: leave links alone */ }
  });
  function setPaused(v) {
    paused = v;
    $('pause').hidden = v;
    $('resume').hidden = !v;
    if (!v && waiting) show(waiting);
  }
  $('pause').addEventListener('click', function () { setPaused(true); });
  $('resume').addEventListener('click', function () { setPaused(false); });
  $('next').addEventListener('click', function () { if (waiting) show(waiting); });
  $('publish').addEventListener('click', function () {
    if (!embedded || !current) return;
    post('publish-request', { page: { slug: current.slug, title: current.title } });
  });
  $('open').addEventListener('click', function (e) {
    if (!embedded) return;
    e.preventDefault();
    post('open-external', { url: externalUrl(cfg.port, current ? current.slug : '') });
  });

  function loadPages() {
    return fetch('/api/pages', { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : []; })
      .then(function (list) { pages = Array.isArray(list) ? list : []; return pages; })
      .catch(function () { return pages || []; });
  }
  function closeMenu(focusButton) {
    $('menu').hidden = true;
    $('pick').setAttribute('aria-expanded', 'false');
    if (focusButton) $('pick').focus();
  }
  function openMenu() {
    var menu = $('menu');
    menu.textContent = '';
    menu.hidden = false;
    $('pick').setAttribute('aria-expanded', 'true');
    loadPages().then(function (list) {
      menu.textContent = '';
      if (!list.length) {
        var none = document.createElement('li');
        none.className = 'none';
        none.textContent = 'No pages yet.';
        menu.appendChild(none);
        return;
      }
      list.slice(0, 30).forEach(function (p) {
        var li = document.createElement('li');
        var b = document.createElement('button');
        b.type = 'button';
        b.textContent = p.title || p.slug;
        var meta = document.createElement('span');
        meta.className = 'meta';
        meta.textContent = [p.type, p.status].filter(Boolean).join(' \\u00b7 ');
        b.appendChild(meta);
        b.addEventListener('click', function () { closeMenu(true); show({ slug: p.slug, title: p.title, type: p.type, status: p.status, rev: current ? current.rev : 0 }); });
        li.appendChild(b);
        menu.appendChild(li);
      });
      var first = menu.querySelector('button');
      if (first) first.focus();
    });
  }
  $('pick').addEventListener('click', function () { if ($('menu').hidden) openMenu(); else closeMenu(false); });
  $('menu').addEventListener('keydown', function (e) {
    var items = Array.prototype.slice.call($('menu').querySelectorAll('button'));
    var i = items.indexOf(document.activeElement);
    if (e.key === 'Escape') { e.preventDefault(); closeMenu(true); }
    else if (e.key === 'ArrowDown' && items.length) { e.preventDefault(); items[(i + 1) % items.length].focus(); }
    else if (e.key === 'ArrowUp' && items.length) { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
    else if (e.key === 'Home' && items.length) { e.preventDefault(); items[0].focus(); }
    else if (e.key === 'End' && items.length) { e.preventDefault(); items[items.length - 1].focus(); }
  });
  document.addEventListener('click', function (e) {
    if ($('menu').hidden) return;
    if (!$('menu').contains(e.target) && e.target !== $('pick')) closeMenu(false);
  });

  window.addEventListener('message', function (e) {
    var m = readHostMessage(e, window.parent, parentOrigin);
    if (!m) return;
    if (m.type === 'pause') setPaused(true);
    else if (m.type === 'resume') setPaused(false);
    else if (m.type === 'host') {
      canPublish = m.canPublish;
      agent = m.agent;
      $('publish').hidden = !(embedded && current && lastOk && canPublish);
    }
    else if (m.type === 'show') {
      var slug = m.slug;
      loadPages().then(function (list) {
        for (var i = 0; i < list.length; i++) {
          if (list[i].slug === slug) {
            var p = list[i];
            show({ slug: p.slug, title: p.title, type: p.type, status: p.status, rev: current ? current.rev : 0 });
            return;
          }
        }
      });
    }
  });

  var onAdded = cfg.csrf ? installDropZone(window, document, { csrf: cfg.csrf, current: function () { return current; }, frame: function () { return frame; }, agent: function () { return agent; }, canPublish: function () { return canPublish; } }) : null;
  if (embedded) post('ready', { root: cfg.root, port: cfg.port });
  if (cfg.initial) show(cfg.initial);
  if (typeof EventSource !== 'function') return;
  var es = new EventSource('/events?since=' + encodeURIComponent(String((cfg.initial && cfg.initial.rev) || 0)));
  es.addEventListener('added', function (e) {
    var a;
    try { a = JSON.parse(e.data); } catch (err) { return; }
    if (onAdded) onAdded(a);
  });
  es.addEventListener('show', function (e) {
    var p;
    try { p = JSON.parse(e.data); } catch (err) { return; }
    if (paused) {
      waiting = p;
      var t = String(p.title || p.slug);
      $('next').textContent = 'New: ' + (t.length > 24 ? t.slice(0, 23) + '\u2026' : t);
      $('next').title = 'Show ' + t;
      $('next').hidden = false;
      return;
    }
    show(p);
  });
})();
</script>
</body>
</html>
`;
}
