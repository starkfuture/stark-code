// @ts-check
/**
 * The publish bundle and its manifest (CONTRACTS.md 12.1). Shared by `spage publish`
 * and the publish guard (guard.js), so it uses Node built-ins only and loads fast.
 *
 * Layout: <root>/pages/.spage/publish/<slug>/manifest.json, and each bundle file at
 * <root>/pages/.spage/publish/<slug>/files/<path>, where <path> is its path on Pages.
 * <root>/pages/.spage/publish/current.json points at the bundle prepared last (the only
 * one the guard lets Claude upload).
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { isSlug, stateDir } from '../pages.js';

/** A manifest is good for 30 minutes (the guard denies older ones). */
export const MANIFEST_MAX_AGE_MS = 30 * 60 * 1000;
/** Clock skew we accept for a manifest made "in the future". */
const FUTURE_SKEW_MS = 2 * 60 * 1000;
export const MAX_BUNDLE_FILES = 200;
/** Size caps the guard checks before it hashes anything (a huge bundle must not run it past its timeout). */
export const MAX_FILE_BYTES = Object.freeze({ image: 1_000_000, text: 2 * 1024 * 1024, font: 5 * 1024 * 1024 });
export const MAX_BUNDLE_BYTES = 50 * 1024 * 1024;

/**
 * @typedef {{ path: string, local: string, sha256: string, size: number, contentType: string }} ManifestFile
 * @typedef {{
 *   v: 1, slug: string, title: string, type: string, status: string, project: string,
 *   pageHash: string, createdAt: string, bundleHash: string, files: ManifestFile[],
 * }} Manifest
 * @typedef {{ root: string, slug: string, dir: string, file: string, manifest: Manifest }} FoundManifest
 */

/** @param {string} root */
export function publishDir(root) {
  return path.join(stateDir(root), 'publish');
}

/** @param {string} root @param {string} slug */
export function bundleDir(root, slug) {
  return path.join(publishDir(root), slug);
}

/** @param {string} root @param {string} slug */
export function manifestPath(root, slug) {
  return path.join(bundleDir(root, slug), 'manifest.json');
}

/** The "prepared last" pointer. @param {string} root */
export function currentPath(root) {
  return path.join(publishDir(root), 'current.json');
}

/**
 * @typedef {{ slug: string, root: string, project: string, bundleHash: string, createdAt: string }} CurrentBundle
 */

/**
 * Write the "prepared last" pointer (latest prepare wins), atomically.
 * @param {string} root @param {CurrentBundle} cur
 */
export function writeCurrent(root, cur) {
  const file = currentPath(root);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(cur, null, 2) + '\n');
  fs.renameSync(tmp, file);
}

/**
 * Read the "prepared last" pointer of a folder. Null when missing, malformed, a symlink,
 * or when it names another folder than the one it sits in.
 * @param {string} root
 * @returns {CurrentBundle | null}
 */
export function readCurrent(root) {
  try {
    const file = currentPath(root);
    if (fs.lstatSync(file).isSymbolicLink()) return null;
    const v = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!v || typeof v !== 'object' || Array.isArray(v)) return null;
    if (!isSlug(v.slug) || typeof v.project !== 'string' || !PROJECT_RE.test(v.project)) return null;
    if (typeof v.bundleHash !== 'string' || !HEX64.test(v.bundleHash)) return null;
    if (typeof v.createdAt !== 'string' || Number.isNaN(Date.parse(v.createdAt))) return null;
    if (typeof v.root !== 'string' || !sameFolder(v.root, root)) return null;
    return { slug: v.slug, root, project: v.project, bundleHash: v.bundleHash, createdAt: v.createdAt };
  } catch {
    return null;
  }
}

/** @param {string} a @param {string} b */
function sameFolder(a, b) {
  const ra = realOrNull(a) ?? path.resolve(a);
  const rb = realOrNull(b) ?? path.resolve(b);
  return process.platform === 'darwin' || process.platform === 'win32' ? ra.toLowerCase() === rb.toLowerCase() : ra === rb;
}

/** @param {string} root */
export function publishConfigPath(root) {
  return path.join(stateDir(root), 'publish.json');
}

/** @param {Uint8Array | string} data */
export function sha256(data) {
  return crypto.createHash('sha256').update(data).digest('hex');
}

/** @param {Uint8Array | string} data the `sha384-<base64>` form used by `integrity` */
export function sriSha384(data) {
  return `sha384-${crypto.createHash('sha384').update(data).digest('base64')}`;
}

/**
 * SHA-256 of the sorted `path:sha256` lines.
 * @param {Array<{ path: string, sha256: string }>} files
 */
export function bundleHashOf(files) {
  const lines = files.map((f) => `${f.path}:${f.sha256}`).sort();
  return sha256(lines.join('\n'));
}

const CONTENT_TYPES = /** @type {Record<string, string>} */ ({
  '.html': 'text/html',
  '.css': 'text/css',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.otf': 'font/otf',
  '.woff2': 'font/woff2',
});

/** @param {string} p @returns {string | null} */
export function contentTypeFor(p) {
  const ext = path.posix.extname(p).toLowerCase();
  return Object.hasOwn(CONTENT_TYPES, ext) ? CONTENT_TYPES[ext] : null;
}

const HEX64 = /^[0-9a-f]{64}$/;
const SAFE_NAME = '[A-Za-z0-9][A-Za-z0-9._-]{0,127}';
/** Paths a bundle may hold, on Pages inside the project. */
const BUNDLE_PATH = new RegExp(
  `^(?:([a-z0-9-]{3,64})/(?:index\\.html|img/${SAFE_NAME})|_stark/(?:r/[0-9A-Za-z.+-]{1,40}/page\\.css|fonts/${SAFE_NAME}))$`,
);

/** Characters of the content hash in a shared file's published path. */
export const SHORT_HASH_LENGTH = 12;

/**
 * A shared Stark file: under _stark/ (the stylesheet and the fonts). It is the same for
 * every page and holds no page content. @param {string} p
 */
export function isSharedPath(p) {
  return typeof p === 'string' && p.startsWith('_stark/');
}

/**
 * The published name of a font: its file name with a short content hash before the
 * extension (StarkSans-Regular-0123456789ab.otf). Pages in one project share _stark/, so a
 * later publish with other font bytes gets a new path and never overwrites a font that an
 * earlier page's stylesheet points at.
 * @param {string} file @param {string} sha the font's sha256 (hex)
 */
export function hashedFontName(file, sha) {
  const ext = path.posix.extname(file);
  return `${file.slice(0, file.length - ext.length)}-${sha.slice(0, SHORT_HASH_LENGTH)}${ext}`;
}

const CSS_ADDRESS = /^_stark\/r\/[0-9A-Za-z.+-]{1,27}-([0-9a-f]{12})\/page\.css$/;
const FONT_ADDRESS = /^_stark\/fonts\/[A-Za-z0-9][A-Za-z0-9._-]{0,100}-([0-9a-f]{12})\.(?:otf|woff2)$/;

/**
 * Does a shared file's path carry the start of its own sha256? Only such files may be
 * uploaded without asking: their path can never hold other bytes.
 * @param {string} p @param {string} sha
 */
export function contentAddressOk(p, sha) {
  const m = CSS_ADDRESS.exec(p) ?? FONT_ADDRESS.exec(p);
  return !!m && typeof sha === 'string' && m[1] === sha.slice(0, SHORT_HASH_LENGTH);
}

/** A Pages project name: 1 to 100 characters, letters, digits, space, dot, underscore, hyphen. */
export const PROJECT_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,99}$/;

/**
 * Check a parsed manifest's shape. Returns a plain problem, or null when it is fine.
 * @param {unknown} m
 * @returns {string | null}
 */
export function manifestProblem(m) {
  if (!m || typeof m !== 'object' || Array.isArray(m)) return 'not an object';
  const o = /** @type {Record<string, any>} */ (m);
  if (o.v !== 1) return 'unknown version';
  if (!isSlug(o.slug)) return 'bad slug';
  for (const k of ['title', 'type', 'status']) if (typeof o[k] !== 'string') return `bad ${k}`;
  if (typeof o.project !== 'string' || !PROJECT_RE.test(o.project)) return 'bad project';
  if (typeof o.pageHash !== 'string' || !HEX64.test(o.pageHash)) return 'bad pageHash';
  if (typeof o.bundleHash !== 'string' || !HEX64.test(o.bundleHash)) return 'bad bundleHash';
  if (typeof o.createdAt !== 'string' || Number.isNaN(Date.parse(o.createdAt))) return 'bad createdAt';
  if (!Array.isArray(o.files) || o.files.length === 0 || o.files.length > MAX_BUNDLE_FILES) return 'bad files';
  const seen = new Set();
  for (const f of o.files) {
    if (!f || typeof f !== 'object') return 'bad file entry';
    if (typeof f.path !== 'string') return 'bad file path';
    const m2 = BUNDLE_PATH.exec(f.path);
    if (!m2) return `path not allowed: ${f.path}`;
    if (m2[1] !== undefined && m2[1] !== o.slug) return `path outside the page: ${f.path}`;
    if (seen.has(f.path)) return `duplicate path: ${f.path}`;
    seen.add(f.path);
    if (f.local !== `files/${f.path}`) return `bad local path for ${f.path}`;
    if (typeof f.sha256 !== 'string' || !HEX64.test(f.sha256)) return `bad sha256 for ${f.path}`;
    if (!Number.isSafeInteger(f.size) || f.size < 0) return `bad size for ${f.path}`;
    if (typeof f.contentType !== 'string' || f.contentType !== contentTypeFor(f.path)) return `bad content type for ${f.path}`;
  }
  if (!seen.has(`${o.slug}/index.html`)) return 'no index.html';
  return null;
}

/**
 * Read a page's manifest. Null when missing, unreadable or malformed.
 * @param {string} root @param {string} slug
 * @returns {Manifest | null}
 */
export function readManifest(root, slug) {
  try {
    const file = manifestPath(root, slug);
    if (fs.lstatSync(file).isSymbolicLink()) return null;
    const m = JSON.parse(fs.readFileSync(file, 'utf8'));
    return manifestProblem(m) === null ? m : null;
  } catch {
    return null;
  }
}

/**
 * All well-formed manifests under <root>/pages/.spage/publish/.
 * @param {string} root
 * @returns {FoundManifest[]}
 */
export function findManifests(root) {
  /** @type {FoundManifest[]} */
  const out = [];
  let names;
  try {
    names = fs.readdirSync(publishDir(root));
  } catch {
    return out;
  }
  for (const slug of names) {
    if (!isSlug(slug)) continue;
    const manifest = readManifest(root, slug);
    if (manifest && manifest.slug === slug) {
      out.push({ root, slug, dir: bundleDir(root, slug), file: manifestPath(root, slug), manifest });
    }
  }
  return out;
}

/** @param {string} p */
function realOrNull(p) {
  try { return fs.realpathSync(p); } catch { return null; }
}

/**
 * Read one bundle file, refusing symlinks and anything outside the bundle folder.
 * @param {string} root @param {Manifest} manifest @param {ManifestFile} f
 * @returns {Buffer}
 */
export function readBundleFile(root, manifest, f) {
  const dir = bundleDir(root, manifest.slug);
  const abs = path.join(dir, ...f.local.split('/'));
  const realDir = realOrNull(dir);
  const st = fs.lstatSync(abs);
  if (st.isSymbolicLink() || !st.isFile()) throw new Error(`${f.path} is not a plain file in the bundle.`);
  if (st.size !== f.size) throw new Error(`${f.path} changed after prepare`);
  const realFile = realOrNull(abs);
  if (!realDir || !realFile || !realFile.startsWith(realDir + path.sep)) throw new Error(`${f.path} is outside the bundle folder.`);
  return fs.readFileSync(abs);
}

/**
 * The page's index.md for a bundle: <root>/pages/<slug>/index.md, a real file.
 * @param {string} root @param {string} slug
 */
export function pageFileFor(root, slug) {
  return path.join(root, 'pages', slug, 'index.md');
}

/**
 * Check a manifest against the disk: fresh, the page unchanged, every file unchanged.
 * @param {string} root
 * @param {Manifest} manifest
 * @param {{ now?: Date, maxAgeMs?: number, manifestFile?: string }} [opts]
 * @returns {{ ok: true, totalSize: number } | { ok: false, reason: string }}
 */
export function verifyBundle(root, manifest, opts = {}) {
  const now = (opts.now ?? new Date()).getTime();
  const maxAge = opts.maxAgeMs ?? MANIFEST_MAX_AGE_MS;
  const created = Date.parse(manifest.createdAt);
  if (!(created <= now + FUTURE_SKEW_MS) || now - created > maxAge) return { ok: false, reason: 'the manifest is older than 30 minutes' };
  try {
    const mtime = fs.statSync(opts.manifestFile ?? manifestPath(root, manifest.slug)).mtimeMs;
    if (now - mtime > maxAge) return { ok: false, reason: 'the manifest is older than 30 minutes' };
  } catch {
    return { ok: false, reason: 'the manifest is missing' };
  }
  const pageFile = pageFileFor(root, manifest.slug);
  try {
    const st = fs.lstatSync(pageFile);
    const dirSt = fs.lstatSync(path.dirname(pageFile));
    if (st.isSymbolicLink() || !st.isFile() || dirSt.isSymbolicLink()) return { ok: false, reason: 'index.md is not a plain file' };
    if (sha256(fs.readFileSync(pageFile)) !== manifest.pageHash) return { ok: false, reason: 'index.md changed after prepare' };
  } catch {
    return { ok: false, reason: 'index.md is missing' };
  }
  let total = 0;
  for (const f of manifest.files) {
    let data;
    try {
      data = readBundleFile(root, manifest, f);
    } catch (e) {
      return { ok: false, reason: e instanceof Error ? e.message : `${f.path} cannot be read` };
    }
    if (data.length !== f.size || sha256(data) !== f.sha256) return { ok: false, reason: `${f.path} changed after prepare` };
    total += data.length;
  }
  if (bundleHashOf(manifest.files) !== manifest.bundleHash) return { ok: false, reason: 'the bundle hash does not match its files' };
  return { ok: true, totalSize: total };
}

/**
 * The size caps of a manifest's files, or null when it is within them.
 * @param {Manifest} m
 * @returns {string | null}
 */
export function bundleSizeProblem(m) {
  let total = 0;
  for (const f of m.files) {
    const kind = f.contentType.startsWith('image/') ? 'image' : f.contentType.startsWith('font/') ? 'font' : 'text';
    if (f.size > MAX_FILE_BYTES[kind]) return `${f.path} is larger than a bundle file may be`;
    total += f.size;
  }
  return total > MAX_BUNDLE_BYTES ? 'the bundle is larger than 50 MB' : null;
}

/** @param {number} n */
export function formatBytes(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

/** Text files in a bundle, which the secret scan reads. @param {ManifestFile} f */
export function isTextFile(f) {
  return f.contentType.startsWith('text/');
}
