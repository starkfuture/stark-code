---
schema: 1
type: guide
title: How to do the task
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Before you start

```pending
What the reader needs: access, tools, versions.
```

## Steps

```pending
Numbered steps. One action per step, with the exact command or click.
```

## Check it worked

```pending
What the reader sees when it worked.
```

## If it breaks

```pending
The common errors and what to do about each.
```
