---
schema: 1
type: decision
title: Which option we take for the thing being decided
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Context

```pending
What is being decided, why now, and what limits the choice. Two to five short sentences. Name the source of every fact.
```

## Options

```options
- name: First option
  chosen: true
  pros: [The strongest reason for it]
  cons: [The strongest reason against it]
  cost: about 2 days
- name: Second option
  pros: [The strongest reason for it]
  cons: [The strongest reason against it]
  cost: about 5 days
```

## Decision

```pending
The choice in one or two sentences: what we do, from when, and who decided.
```

## Why

```pending
The reasons, strongest first. Say what would change the decision.
```

## Consequences

```pending
What changes, who does what next, and what we give up.
```
