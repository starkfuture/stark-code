---
description: Turn the current discussion into a typed Stark page (decision, report and more)
argument-hint: "[type] [slug]"
---

Turn the current discussion into a typed Stark page. Follow the `stark-pages` skill exactly.

Arguments (both optional): $ARGUMENTS
- The first word may be a page type: decision, report, explainer, guide, plan, spec, data or mock.
- The second may be a slug: 3 to 64 lowercase letters, digits and hyphens.
- If no type is given, pick the one that fits: `decision` when the discussion ends in a choice between options, `report` when it answers a question with findings. Use another type only when neither fits.
- If no slug is given, make a short one from the title.

Steps:
1. Read the template for the type: `${CLAUDE_PLUGIN_ROOT}/skills/stark-pages/templates/<type>.md`.
2. Write `pages/<slug>/index.md` in the project folder (the folder Claude Code started in) with the Write tool. Use only facts from this conversation and the files and sources it used. List each source in `sources`. Fill every section. Leave a `pending` block only where the facts are not known yet, and say so in your reply.
3. The page check runs after you save. If it reports errors, fix them and save again. After two failed fixes, stop and tell the user what is left.
4. Reply in two or three lines: the bottom line and the page path. Do not paste the page into the chat.
