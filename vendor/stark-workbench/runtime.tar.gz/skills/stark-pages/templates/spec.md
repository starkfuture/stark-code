---
schema: 1
type: spec
title: What the thing must do
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Summary

```pending
What is being specified and for whom.
```

## Requirements

```pending
Numbered requirements. Each one testable.
```

## Out of scope

```pending
What this spec does not cover.
```

## Open questions

```pending
What still needs an answer, and from whom.
```
