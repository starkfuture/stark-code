// @ts-check
/**
 * Page folders, slugs and a small header reader used for listings.
 * The full checker lives in @stark/page-format; this file only finds pages
 * and reads the few header fields the mirror shows (title, type, status).
 */
import fs from 'node:fs';
import path from 'node:path';

export const PAGE_TYPES = ['decision', 'report', 'explainer', 'guide', 'plan', 'spec', 'data', 'mock'];
export const SLUG_RE = /^[a-z0-9-]{3,64}$/;
export const STATE_DIR = '.spage';

/** @param {unknown} s */
export function isSlug(s) {
  return typeof s === 'string' && SLUG_RE.test(s);
}

/** @param {string} root */
export function pagesDir(root) {
  return path.join(root, 'pages');
}

/** @param {string} root */
export function stateDir(root) {
  return path.join(pagesDir(root), STATE_DIR);
}

/**
 * @typedef {{ root: string, slug: string, dir: string, file: string }} PageRef
 */

/**
 * Find the page a file belongs to: the deepest `pages/<slug>/` folder on its path.
 * Returns null for files outside any page folder, in `pages/.spage/`, or in `.render/`.
 * @param {string} filePath absolute or relative path
 * @param {string} [base] folder to resolve a relative path against
 * @returns {PageRef | null}
 */
export function findPageForFile(filePath, base = process.cwd()) {
  if (typeof filePath !== 'string' || filePath.length === 0 || filePath.includes('\0')) return null;
  const abs = path.resolve(base, filePath);
  const parts = abs.split(path.sep);
  for (let i = parts.length - 2; i >= 1; i--) {
    if (parts[i] !== 'pages') continue;
    const slug = parts[i + 1];
    if (!isSlug(slug)) continue;
    const rest = parts.slice(i + 2);
    if (rest.includes('.render')) return null;
    const root = parts.slice(0, i).join(path.sep) || path.sep;
    const dir = path.join(root, 'pages', slug);
    return { root, slug, dir, file: path.join(dir, 'index.md') };
  }
  return null;
}

/**
 * Turn a command-line page argument (a page folder or its index.md) into a PageRef.
 * The slug and root are filled when the folder sits in a `pages/` folder; otherwise
 * the slug is the folder name and root is its parent's parent.
 * @param {string} arg
 * @param {string} [cwd]
 * @returns {{ dir: string, file: string, slug: string, root: string }}
 */
export function resolvePageArg(arg, cwd = process.cwd()) {
  const abs = path.resolve(cwd, arg);
  const isFile = path.basename(abs) === 'index.md' || abs.endsWith('.md');
  const file = isFile ? abs : path.join(abs, 'index.md');
  const dir = path.dirname(file);
  const found = findPageForFile(file);
  if (found && found.dir === dir) return found;
  return { dir, file, slug: path.basename(dir), root: path.dirname(path.dirname(dir)) };
}

/**
 * List page folders under `<root>/pages/` that hold an index.md.
 * @param {string} root
 * @param {{ fs?: typeof fs }} [opts]
 * @returns {PageRef[]}
 */
export function listPageRefs(root, opts = {}) {
  const f = opts.fs ?? fs;
  const dir = pagesDir(root);
  /** @type {string[]} */
  let names = [];
  try {
    names = f.readdirSync(dir);
  } catch {
    return [];
  }
  /** @type {PageRef[]} */
  const out = [];
  for (const slug of names.sort()) {
    if (!isSlug(slug)) continue;
    const file = path.join(dir, slug, 'index.md');
    try {
      if (f.statSync(file).isFile()) out.push({ root, slug, dir: path.join(dir, slug), file });
    } catch {
      // folder without index.md: not a page yet
    }
  }
  return out;
}

/**
 * Read a few top-level scalar fields from the YAML header without a YAML parser.
 * Good enough for titles in listings; the checker does the real parsing.
 * @param {string} text
 * @returns {Record<string, string>}
 */
export function readHeaderFields(text) {
  /** @type {Record<string, string>} */
  const out = {};
  if (typeof text !== 'string') return out;
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/);
  if (lines[0]?.trim() !== '---') return out;
  for (let i = 1; i < lines.length && i < 400; i++) {
    const line = lines[i];
    if (line.trim() === '---') break;
    const m = /^([A-Za-z][A-Za-z0-9_]*):[ \t]*(.*)$/.exec(line);
    if (!m) continue;
    out[m[1]] = unquote(m[2]);
  }
  return out;
}

/** @param {string} raw */
function unquote(raw) {
  const v = raw.trim();
  if (v.startsWith('"')) {
    const end = findClosingDouble(v);
    const lit = end > 0 ? v.slice(0, end + 1) : v + '"';
    try {
      return String(JSON.parse(lit));
    } catch {
      return lit.slice(1, -1);
    }
  }
  if (v.startsWith("'")) {
    const end = v.indexOf("'", 1);
    // YAML single quotes escape a quote by doubling it
    let s = '';
    let i = 1;
    while (i < v.length) {
      if (v[i] === "'" && v[i + 1] === "'") { s += "'"; i += 2; continue; }
      if (v[i] === "'") break;
      s += v[i++];
    }
    return end < 0 ? v.slice(1) : s;
  }
  return v.replace(/\s+#.*$/, '').trim();
}

/** @param {string} v */
function findClosingDouble(v) {
  for (let i = 1; i < v.length; i++) {
    if (v[i] === '\\') { i++; continue; }
    if (v[i] === '"') return i;
  }
  return -1;
}

/**
 * Metadata for listings: slug, title, type, status, mtime (ISO).
 * @param {PageRef} ref
 * @param {{ fs?: typeof fs }} [opts]
 * @returns {{ slug: string, title: string, type: string, status: string, mtime: string, mtimeMs: number } | null}
 */
export function readPageMeta(ref, opts = {}) {
  const f = opts.fs ?? fs;
  try {
    const st = f.statSync(ref.file);
    const text = f.readFileSync(ref.file, 'utf8');
    const h = readHeaderFields(text);
    return {
      slug: ref.slug,
      title: h.title || ref.slug,
      type: h.type || 'unknown',
      status: h.status || 'unknown',
      mtime: new Date(st.mtimeMs).toISOString(),
      mtimeMs: st.mtimeMs,
    };
  } catch {
    return null;
  }
}

/**
 * All pages under root with metadata, newest first.
 * @param {string} root
 * @param {{ fs?: typeof fs }} [opts]
 */
export function listPagesMeta(root, opts = {}) {
  const metas = [];
  for (const ref of listPageRefs(root, opts)) {
    const m = readPageMeta(ref, opts);
    if (m) metas.push(m);
  }
  metas.sort((a, b) => b.mtimeMs - a.mtimeMs || a.slug.localeCompare(b.slug));
  return metas;
}

/** Largest index.md the checker and the mirror look at (200 KB, as in @stark/page-format). */
export const MAX_PAGE_BYTES = 200 * 1024;
/** Above this the hook does not parse the page at all; it only reports the size. */
export const MAX_PARSE_BYTES = 2 * MAX_PAGE_BYTES;

/**
 * True when `<root>/pages/<slug>/index.md` is a real file inside the real pages/ folder:
 * neither the page folder nor index.md is a symlink that leads somewhere else.
 * (A cloned repo can carry symlinks; without this the mirror and the hook would read
 * any file the user can read, such as ~/.ssh/config.)
 * @param {string} root
 * @param {string} slug
 * @param {{ fs?: Pick<typeof fs, 'realpathSync' | 'lstatSync'> }} [opts]
 */
export function isRealPageFile(root, slug, opts = {}) {
  const f = opts.fs ?? fs;
  if (!isSlug(slug)) return false;
  try {
    const realPages = f.realpathSync(pagesDir(root));
    const expected = path.join(realPages, slug, 'index.md');
    if (f.realpathSync(path.join(pagesDir(root), slug, 'index.md')) !== expected) return false;
    if (f.lstatSync(path.join(realPages, slug)).isSymbolicLink()) return false;
    const st = f.lstatSync(expected);
    return st.isFile() && !st.isSymbolicLink();
  } catch {
    return false;
  }
}

/**
 * @typedef {{ code: string, severity: 'error', line: null, field: null, message: string, hint: string }} FileIssue
 * @typedef {{ ok: true, text: string, bytes: number } | { ok: false, issue: FileIssue, bytes: number }} PageText
 */

/**
 * Read index.md with a size cap and a text check. Never throws for a file that exists;
 * throws only when the file cannot be read at all (missing, no permission).
 * @param {string} file
 * @param {{ fs?: Pick<typeof fs, 'statSync' | 'openSync' | 'readSync' | 'closeSync' | 'readFileSync'>, maxBytes?: number }} [opts]
 * @returns {PageText}
 */
export function readPageText(file, opts = {}) {
  const f = opts.fs ?? fs;
  const maxBytes = opts.maxBytes ?? MAX_PARSE_BYTES;
  const bytes = f.statSync(file).size;
  if (bytes > maxBytes) {
    const kb = Math.ceil(bytes / 1024);
    return {
      ok: false, bytes,
      issue: {
        code: 'size', severity: 'error', line: null, field: null,
        message: `The page is ${kb} KB. The limit is ${MAX_PAGE_BYTES / 1024} KB.`,
        hint: 'Move large tables or data into a separate file under the page folder, or split the page in two.',
      },
    };
  }
  const fd = f.openSync(file, 'r');
  let head;
  try {
    head = Buffer.alloc(Math.min(bytes, 8192));
    f.readSync(fd, head, 0, head.length, 0);
  } finally {
    f.closeSync(fd);
  }
  if (head.includes(0)) {
    return {
      ok: false, bytes,
      issue: {
        code: 'not-text', severity: 'error', line: null, field: null,
        message: 'index.md is not a text file.',
        hint: 'Write the page as plain markdown text. Put images and other files in the img/ folder.',
      },
    };
  }
  return { ok: true, text: f.readFileSync(file, 'utf8'), bytes };
}

/**
 * The git directory for the repo that holds `start`, and the repo's top folder.
 * Follows a worktree's `.git` file ("gitdir: ..."). Returns null outside a repo.
 * @param {string} start
 * @returns {{ top: string, gitDir: string } | null}
 */
export function findGitDir(start) {
  let dir = path.resolve(start);
  for (;;) {
    const dotGit = path.join(dir, '.git');
    try {
      const st = fs.statSync(dotGit);
      if (st.isDirectory()) return { top: dir, gitDir: dotGit };
      if (st.isFile()) {
        const m = /^gitdir:\s*(.+?)\s*$/m.exec(fs.readFileSync(dotGit, 'utf8'));
        if (m) return { top: dir, gitDir: path.resolve(dir, m[1]) };
      }
    } catch {
      // no .git here
    }
    const up = path.dirname(dir);
    if (up === dir) return null;
    dir = up;
  }
}

/**
 * Keep drafts out of git: add `/<root relative to the repo top>/pages/` to the repo's
 * .git/info/exclude (a local, uncommitted ignore list). Files already tracked stay
 * tracked. Best effort; returns true when the line is there afterwards.
 * @param {string} root
 */
export function ensureGitExclude(root) {
  try {
    const repo = findGitDir(root);
    if (!repo) return false;
    const rel = path.relative(repo.top, path.resolve(root)).split(path.sep).join('/');
    if (rel.startsWith('..')) return false;
    const line = `/${rel ? `${rel}/` : ''}pages/`;
    // A worktree's gitdir is .git/worktrees/<name>; info/exclude lives in the common dir.
    let gitDir = repo.gitDir;
    try {
      const common = fs.readFileSync(path.join(gitDir, 'commondir'), 'utf8').trim();
      if (common) gitDir = path.resolve(gitDir, common);
    } catch {
      // not a worktree
    }
    const file = path.join(gitDir, 'info', 'exclude');
    let current = '';
    try { current = fs.readFileSync(file, 'utf8'); } catch { /* no exclude file yet */ }
    if (current.split(/\r?\n/).some((l) => l.trim() === line)) return true;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const sep = current && !current.endsWith('\n') ? '\n' : '';
    fs.appendFileSync(file, `${sep}# Stark pages are drafts (added by spage)\n${line}\n`);
    return true;
  } catch {
    return false;
  }
}
