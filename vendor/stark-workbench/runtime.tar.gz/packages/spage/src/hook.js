// @ts-check
/**
 * Claude Code hook entry points.
 *   post-tool-use  check a page Claude just wrote; exit 2 with the problems on stderr
 *   session-start  make sure the mirror runs; print one line for Claude's context
 * Both must never crash on odd input.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as server from './server.js';
import {
  ensureGitExclude, findPageForFile, isRealPageFile, pagesDir, readHeaderFields, readPageText, stateDir,
} from './pages.js';

/**
 * @typedef {{
 *   io: { stdout: { write: (s: string) => unknown }, stderr: { write: (s: string) => unknown }, stdin?: NodeJS.ReadableStream & { isTTY?: boolean } },
 *   env: Record<string, string | undefined>,
 *   cwd: string,
 *   now?: () => Date,
 *   getFormat: () => Promise<import('./deps.js').FormatApi>,
 *   server?: Partial<typeof server>,
 *   sleep?: (ms: number) => Promise<void>,
 *   homedir?: string,
 * }} HookContext
 */

/**
 * Read all of stdin as text, with a size cap and a time limit. A TTY gives ''.
 * When it finishes it pauses and destroys the stream, so an open pipe cannot keep
 * the hook process alive after it has answered.
 * @param {(NodeJS.ReadableStream & { isTTY?: boolean, destroy?: () => void }) | undefined} stdin
 * @param {{ maxBytes?: number, timeoutMs?: number }} [opts]
 * @returns {Promise<string>}
 */
export function readStdin(stdin, opts = {}) {
  const maxBytes = opts.maxBytes ?? 8 * 1024 * 1024;
  const timeoutMs = opts.timeoutMs ?? 1500;
  if (!stdin || stdin.isTTY) return Promise.resolve('');
  return new Promise((resolve) => {
    /** @type {Buffer[]} */
    const chunks = [];
    let size = 0;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      stdin.removeListener('data', onData);
      stdin.removeListener('end', finish);
      stdin.removeListener('error', finish);
      try {
        stdin.pause?.();
        stdin.destroy?.();
      } catch {
        // already closed
      }
      resolve(Buffer.concat(chunks).toString('utf8'));
    };
    /** @param {Buffer | string} c */
    const onData = (c) => {
      const b = Buffer.isBuffer(c) ? c : Buffer.from(c);
      size += b.length;
      if (size > maxBytes) { finish(); return; }
      chunks.push(b);
      // A complete JSON payload is enough: do not wait for an end that may come late.
      if (size < 1024 * 1024 && /[}\]]\s*$/.test(b.toString('utf8', Math.max(0, b.length - 16)))) {
        try {
          JSON.parse(Buffer.concat(chunks).toString('utf8'));
          finish();
        } catch {
          // not complete yet
        }
      }
    };
    const timer = setTimeout(finish, timeoutMs);
    if (typeof timer === 'object' && 'unref' in timer) timer.unref();
    stdin.on('data', onData);
    stdin.once('end', finish);
    stdin.once('error', finish);
    stdin.resume?.();
  });
}

/** @param {string} raw */
function parsePayload(raw) {
  if (!raw || !raw.trim()) return null;
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
  } catch {
    return null;
  }
}

// A path in a shell command that runs through a pages/<slug>/ folder.
const BASH_PAGE_PATH = /(?:^|[\s'"=<>(])((?:~\/)?[\w.\/${}-]*pages\/[a-z0-9-]{3,64}(?:\/[^\s'"`;|&<>)]*)?)/g;

/**
 * Every file path a Write, Edit or MultiEdit payload names, and every pages/<slug>/
 * path in a Bash command (a heredoc or sed -i write is checked like a Write).
 * @param {any} payload
 * @param {{ homedir?: string, projectDir?: string }} [opts] to expand ~ and $CLAUDE_PROJECT_DIR
 * @returns {string[]}
 */
export function pathsFromPayload(payload, opts = {}) {
  /** @type {string[]} */
  const out = [];
  const ti = payload && typeof payload === 'object' ? payload.tool_input : null;
  if (!ti || typeof ti !== 'object') return out;
  for (const key of ['file_path', 'path']) {
    if (typeof ti[key] === 'string' && ti[key]) out.push(ti[key]);
  }
  if (Array.isArray(ti.edits)) {
    for (const e of ti.edits) {
      if (e && typeof e === 'object' && typeof e.file_path === 'string' && e.file_path) out.push(e.file_path);
    }
  }
  if (payload.tool_name === 'Bash' && typeof ti.command === 'string' && ti.command.includes('pages/')) {
    const home = opts.homedir ?? os.homedir();
    for (const m of ti.command.slice(0, 100_000).matchAll(BASH_PAGE_PATH)) {
      let p = m[1];
      if (p.startsWith('~/')) p = path.join(home, p.slice(2));
      p = p.replace(/^\$\{?HOME\}?(?=\/)/, home);
      if (opts.projectDir) p = p.replace(/^\$\{?CLAUDE_PROJECT_DIR\}?(?=\/)/, opts.projectDir);
      if (p.includes('$')) continue; // another variable: cannot tell where it points
      out.push(p);
    }
  }
  return [...new Set(out)];
}

/** @param {string} from @param {string} to */
function rel(from, to) {
  const r = path.relative(from, to);
  return r && !r.startsWith('..') && !path.isAbsolute(r) ? r : to;
}

/** @param {string} p */
function real(p) {
  try { return fs.realpathSync(p); } catch { return path.resolve(p); }
}

/** @param {string} a @param {string} b */
function sameDir(a, b) {
  return path.resolve(a) === path.resolve(b) || real(a) === real(b);
}

/**
 * The session's project folder: CLAUDE_PROJECT_DIR, else the payload's cwd, else ours.
 * @param {HookContext} ctx @param {any} payload
 */
function projectDirOf(ctx, payload) {
  const fromPayload = payload && typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : null;
  return path.resolve(ctx.env.CLAUDE_PROJECT_DIR || fromPayload || ctx.cwd);
}

/**
 * Append one line to pages/.spage/checks.jsonl (first-pass validation rate). Best effort.
 * @param {string} root @param {Record<string, unknown>} entry
 */
function logCheck(root, entry) {
  try {
    server.ensureStateDir(root);
    fs.appendFileSync(path.join(stateDir(root), 'checks.jsonl'), JSON.stringify(entry) + '\n');
  } catch {
    // logging is optional
  }
}

/** @param {string} root @param {string} slug */
function prevFile(root, slug) {
  return path.join(stateDir(root), 'prev', `${slug}.md`);
}

/**
 * @param {HookContext} ctx
 * @returns {Promise<number>} exit code
 */
export async function hookPostToolUse(ctx) {
  const srv = { ...server, ...(ctx.server ?? {}) };
  const now = ctx.now ?? (() => new Date());
  let payload;
  try {
    payload = parsePayload(await readStdin(ctx.io.stdin));
  } catch {
    return 0;
  }
  if (!payload) return 0;
  const base = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : ctx.cwd;
  const project = projectDirOf(ctx, payload);
  const home = ctx.homedir ?? os.homedir();
  const starkRoot = path.join(home, 'Stark');
  /** @type {Map<string, import('./pages.js').PageRef>} */
  const pages = new Map();
  for (const p of pathsFromPayload(payload, { homedir: home, projectDir: project })) {
    const ref = findPageForFile(p, base);
    if (ref && !pages.has(ref.file)) pages.set(ref.file, ref);
  }
  if (pages.size === 0) return 0;

  let format;
  try {
    format = await ctx.getFormat();
  } catch (e) {
    ctx.io.stderr.write(`Stark page check skipped: ${e instanceof Error ? e.message : String(e)}\n`);
    return 1;
  }

  let failed = false;
  /** @type {string[]} */
  const notes = [];
  for (const ref of pages.values()) {
    // Only real files in the real pages/ folder: no symlinks out of it.
    if (!isRealPageFile(ref.root, ref.slug)) continue; // no index.md yet (an image written first), or a symlink
    /** @type {import('./pages.js').PageText} */
    let read;
    try {
      read = readPageText(ref.file);
    } catch {
      continue;
    }
    const inProject = sameDir(ref.root, project);
    const ours = inProject || sameDir(ref.root, starkRoot);
    // Other tools use pages/<name>/index.md too (Next, Astro, Docusaurus, Nuxt...).
    // Outside our own pages/ folders, check only files that say they are Stark pages.
    const starkHeader = read.ok && readHeaderFields(read.text).schema === '1';
    if (!ours && !starkHeader) continue;
    // Hide pages/ from git only for a real Stark page in our own folders: a framework's
    // pages/<name>/index.md (Next, Nuxt, Docusaurus...) must stay visible to git.
    if (ours && starkHeader) ensureGitExclude(ref.root);

    const label = rel(base, ref.file);
    const tool = typeof payload.tool_name === 'string' ? payload.tool_name : null;
    if (!read.ok) {
      failed = true;
      ctx.io.stderr.write(`Stark page check: ${label} has problems.\n`);
      ctx.io.stderr.write(format.formatIssues({ errors: [read.issue], warnings: [] }, { file: label }).trimEnd() + '\n');
      ctx.io.stderr.write(`Fix ${label} and save it again. Do not tell the user the page is ready until this check passes.\n`);
      if (ours) logCheck(ref.root, { at: now().toISOString(), slug: ref.slug, ok: false, errors: 1, warnings: 0, tool });
      continue;
    }
    let previousText;
    if (ours) {
      try { previousText = fs.readFileSync(prevFile(ref.root, ref.slug), 'utf8'); } catch { /* first version */ }
    }
    let result;
    try {
      result = format.validatePage(read.text, { path: ref.file, ...(previousText !== undefined ? { previousText } : {}) });
    } catch (e) {
      ctx.io.stderr.write(`Stark page check crashed on ${label}: ${e instanceof Error ? e.message : String(e)}\n`);
      return 1;
    }
    if (ours) {
      logCheck(ref.root, { at: now().toISOString(), slug: ref.slug, ok: result.ok, errors: result.errors.length, warnings: result.warnings.length, tool });
    }
    if (!result.ok) {
      failed = true;
      ctx.io.stderr.write(`Stark page check: ${label} has problems.\n`);
      ctx.io.stderr.write(format.formatIssues(result, { file: label }).trimEnd() + '\n');
      ctx.io.stderr.write(`Fix the errors in ${label} and save it again. Do not tell the user the page is ready until this check passes.\n`);
      continue;
    }
    if (ours) {
      // The last valid text, for the "section shrank" warning next time.
      try {
        server.ensureStateDir(ref.root);
        fs.mkdirSync(path.dirname(prevFile(ref.root, ref.slug)), { recursive: true });
        fs.writeFileSync(prevFile(ref.root, ref.slug), read.text);
      } catch {
        // optional
      }
    }
    let mirror = '';
    try {
      const sent = await srv.notifyMirror(ref.root, ref.slug, { timeoutMs: 1500 });
      if (sent.sent) mirror = ' The browser mirror shows it.';
      else if (inProject && !(await srv.liveMirror(ref.root, { timeoutMs: 300 }))) {
        // First page in this project: start the mirror now (it opens the follower once a day).
        if (srv.spawnDetachedMirror(ref.root, { open: !openedOn(ref.root, localDay(now())) })) {
          mirror = ' The browser mirror is starting and will show it.';
        }
      }
    } catch {
      // the mirror is optional
    }
    const w = result.warnings.length;
    const head = `Stark page check: ${label} is valid (0 errors${w ? `, ${w} warning${w === 1 ? '' : 's'}` : ''}).${mirror}`;
    notes.push(w ? `${head}\n${format.formatIssues(result, { file: label }).trimEnd()}` : head);
  }
  if (failed) return 2;
  if (notes.length > 0) {
    ctx.io.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: notes.join('\n\n') } }) + '\n');
  }
  return 0;
}

/** @param {Date} d */
export function localDay(d) {
  const p = (/** @type {number} */ n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** @param {string} root @param {string} day */
export function openedOn(root, day) {
  try {
    return JSON.parse(fs.readFileSync(path.join(stateDir(root), 'opened.json'), 'utf8')).day === day;
  } catch {
    return false;
  }
}

/**
 * Record that the follower was opened today. Call only once a live mirror is confirmed.
 * @param {string} root @param {string} day
 */
export function markOpened(root, day) {
  try {
    server.ensureStateDir(root);
    fs.writeFileSync(path.join(stateDir(root), 'opened.json'), JSON.stringify({ day }) + '\n');
  } catch {
    // best effort
  }
}

/**
 * The folder whose pages/ the mirror serves: the session's project folder, the same
 * folder the skill writes pages into. Its pages/ folder is made by the first page.
 * @param {string} project
 */
export function mirrorRootFor(project) {
  return path.resolve(project);
}

/**
 * @param {HookContext} ctx
 * @returns {Promise<number>}
 */
export async function hookSessionStart(ctx) {
  const srv = { ...server, ...(ctx.server ?? {}) };
  const sleep = ctx.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
  const now = ctx.now ?? (() => new Date());
  const started = Date.now();
  try {
    const payload = parsePayload(await readStdin(ctx.io.stdin, { timeoutMs: 300 }));
    const root = mirrorRootFor(projectDirOf(ctx, payload));
    // No pages yet: start nothing (no folder, no process). The first page starts the mirror.
    if (!fs.existsSync(pagesDir(root))) {
      ctx.io.stdout.write('Stark mirror: starts when the first page is saved in pages/.\n');
      return 0;
    }
    const day = localDay(now());
    const openToday = !openedOn(root, day);

    const live = await srv.liveMirror(root, { timeoutMs: 400 });
    if (live) {
      if (openToday) {
        srv.openUrl(srv.followUrl(live.port));
        markOpened(root, day);
      }
      ctx.io.stdout.write(`Stark mirror: ${srv.followUrl(live.port)}\n`);
      return 0;
    }

    // The child opens the follower itself once it listens, and records the day then.
    srv.spawnDetachedMirror(root, { open: openToday });
    while (Date.now() - started < 1000) {
      await sleep(100);
      const s = srv.readMirrorState(root);
      if (s && srv.pidAlive(s.pid)) {
        ctx.io.stdout.write(`Stark mirror: ${srv.followUrl(s.port)}\n`);
        return 0;
      }
    }
    ctx.io.stdout.write('Stark mirror: starting. Run /stark-workbench:mirror to get its address.\n');
    return 0;
  } catch {
    return 0;
  }
}
