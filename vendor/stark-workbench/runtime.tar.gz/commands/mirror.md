---
description: Show the Stark browser mirror's address, or how to start it
---

Show the Stark browser mirror's address.

1. Run: `ELECTRON_RUN_AS_NODE=1 "${STARK_WORKBENCH_NODE:-node}" "${CLAUDE_PLUGIN_ROOT}/packages/spage/bin/spage.js" doctor --root "${CLAUDE_PROJECT_DIR:-$PWD}"`
   The line that starts with `ok` and says "Mirror is running" has the address. If it is there, give the user that address and stop.
2. If the mirror is not running, do not start it from Bash: the sandbox does not allow opening a port, and a server started there would stop with your Bash task. Tell the user either of these:
   - It starts by itself when the next page is saved, or at the start of a new Claude Code session.
   - To start it now, run this in their own terminal:
     `ELECTRON_RUN_AS_NODE=1 "${STARK_WORKBENCH_NODE:-node}" "${CLAUDE_PLUGIN_ROOT}/packages/spage/bin/spage.js" serve --root "<the project folder>" --open`
     Write the real paths into the command, so the user can paste it.

Never open the mirror with browser tools. The user's own browser tab follows the session by itself.
