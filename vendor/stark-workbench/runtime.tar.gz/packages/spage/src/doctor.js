// @ts-check
/**
 * `spage doctor`: a short health report. Each line starts with ok, warn or fail.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { listPageRefs, pagesDir } from './pages.js';
import * as server from './server.js';
import { installHint } from './deps.js';
import { projectDirsFor, savedPagesRules } from './saved-rules.js';

const REPO_ROOT = fileURLToPath(new URL('../../../', import.meta.url));

/**
 * @typedef {{ level: 'ok' | 'warn' | 'fail', text: string }} Check
 */

/**
 * @param {{
 *   root: string,
 *   nodeVersion?: string,
 *   resolve?: (spec: string) => string,
 *   getFormat: () => Promise<import('./deps.js').FormatApi>,
 *   getRenderer: () => Promise<import('./deps.js').RendererApi>,
 *   server?: Partial<typeof server>,
 *   home?: string,
 *   managedSettings?: string,
 *   projectDir?: string,
 * }} o
 * @returns {Promise<Check[]>}
 */
export async function runDoctor(o) {
  const srv = { ...server, ...(o.server ?? {}) };
  /** @type {Check[]} */
  const checks = [];
  const nodeVersion = o.nodeVersion ?? process.versions.node;
  const major = Number(nodeVersion.split('.')[0]);
  checks.push(major >= 22
    ? { level: 'ok', text: `Node ${nodeVersion}` }
    : { level: 'fail', text: `Node ${nodeVersion} is too old. Install Node 22 or newer.` });

  const resolve = o.resolve ?? ((s) => import.meta.resolve(s));
  for (const spec of ['markdown-it', 'js-yaml', '@cfworker/json-schema']) {
    try {
      resolve(spec);
      checks.push({ level: 'ok', text: `${spec} is installed` });
    } catch {
      checks.push({ level: 'fail', text: `${spec} is missing. ${installHint()}` });
    }
  }

  /** @type {import('./deps.js').FormatApi | null} */
  let format = null;
  try {
    format = await o.getFormat();
    checks.push({ level: 'ok', text: 'page checker loads (@stark/page-format)' });
  } catch (e) {
    checks.push({ level: 'fail', text: e instanceof Error ? e.message : String(e) });
  }
  try {
    await o.getRenderer();
    checks.push({ level: 'ok', text: 'renderer loads (@stark/pages-renderer)' });
  } catch (e) {
    checks.push({ level: 'fail', text: e instanceof Error ? e.message : String(e) });
  }

  const pdir = pagesDir(o.root);
  if (!fs.existsSync(pdir)) {
    checks.push({ level: 'warn', text: `No pages folder at ${pdir}. Make one with "spage new report <slug>".` });
  } else {
    const refs = listPageRefs(o.root);
    let invalid = 0;
    if (format) {
      for (const ref of refs) {
        try {
          if (!format.validatePage(fs.readFileSync(ref.file, 'utf8'), { path: ref.file }).ok) invalid += 1;
        } catch {
          invalid += 1;
        }
      }
    }
    const text = `${refs.length} page${refs.length === 1 ? '' : 's'} in ${pdir}` + (format ? `, ${invalid} with errors` : '');
    checks.push({ level: invalid > 0 ? 'warn' : 'ok', text: invalid > 0 ? `${text}. Run "spage list" to see which.` : text });
  }

  const state = srv.readMirrorState(o.root);
  if (!state) {
    checks.push({ level: 'warn', text: 'Mirror is not running. Start it with "spage serve --open".' });
  } else if (!srv.pidAlive(state.pid)) {
    checks.push({ level: 'warn', text: `Mirror state is stale (process ${state.pid} is gone). Start it again with "spage serve --open".` });
  } else {
    const live = await srv.liveMirror(o.root, { timeoutMs: 800 });
    checks.push(live
      ? { level: 'ok', text: `Mirror is running: ${srv.followUrl(state.port)}` }
      : { level: 'warn', text: `Mirror process ${state.pid} runs but does not answer on port ${state.port}. Stop it and run "spage serve" again.` });
    try {
      const mode = fs.statSync(srv.mirrorFile(o.root)).mode & 0o777;
      if (mode & 0o077) checks.push({ level: 'warn', text: `mirror.json can be read by other users (mode ${mode.toString(8)}). Run: chmod 600 ${srv.mirrorFile(o.root)}` });
    } catch {
      // state vanished between checks
    }
  }

  const projectDir = o.projectDir ?? process.env.CLAUDE_PROJECT_DIR;
  checks.push(sandboxCheck({ root: o.root, home: o.home ?? os.homedir(), managedSettings: o.managedSettings, projectDir }));
  checks.push(savedRulesCheck({ root: o.root, home: o.home ?? os.homedir(), managedSettings: o.managedSettings, projectDir }));
  const place = pluginPlaceCheck({ root: o.root, pluginRoot: REPO_ROOT });
  if (place) checks.push(place);

  for (const f of ['.claude-plugin/plugin.json', 'hooks/hooks.json', 'skills/stark-pages/SKILL.md']) {
    const p = path.join(REPO_ROOT, f);
    checks.push(fs.existsSync(p)
      ? { level: 'ok', text: `plugin file ${f}` }
      : { level: 'warn', text: `plugin file ${f} is missing from ${REPO_ROOT}.` });
  }
  return checks;
}

/** Claude Code's managed settings file on this machine. */
function defaultManagedSettings() {
  if (process.platform === 'darwin') return '/Library/Application Support/ClaudeCode/managed-settings.json';
  if (process.platform === 'win32') return 'C:\\ProgramData\\ClaudeCode\\managed-settings.json';
  return '/etc/claude-code/managed-settings.json';
}

/** @param {string} file @returns {any} */
function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

/** @param {string} child @param {string} parent */
function within(child, parent) {
  const r = path.relative(parent, child);
  return r === '' || (!r.startsWith('..') && !path.isAbsolute(r));
}

/**
 * The publish guard's consent is only as strong as Claude's sandbox: the sandbox is what
 * stops Bash from writing ~/.stark/guard (CONTRACTS.md 12.2). Warn when the sandbox is off
 * in Claude Code's settings, when a sandbox write rule reaches ~/.stark, or when this
 * folder holds ~/.stark (the sandbox may write the folder Claude Code runs in).
 * @param {{ root: string, home: string, managedSettings?: string, projectDir?: string }} o
 * @returns {Check}
 */
export function sandboxCheck(o) {
  const home = path.resolve(o.home);
  const guard = path.join(home, '.stark', 'guard');
  // Highest precedence first.
  const files = [
    o.managedSettings ?? defaultManagedSettings(),
    ...projectDirsFor(o.root, home, o.projectDir).flatMap((d) => [path.join(d, '.claude', 'settings.local.json'), path.join(d, '.claude', 'settings.json')]),
    path.join(home, '.claude', 'settings.json'),
  ];
  const settings = files.map(readJson).filter((v) => v && typeof v === 'object');
  const enabled = settings.map((v) => v?.sandbox?.enabled).find((x) => typeof x === 'boolean');
  if (enabled !== true) {
    return {
      level: 'warn',
      text: 'Claude\'s Bash sandbox is not on. Every page file still asks you, but the publish guard keeps its upload records in ~/.stark/guard, and only the sandbox stops Claude\'s commands from changing them. Turn it on with /sandbox in Claude Code.',
    };
  }
  for (const v of settings) {
    const list = v?.sandbox?.filesystem?.allowWrite;
    if (!Array.isArray(list)) continue;
    for (const raw of list) {
      if (typeof raw !== 'string' || !raw) continue;
      const p = raw.replace(/^~(?=\/|$)/, home).replace(/^\/\/+/, '/');
      if (!path.isAbsolute(p)) continue;
      // A glob counts from the folder it starts in (~/.st* may be ~/.stark).
      const g = p.search(/[*?[{]/);
      const abs = path.resolve(g < 0 ? p : p.slice(0, p.lastIndexOf('/', g) + 1) || '/');
      if (within(guard, abs) || within(abs, path.join(home, '.stark'))) {
        return { level: 'warn', text: `Claude's sandbox may write ${raw}, which reaches ~/.stark/guard (the publish guard's records) or the Stark fonts. Remove it from sandbox.filesystem.allowWrite.` };
      }
    }
  }
  if (within(guard, path.resolve(o.root))) {
    return { level: 'warn', text: `${o.root} holds ~/.stark/guard, and Claude's sandbox may write the folder Claude Code starts in. Start Claude Code in a project folder, not your home folder, to publish.` };
  }
  return { level: 'ok', text: 'Claude\'s sandbox is on and cannot write ~/.stark/guard' };
}

/**
 * The guard and the renderer it rebuilds pages with run from the plugin's folder. When that
 * folder is inside the project, Claude's sandbox may change them (and the shared Stark
 * stylesheet uploads without a prompt), so warn.
 * @param {{ root: string, pluginRoot: string }} o
 * @returns {Check | null}
 */
export function pluginPlaceCheck(o) {
  const real = (/** @type {string} */ p) => { try { return fs.realpathSync(p); } catch { return path.resolve(p); } };
  if (!within(real(o.pluginRoot), real(o.root))) return null;
  return {
    level: 'warn',
    text: `The Stark plugin runs from ${o.pluginRoot}, inside this folder, so Claude's sandbox can change the publish guard and the shared style file. Publish from a project folder that does not hold the plugin.`,
  };
}

/**
 * A saved "always allow" rule for a Pages tool that asks may skip the publish question
 * (Claude Code does not say), so the guard denies those calls; tell the user which line
 * to remove (CONTRACTS.md 16.6).
 * @param {{ root: string, home: string, managedSettings?: string, projectDir?: string }} o
 * @returns {Check}
 */
export function savedRulesCheck(o) {
  const hits = savedPagesRules({ home: path.resolve(o.home), projectDirs: projectDirsFor(o.root, o.home, o.projectDir), managedSettings: o.managedSettings });
  if (hits.length === 0) return { level: 'ok', text: 'No saved "always allow" rule covers the Stark Pages tools that ask you' };
  const list = hits.slice(0, 3).map((h) => `"${h.rule}" in ${h.file}`).join('; ');
  return {
    level: 'warn',
    text: `A saved "always allow" rule may skip the publish question, so the guard refuses those Pages calls: ${list}${hits.length > 3 ? ` and ${hits.length - 3} more` : ''}. Remove it, and answer publish prompts with a plain yes.`,
  };
}

/** @param {Check[]} checks */
export function formatChecks(checks) {
  const lines = checks.map((c) => `${c.level.padEnd(4)}  ${c.text}`);
  const fails = checks.filter((c) => c.level === 'fail').length;
  const warns = checks.filter((c) => c.level === 'warn').length;
  lines.push(fails === 0 && warns === 0 ? 'All good.' : `${fails} problem${fails === 1 ? '' : 's'}, ${warns} warning${warns === 1 ? '' : 's'}.`);
  return lines.join('\n') + '\n';
}
