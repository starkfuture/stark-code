// @ts-check
/**
 * Page templates for `spage new`. The templates live with the skill
 * (skills/stark-pages/templates/<type>.md) so Claude and spage use the same text.
 */
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

export const TEMPLATE_DIR = fileURLToPath(new URL('../../../skills/stark-pages/templates/', import.meta.url));

/** @param {string} type */
function fallbackTemplate(type) {
  return `---
schema: 1
type: ${type}
title: Title in plain words
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Summary

\`\`\`pending
Write the bottom line first, then the details.
\`\`\`
`;
}

/**
 * @param {string} type
 * @param {{ dir?: string }} [opts]
 */
export function readTemplate(type, opts = {}) {
  const file = path.join(opts.dir ?? TEMPLATE_DIR, `${type}.md`);
  try {
    return fs.readFileSync(file, 'utf8');
  } catch {
    return fallbackTemplate(type);
  }
}

/** @param {unknown} v */
function yamlValue(v) {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (Array.isArray(v)) return `[${v.map(yamlValue).join(', ')}]`;
  // JSON strings are valid YAML double-quoted strings
  return JSON.stringify(String(v));
}

/**
 * Set header fields in a template. Existing `key:` lines are replaced (comments on
 * them are dropped); missing keys are added before the closing `---`.
 * @param {string} text
 * @param {Record<string, unknown>} fields
 */
export function setHeaderFields(text, fields) {
  const lines = text.split('\n');
  if (lines[0]?.trim() !== '---') throw new Error('Template has no YAML header.');
  let end = lines.findIndex((l, i) => i > 0 && l.trim() === '---');
  if (end < 0) throw new Error('Template header is not closed with ---.');
  for (const [key, value] of Object.entries(fields)) {
    const line = `${key}: ${yamlValue(value)}`;
    const at = lines.findIndex((l, i) => i > 0 && i < end && l.startsWith(`${key}:`));
    if (at >= 0) lines[at] = line;
    else {
      lines.splice(end, 0, line);
      end += 1;
    }
  }
  return lines.join('\n');
}
