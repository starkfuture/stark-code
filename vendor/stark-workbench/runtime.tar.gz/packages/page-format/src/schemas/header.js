// @ts-check
import { PAGE_TYPES, PAGE_STATUSES, AUTHORS, SLUG_PATTERN } from '../constants.js';

const DATE = { type: ['string', 'null'], pattern: '^\\d{4}-\\d{2}-\\d{2}$', format: 'date' };
const SLUG_OR_NULL = { type: ['string', 'null'], pattern: SLUG_PATTERN };

/**
 * JSON Schema (2020-12) for the page header. Unknown fields are allowed here;
 * the checker reports them as warnings (`header-unknown-field`).
 */
export const HEADER_SCHEMA = Object.freeze({
  $schema: 'https://json-schema.org/draft/2020-12/schema',
  $id: 'https://stark.local/schemas/page-header.json',
  title: 'Stark page header',
  type: 'object',
  required: ['schema', 'type', 'title', 'owner', 'status', 'verified', 'sources'],
  properties: {
    schema: { type: 'integer', const: 1 },
    type: { type: 'string', enum: [...PAGE_TYPES] },
    title: { type: 'string', minLength: 3, maxLength: 120, pattern: '^[^\\r\\n]*$' },
    owner: { type: 'string', minLength: 1, maxLength: 80 },
    status: { type: 'string', enum: [...PAGE_STATUSES] },
    verified: DATE,
    reviewBy: DATE,
    sources: { type: 'array', items: { type: 'string', minLength: 1, maxLength: 300 } },
    supersedes: SLUG_OR_NULL,
    id: { type: 'string', pattern: SLUG_PATTERN },
    created: { type: 'string', format: 'date-time' },
    author: { type: 'string', enum: [...AUTHORS] },
    session: { type: 'string', maxLength: 120 },
    supersededBy: SLUG_OR_NULL,
    published: {
      type: 'array',
      items: {
        type: 'object',
        required: ['target', 'url', 'at'],
        properties: {
          target: { type: 'string', minLength: 1 },
          url: { type: 'string', minLength: 1 },
          at: { type: 'string', format: 'date-time' },
        },
      },
    },
  },
});
