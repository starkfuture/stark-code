// @ts-check
/**
 * The local Stark font cache for publishing (CONTRACTS.md 12.1). Pages serves files
 * with a strict CSP (no outside fonts), so a bundle carries its own copies.
 *   spage fonts fetch            fill ~/.stark/fonts/ (used by every project) from assets.starkfuture.com
 * Published fonts come only from ~/.stark/fonts/: a font cache inside the project would be
 * a file Claude can write from inside its sandbox, published under a trusted name.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parseArgs } from 'node:util';
import { stateDir } from '../pages.js';

/** Fallback list, the same files as FONT_FILES in @stark/pages-renderer. */
export const DEFAULT_FONT_FILES = Object.freeze([
  { dir: 'stark-sans', file: 'StarkSans-Regular.otf' },
  { dir: 'stark-sans', file: 'StarkSans-Medium.otf' },
  { dir: 'universal-sans', file: 'Universal-Sans-Display-400.woff2' },
  { dir: 'universal-sans', file: 'Universal-Sans-Display-500.woff2' },
  { dir: 'fragment-mono', file: 'FragmentMono-latin.woff2' },
]);
export const FONT_SOURCE = 'https://assets.starkfuture.com/frontend-assets/fonts';
export const MAX_FONT_BYTES = 5 * 1024 * 1024;

/** @param {string} root */
export function projectFontDir(root) {
  return path.join(stateDir(root), 'fonts');
}

/** @param {string} home */
export function homeFontDir(home) {
  return path.join(home, '.stark', 'fonts');
}

/**
 * True when the bytes look like the font type the file name says.
 * @param {string} file @param {Uint8Array} bytes
 */
export function fontMagicOk(file, bytes) {
  if (bytes.length < 12) return false;
  const tag = Buffer.from(bytes.subarray(0, 4)).toString('latin1');
  if (file.endsWith('.woff2')) return tag === 'wOF2';
  if (file.endsWith('.otf') || file.endsWith('.ttf')) return tag === 'OTTO' || tag === '\u0000\u0001\u0000\u0000' || tag === 'true';
  return false;
}

/**
 * The cached fonts to put in a bundle, from ~/.stark/fonts/ only (never the project's own
 * pages/.spage/fonts/). Files that are missing, symlinks, too big or not fonts are skipped.
 * @param {string} _root the project folder (not used for fonts any more)
 * @param {{ homedir?: string, files?: ReadonlyArray<{ file: string }> }} [opts]
 * @returns {{ dir: string | null, fonts: Array<{ file: string, bytes: Buffer }> }}
 */
export function cachedFonts(_root, opts = {}) {
  const files = opts.files ?? DEFAULT_FONT_FILES;
  const home = opts.homedir ?? os.homedir();
  for (const dir of [homeFontDir(home)]) {
    /** @type {Array<{ file: string, bytes: Buffer }>} */
    const fonts = [];
    for (const { file } of files) {
      const p = path.join(dir, file);
      try {
        const st = fs.lstatSync(p);
        if (!st.isFile() || st.size > MAX_FONT_BYTES) continue;
        const bytes = fs.readFileSync(p);
        if (fontMagicOk(file, bytes)) fonts.push({ file, bytes });
      } catch {
        // not cached
      }
    }
    if (fonts.length > 0) return { dir, fonts };
  }
  return { dir: null, fonts: [] };
}

/**
 * Download the Stark fonts into `dir` (default <root>/pages/.spage/fonts/; the command
 * always passes ~/.stark/fonts/).
 * @param {{
 *   root?: string,
 *   dir?: string,
 *   fetch: typeof globalThis.fetch,
 *   files?: ReadonlyArray<{ dir: string, file: string }>,
 *   source?: string,
 *   timeoutMs?: number,
 * }} o
 * @returns {Promise<Array<{ file: string, ok: boolean, size?: number, error?: string }>>}
 */
export async function fetchFonts(o) {
  const dir = o.dir ?? projectFontDir(/** @type {string} */ (o.root));
  fs.mkdirSync(dir, { recursive: true });
  const source = o.source ?? FONT_SOURCE;
  const out = [];
  for (const f of o.files ?? DEFAULT_FONT_FILES) {
    const url = `${source}/${f.dir}/${f.file}`;
    try {
      const res = await o.fetch(url, { redirect: 'error', signal: AbortSignal.timeout(o.timeoutMs ?? 30_000) });
      if (!res.ok) { out.push({ file: f.file, ok: false, error: `HTTP ${res.status}` }); continue; }
      const bytes = Buffer.from(await res.arrayBuffer());
      if (bytes.length > MAX_FONT_BYTES) { out.push({ file: f.file, ok: false, error: 'too big' }); continue; }
      if (!fontMagicOk(f.file, bytes)) { out.push({ file: f.file, ok: false, error: 'not a font file' }); continue; }
      const tmp = path.join(dir, `.${f.file}.${process.pid}.tmp`);
      fs.writeFileSync(tmp, bytes);
      fs.renameSync(tmp, path.join(dir, f.file));
      out.push({ file: f.file, ok: true, size: bytes.length });
    } catch (e) {
      out.push({ file: f.file, ok: false, error: e instanceof Error ? e.message : String(e) });
    }
  }
  return out;
}

/**
 * @typedef {{
 *   io: { stdout: { write: (s: string) => unknown }, stderr: { write: (s: string) => unknown } },
 *   cwd?: string,
 *   fetch?: typeof globalThis.fetch,
 *   getRenderer?: () => Promise<any>,
 *   homedir?: string,
 * }} FontsContext
 */

/**
 * `spage fonts fetch`. argv is everything after "fonts".
 * @param {string[]} argv
 * @param {FontsContext} ctx
 * @returns {Promise<number>}
 */
export async function fontsCommand(argv, ctx) {
  const io = ctx.io;
  const [sub, ...rest] = argv;
  if (sub !== 'fetch') {
    io.stderr.write('Usage: spage fonts fetch\n');
    return 1;
  }
  try {
    parseArgs({ args: rest, options: {}, allowPositionals: false, strict: true });
  } catch (e) {
    const root = rest.some((a) => a === '--root' || a.startsWith('--root='));
    io.stderr.write(root
      ? 'spage fonts fetch has no --root any more: published fonts come only from ~/.stark/fonts.\nUsage: spage fonts fetch\n'
      : `${e instanceof Error ? e.message : String(e)}\nUsage: spage fonts fetch\n`);
    return 1;
  }
  const dir = homeFontDir(ctx.homedir ?? os.homedir());
  /** @type {ReadonlyArray<{ dir: string, file: string }>} */
  let files = DEFAULT_FONT_FILES;
  try {
    const r = ctx.getRenderer ? await ctx.getRenderer() : null;
    if (r && Array.isArray(r.FONT_FILES) && r.FONT_FILES.length) files = r.FONT_FILES;
  } catch {
    // the fallback list is the same
  }
  const doFetch = ctx.fetch ?? globalThis.fetch;
  const results = await fetchFonts({ dir, fetch: doFetch, files });
  const good = results.filter((r) => r.ok);
  for (const r of results) {
    io.stdout.write(r.ok ? `ok    ${r.file}\n` : `fail  ${r.file}: ${r.error}\n`);
  }
  if (good.length === results.length) {
    io.stdout.write(`Saved ${good.length} fonts in ~/.stark/fonts. Every project now publishes with the Stark fonts.\n`);
    return 0;
  }
  io.stderr.write('Some fonts could not be downloaded. If this ran inside Claude\'s sandbox, the network may be blocked: run it in your own terminal.\n');
  return 1;
}
