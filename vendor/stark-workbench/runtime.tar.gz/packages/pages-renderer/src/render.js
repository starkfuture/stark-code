// @ts-check
// renderPage: a PageDoc (CONTRACTS.md section 5) to one safe, styled HTML document.

import { STARK_CSS, pageCss } from './css.js';
import { md, renderMarkdownWith, renderSource } from './markdown.js';
import { escapeHtml, normalizeAssetBase, slugify, toText } from './safe.js';

/**
 * @typedef {import('./markdown.js').Block} Block
 * @typedef {{ heading: string; key: string; line: number; body: string; blocks: Block[] }} Section
 * @typedef {{ code: string; severity: 'error' | 'warning'; line: number | null; field: string | null;
 *   message: string; expected?: string; found?: string; hint?: string }} Issue
 * @typedef {{
 *   path: string | null; text: string; header: Record<string, unknown> | null;
 *   headerLines: { start: number; end: number } | null; preamble: string;
 *   sections: Section[]; blocks: Block[]; parseIssues: Issue[];
 * }} PageDoc
 * @typedef {{ ok: boolean; errors: Issue[]; warnings: Issue[]; doc?: PageDoc }} ValidationResult
 * @typedef {{
 *   mode?: 'document' | 'fragment';
 *   theme?: 'stark' | 'host';
 *   assetBase?: string;
 *   validation?: ValidationResult | null;
 *   css?: 'inline' | 'external';
 *   cssHref?: string;
 *   cssIntegrity?: string;
 *   fontBase?: string;
 *   view?: 'page' | 'panel';
 *   diagrams?: Map<number, import('./markdown.js').DiagramResult> | null;
 * }} RenderOptions
 * `view: 'panel'` forces the narrow layout at any width (class sp-view-panel; spage /panel).
 * `diagrams` is the result of `await drawDiagrams(doc)` (diagram.js): drawn mermaid blocks by block index.
 */

export const RENDERER_VERSION = '0.1.0';

const LAYOUTS = /** @type {Record<string, { order: string[]; callouts: Record<string, 'lead' | 'plain'>; wide: string[] }>} */ ({
  decision: {
    order: ['context', 'options', 'decision', 'why', 'consequences'],
    callouts: { decision: 'plain' },
    wide: ['options'],
  },
  report: {
    order: ['bottom line', 'findings', 'evidence', 'open questions', 'next steps'],
    callouts: { 'bottom line': 'lead' },
    wide: ['findings'],
  },
});

/** @param {unknown} heading */
function sectionKey(heading) {
  return toText(heading).trim().replace(/\s+/g, ' ').toLowerCase();
}

/** @param {unknown} v @returns {string} */
function str(v) {
  return toText(v).trim();
}

/**
 * Remove a leading "## Heading" line if the parser left it in the body.
 * @param {string} body
 * @param {string} heading
 */
function stripHeadingLine(body, heading) {
  const m = /^\s*##[ \t]+([^\n]*)\n?/.exec(body);
  if (m && sectionKey(m[1].replace(/[ \t]#+[ \t]*$/, '')) === sectionKey(heading)) return body.slice(m[0].length);
  return body;
}

/**
 * Split the preamble into a short subtitle and the rest.
 * @param {string} preamble
 * @param {string} assetPrefix
 * @returns {{ subtitle: string | null, rest: string }}
 */
function splitPreamble(preamble, assetPrefix) {
  const text = preamble.replace(/^\s*\n/, '');
  if (!text.trim()) return { subtitle: null, rest: '' };
  const lead = text.replace(/^\s+/, '');
  const end = lead.search(/\n[ \t]*\n/);
  const first = (end === -1 ? lead : lead.slice(0, end)).trim();
  const rest = end === -1 ? '' : lead.slice(end);
  const looksLikeParagraph = !/^(#|[-*+][ \t]|\d+[.)][ \t]|>|```|~~~|\||!\[|<|[ \t]{4})/.test(first) && !first.includes('```');
  if (looksLikeParagraph && first.length <= 280) {
    return { subtitle: md.renderInline(first.replace(/\s*\n\s*/g, ' '), { assetPrefix }), rest };
  }
  return { subtitle: null, rest: text };
}

/**
 * @param {PageDoc} doc
 * @param {Record<string, unknown>} header
 */
function renderFacts(doc, header) {
  /** @type {Array<[string, string]>} */
  const rows = [];
  // Type and status are in the eyebrow already, so the facts column does not repeat them.
  rows.push(['Owner', str(header.owner) ? escapeHtml(str(header.owner)) : '<span class="sp-muted">Not set</span>']);
  rows.push(['Verified', str(header.verified) ? escapeHtml(str(header.verified)) : '<span class="sp-muted">Not checked yet</span>']);
  if (str(header.reviewBy)) rows.push(['Review by', escapeHtml(str(header.reviewBy))]);
  const sources = Array.isArray(header.sources) ? header.sources.map(str).filter(Boolean) : [];
  rows.push([
    'Sources',
    sources.length
      ? `<ul>${sources.map((s) => `<li>${renderSource(s)}</li>`).join('')}</ul>`
      : '<span class="sp-muted">None listed</span>',
  ]);
  if (str(header.supersedes)) rows.push(['Supersedes', `<span class="sp-id">${escapeHtml(str(header.supersedes))}</span>`]);
  if (str(header.supersededBy)) rows.push(['Superseded by', `<span class="sp-id">${escapeHtml(str(header.supersededBy))}</span>`]);
  if (str(header.id)) rows.push(['Id', `<span class="sp-id">${escapeHtml(str(header.id))}</span>`]);
  const items = rows.map(([label, value]) => `<div class="sp-fact"><dt>${escapeHtml(label)}</dt><dd>${value}</dd></div>`);
  return `<dl class="sp-facts" aria-label="Facts">${items.join('')}</dl>`;
}


/** @param {ValidationResult | null | undefined} validation */
function renderNotice(validation) {
  if (!validation || typeof validation !== 'object') return '';
  const errors = Array.isArray(validation.errors) ? validation.errors.filter(Boolean) : [];
  if (errors.length === 0) return '';
  const warnings = Array.isArray(validation.warnings) ? validation.warnings.length : 0;
  const count = `${errors.length} ${errors.length === 1 ? 'error' : 'errors'}`;
  const warnText = warnings ? ` It also has ${warnings} ${warnings === 1 ? 'warning' : 'warnings'}.` : '';
  const items = errors.map((issue) => {
    const line = typeof issue.line === 'number' ? `Line ${issue.line}` : 'Page';
    const hint = str(issue.hint) ? `<span class="sp-notice__hint">${escapeHtml(str(issue.hint))}</span>` : '';
    const code = str(issue.code) ? ` <span class="sp-notice__code">${escapeHtml(str(issue.code))}</span>` : '';
    return `<li><span class="sp-notice__line">${escapeHtml(line)}</span><span>${escapeHtml(str(issue.message) || 'Unknown problem.')}${code}${hint}</span></li>`;
  });
  return [
    '<section class="sp-notice" aria-label="Problems found">',
    `<p class="sp-notice__title">This page has ${count}</p>`,
    `<p class="sp-notice__intro">Fix ${errors.length === 1 ? 'it' : 'them'} in index.md and the page will render cleanly.${warnText}</p>`,
    `<ul>${items.join('')}</ul>`,
    '</section>',
  ].join('');
}

/** @param {Record<string, unknown>} header */
function renderBanners(header) {
  const banners = [];
  const supersededBy = str(header.supersededBy);
  if (supersededBy) {
    banners.push(
      `<p class="sp-banner sp-banner--superseded"><span class="sp-label">Superseded by</span><span class="sp-id">${escapeHtml(supersededBy)}</span><span class="sp-muted">Read that page for the current answer.</span></p>`,
    );
  }
  const sources = Array.isArray(header.sources) ? header.sources.filter((s) => str(s)) : [];
  if (sources.length === 0) {
    banners.push(
      '<p class="sp-banner sp-banner--illustrative"><span class="sp-label">Illustrative</span><span>No sources listed. Treat it as an example, not as checked facts.</span></p>',
    );
  }
  return banners.length ? `<div class="sp-banners">${banners.join('')}</div>` : '';
}

/**
 * @param {Section} section
 * @param {string} id
 * @param {{ assetPrefix: string, callout?: 'lead' | 'plain', wide?: boolean, blocks: Block[], diagrams?: RenderOptions['diagrams'] }} o
 */
function renderSection(section, id, o) {
  const heading = str(section.heading) || 'Untitled section';
  const body = stripHeadingLine(toText(section.body), heading);
  const own = Array.isArray(section.blocks) ? section.blocks : [];
  const html = renderMarkdownWith(body, { assetBase: o.assetPrefix, minHeading: 3, diagrams: o.diagrams, pageBlocks: o.blocks }, own, o.blocks);
  const inner = o.callout
    ? `<div class="sp-callout${o.callout === 'lead' ? ' sp-callout--lead' : ''}">${html}</div>`
    : html;
  const cls = `sp-section${o.wide ? ' sp-section--wide' : ''}${o.callout ? ' sp-section--callout' : ''}`;
  return `<section class="${cls}" id="${escapeHtml(id)}"><h2>${escapeHtml(heading)}</h2><div class="sp-prose">${inner}</div></section>`;
}

/**
 * Order sections for the page type: required ones first in their set order,
 * then any extra sections in the order the author wrote them.
 * @param {Section[]} sections
 * @param {string} type
 */
function orderSections(sections, type) {
  const layout = Object.hasOwn(LAYOUTS, type) ? LAYOUTS[type] : null;
  if (!layout) return sections.map((s) => ({ section: s, callout: undefined, wide: false }));
  const remaining = [...sections];
  /** @type {Array<{ section: Section, callout: 'lead' | 'plain' | undefined, wide: boolean }>} */
  const out = [];
  for (const key of layout.order) {
    const i = remaining.findIndex((s) => sectionKey(s.key || s.heading) === key);
    if (i === -1) continue;
    const [section] = remaining.splice(i, 1);
    out.push({ section, callout: layout.callouts[key], wide: layout.wide.includes(key) });
  }
  for (const section of remaining) out.push({ section, callout: undefined, wide: false });
  return out;
}

/**
 * Render the <article> for a page.
 * @param {PageDoc} doc
 * @param {{ theme: 'stark' | 'host', assetPrefix: string, validation?: ValidationResult | null, view?: 'page' | 'panel', diagrams?: RenderOptions['diagrams'] }} o
 */
function renderArticle(doc, o) {
  const header = doc && typeof doc.header === 'object' && doc.header !== null && !Array.isArray(doc.header) ? doc.header : {};
  const type = str(header.type).toLowerCase();
  const status = str(header.status).toLowerCase();
  const title = str(header.title).replace(/\s+/g, ' ') || 'Untitled page';
  const sections = Array.isArray(doc?.sections) ? doc.sections.filter((s) => s && typeof s === 'object') : [];
  const allBlocks = Array.isArray(doc?.blocks) ? doc.blocks : [];
  const { subtitle, rest } = splitPreamble(toText(doc?.preamble), o.assetPrefix);

  const eyebrow = [type || 'page', status].filter(Boolean).map((s) => s.toUpperCase()).join(' · ');
  const draftChip = status === 'draft' ? '<span class="sp-pill">Draft</span>' : '';

  const usedIds = new Set();
  /** @type {Map<string, number>} next suffix to try per heading slug, so repeats stay linear */
  const nextN = new Map();
  const sectionHtml = orderSections(sections, type).map(({ section, callout, wide }) => {
    const base = slugify(str(section.heading));
    let n = nextN.get(base) ?? 1;
    let id = n === 1 ? base : `${base}-${n}`;
    while (usedIds.has(id)) id = `${base}-${++n}`;
    nextN.set(base, n + 1);
    usedIds.add(id);
    return renderSection(section, id, { assetPrefix: o.assetPrefix, callout, wide, blocks: allBlocks, diagrams: o.diagrams });
  });

  const preambleHtml = rest.trim()
    ? `<div class="sp-prose sp-preamble">${renderMarkdownWith(rest, { assetBase: o.assetPrefix, minHeading: 3, diagrams: o.diagrams, pageBlocks: allBlocks }, allBlocks)}</div>`
    : '';

  const layoutClass = Object.hasOwn(LAYOUTS, type) ? `sp-layout-${type}` : 'sp-layout-generic';
  const id = str(header.id);
  const schema = str(header.schema);

  // A hint for the app panel's Publish button: pages that publish prepare would refuse
  // (mock pages, pending blocks, template text) say so. The publish guard is the real gate.
  const warnings = Array.isArray(o.validation?.warnings) ? o.validation.warnings : [];
  const unpublishable = type === 'mock' || allBlocks.some((b) => b && b.lang === 'pending')
    || warnings.some((w) => w && (w.code === 'pending' || w.code === 'placeholder'));

  return [
    `<article class="sp-page sp-theme-${o.theme} ${layoutClass}${o.view === 'panel' ? ' sp-view-panel' : ''}"${unpublishable ? ' data-publishable="false"' : ''}>`,
    renderNotice(o.validation),
    '<div class="sp-grid">',
    '<header class="sp-head">',
    `<div class="sp-eyebrow"><span class="sp-eyebrow__text"><span class="sp-mark" aria-hidden="true"></span>${escapeHtml(eyebrow)}</span>${draftChip}</div>`,
    `<h1 class="sp-title">${escapeHtml(title)}</h1>`,
    subtitle ? `<p class="sp-subtitle">${subtitle}</p>` : '',
    renderBanners(header),
    '</header>',
    renderFacts(doc, header),
    `<div class="sp-body">${preambleHtml}${sectionHtml.join('')}</div>`,
    '</div>',
    `<footer class="sp-foot">${id ? `<span class="sp-id">${escapeHtml(id)}</span>` : ''}<span>Stark page${schema ? ` · schema ${escapeHtml(schema)}` : ''}</span></footer>`,
    '</article>',
  ]
    .filter(Boolean)
    .join('\n');
}

/**
 * Build the Content Security Policy for a rendered document.
 * @param {string | null} assetOrigin
 */
export function buildCsp(assetOrigin) {
  const img = ["'self'", 'data:', ...(assetOrigin ? [assetOrigin] : [])].join(' ');
  return `default-src 'none'; img-src ${img}; style-src 'unsafe-inline'; font-src https://assets.starkfuture.com; base-uri 'none'; form-action 'none'`;
}

/** The CSP of a published page (CONTRACTS.md 12.1): everything from the page's own origin. */
export const PUBLISHED_CSP = "default-src 'none'; img-src 'self'; style-src 'self'; font-src 'self'; base-uri 'none'; form-action 'none'";

/**
 * Check the stylesheet link options for css: 'external'.
 * @param {RenderOptions} opts
 * @returns {{ href: string, integrity: string }}
 */
function externalCss(opts) {
  const href = toText(opts.cssHref);
  const integrity = toText(opts.cssIntegrity);
  // A relative path only: the published CSP allows styles from the page's own origin.
  if (!href || /^[a-z][a-z0-9+.-]*:/i.test(href) || href.startsWith('//') || /["'<>\s\\]/.test(href)) {
    throw new Error('css "external" needs cssHref: a relative path to the stylesheet, like "../_stark/r/0.1.0/page.css".');
  }
  if (!/^sha(256|384|512)-[A-Za-z0-9+/]+={0,2}$/.test(integrity)) {
    throw new Error('css "external" needs cssIntegrity: the stylesheet hash, like "sha384-...".');
  }
  return { href, integrity };
}

/**
 * Turn markdown-it's table alignment attributes into classes (pageCss styles them),
 * so a published page has no style attributes.
 * @param {string} html
 */
function alignToClass(html) {
  return html.replace(/ style="text-align:(left|center|right)"/g, ' class="sp-align-$1"');
}

/**
 * Render a page.
 * @param {PageDoc} doc
 * @param {RenderOptions} [opts]
 * @returns {string}
 */
export function renderPage(doc, opts = {}) {
  const mode = opts.mode ?? 'document';
  if (mode !== 'document' && mode !== 'fragment') {
    throw new Error(`Unknown mode "${toText(mode)}". Use "document" or "fragment".`);
  }
  const theme = opts.theme ?? 'stark';
  if (theme !== 'stark' && theme !== 'host') {
    throw new Error(`Unknown theme "${toText(theme)}". Use "stark" or "host".`);
  }
  const { prefix, origin } = normalizeAssetBase(opts.assetBase);
  const article = renderArticle(doc, { theme, assetPrefix: prefix, validation: opts.validation, view: opts.view === 'panel' ? 'panel' : 'page', diagrams: opts.diagrams instanceof Map ? opts.diagrams : null });
  if (mode === 'fragment') return article;

  const css = opts.css ?? 'inline';
  if (css !== 'inline' && css !== 'external') {
    throw new Error(`Unknown css "${toText(css)}". Use "inline" or "external".`);
  }
  const link = css === 'external' ? externalCss(opts) : null;
  const header = doc && typeof doc.header === 'object' && doc.header !== null ? doc.header : {};
  const title = str(header.title).replace(/\s+/g, ' ') || 'Untitled page';
  return [
    '<!doctype html>',
    `<html lang="en" class="sp-root sp-theme-${theme}">`,
    '<head>',
    '<meta charset="utf-8">',
    `<meta http-equiv="Content-Security-Policy" content="${escapeHtml(link ? PUBLISHED_CSP : buildCsp(origin))}">`,
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    '<meta name="referrer" content="no-referrer">',
    `<meta name="color-scheme" content="${theme === 'stark' ? 'dark light' : 'light dark'}">`,
    `<meta name="generator" content="@stark/pages-renderer ${RENDERER_VERSION}">`,
    `<title>${escapeHtml(title)}</title>`,
    link
      ? `<link rel="stylesheet" href="${escapeHtml(link.href)}" integrity="${escapeHtml(link.integrity)}" crossorigin="anonymous">`
      : `<style>${opts.fontBase ? pageCss({ fontBase: opts.fontBase }) : STARK_CSS}</style>`,
    '</head>',
    '<body>',
    link ? alignToClass(article) : article,
    '</body>',
    '</html>',
    '',
  ].join('\n');
}
