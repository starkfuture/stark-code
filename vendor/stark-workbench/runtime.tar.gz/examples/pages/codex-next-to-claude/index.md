---
schema: 1
type: decision
title: How to get Codex next to Claude
owner: magomet
status: current
verified: 2026-10-14
reviewBy: null
sources:
  - agent_workspace/prototypes/stark-app/build-plan/OWNER-ANSWERS.md
  - agent_workspace/prototypes/stark-app/build-plan/research/t3code/T3CODE-DEEP-DIVE.md
  - agent_workspace/prototypes/stark-app/build-plan/BUILD-PLAN.md
supersedes: null
id: codex-next-to-claude
created: "2026-10-14T12:00:00Z"
author: claude
---

Use stock T3 Code now, and decide on a Stark fork after a 5-day spike.

## Context

"Codex next to Claude" is one of the owner's four must-haves: Codex sessions side by side with Claude in one window. The Claude Mac app cannot do this, so it needs an app outside it (OWNER-ANSWERS.md, item 2).

T3 Code is an open-source desktop app that runs the real `claude` and `codex` programs on your own logins (T3CODE-DEEP-DIVE.md, section 2). A Stark fork of it is the fastest route to a full Stark coding app, but it costs about 27 to 33 days for B1 alone, and its base version, v0.0.46, is not released yet (section 1).

The question: what gives the owner Codex next to Claude now, without locking in the fork too early?

## Options

```options
- name: T3 Code as-is now
  chosen: true
  pros:
    - Claude and Codex threads together from week 1
    - Runs the real claude and codex on your own logins
    - Cheapest path, about 7 to 13 days over 12 months
  cons:
    - Alpha software that changes weekly
    - One window, no split view
    - Starts in Full access with telemetry on
    - No Stark side panel, no Stark look, no server-side publish guard
  cost: B0 setup, about 3.0 to 3.5 days
- name: Wait for our own app
  pros:
    - All must-haves in one Stark app
    - Stark look and a publish guard inside the app
  cons:
    - No Codex next to Claude until the B1 demo
    - B1 demo about late February to mid-March 2027
  cost: B1 about 27 to 33 days, then B2 and B3
- name: Start our own app in week 4
  pros:
    - Keeps T3's terminals, diffs, worktrees, pull requests and pasted images
    - Stark logic reuses Track A through thin wrappers
  cons:
    - The base version v0.0.46 is not released yet
    - Needs Anthropic's written answer before B1
    - Upkeep about 4 to 5 days a month at first
    - BUILD-PLAN schedules Track B from week 10; week 4 means starting right after B0
  cost: B1 about 27 to 33 days
```

## Decision

Use stock T3 Code as-is from week 1, owner only, for Claude and Codex side by side. Stark's own version is built from it later. The owner chose this on 2026-10-14 (OWNER-ANSWERS.md, item 7). Whether to fork is decided at the end of a 5-day hands-on spike, from the hours a real update takes (T3CODE-DEEP-DIVE.md, section 1).

```mermaid
%% caption: The chosen path, and how the fork is decided after the spike
flowchart TD
  A[Use stock T3 Code from week 1] --> B["Do the B0 setup, about 3 to 3.5 days"]
  B --> C[Run a 5-day hands-on spike]
  C --> D{"Update over 1 day, or over 15 upstream files?"}
  D -->|no| E([Build the Stark version as a T3 fork])
  D -->|yes| F([Choose a fresh build or a fresh shell])
```

## Why

- **It is the only option that works in week 1.** T3 can already start a Claude thread and a Codex thread together: Shift-click several models, and each gets its own thread and worktree (section 3.5).
- **It is the cheap floor.** Stock T3 plus Stark's tool server costs about 7 to 13 days over 12 months, against about 74 to 93 for the fork (section 6, estimates).
- **Waiting leaves the must-have empty for months.** At the plan's pace, the B1 demo lands about late February to mid-March 2027, and a team pilot about April 2027 at the earliest (section 8.6, inferred).
- **The fork should not be committed yet.** Over 12 months the fork and a fresh build cost about the same, so the case for the fork is speed and T3's existing features, not cost (section 1). The spike produces the numbers to decide.
- **What would change this:** if the spike's replay plus build plus smoke test takes over 1 day, or days 1 to 4 touch more than 15 upstream files, choose a fresh build or a fresh shell instead of the fork (section 6).

## Consequences

- **B0 setup, about 3.0 to 3.5 days** (sections 8.1 and 8.2):
  - Set the default mode to Supervised, and check each project's own setting.
  - Lock bypass and Auto off with `permissions.disableBypassPermissionsMode` and `permissions.disableAutoMode` in `~/.claude/settings.json`, and with Codex `requirements.toml`.
  - Put the publish guard hook in `~/.claude/settings.json`, because plugin loading inside T3 is unproven.
  - Turn off auto-update with `launchctl setenv T3CODE_DISABLE_AUTO_UPDATE 1` before launch (inferred).
- **Ground rules stay** (section 8.2): owner only, own logins, trusted repos only, no Connect or pairing, never T3's ChatGPT sign-in.
- **Open choice for the owner:** v0.0.45 has no in-chat pages, no V2 engine and no MCP Apps. The deep dive recommends a pinned V2 nightly at least 7 days old instead, which reverses the plan's "no nightly builds" rule (section 8.2).
- **Known bugs to live with:** Stop re-sends the whole prompt (#10955), Auto runs commands that should ask (#15353), and memory grows when idle (#5410). So: avoid Stop, never use Auto, restart the app daily (section 7, risk 23).
- **Team use waits.** Stock T3 for the team depends on Anthropic's answer about seat logins (section 6).
