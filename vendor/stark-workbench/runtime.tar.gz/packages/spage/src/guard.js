// @ts-check
/**
 * The publish guard (CONTRACTS.md 12.2).
 *   spage hook pre-tool-use         PreToolUse, matcher "mcp__.*|Write|Edit|MultiEdit|NotebookEdit|Bash|Monitor"
 *   spage hook post-tool-use-pages  PostToolUse, matcher "mcp__.*"
 *
 * How a publish goes: `spage publish prepare` builds a bundle and points
 * pages/.spage/publish/current.json at it. Every pages_upload_begin is checked against
 * that bundle (hashes, a rebuild from the page, the secret scan):
 *   - a shared Stark file under _stark/ (the content-addressed stylesheet and fonts, no
 *     page content) is allowed silently when it is the verified bundle's own file;
 *   - a page file (<slug>/img/* and <slug>/index.html) always asks the user. No stored
 *     record ever turns such a begin into allow: on one user account nothing on disk can
 *     be made unforgeable, so consent never rests on a file Claude's commands might write.
 * When the begin ran, post-tool-use-pages re-derives the file from current.json, checks
 * its hash against what PreToolUse checked (the begin record, keyed by tool_use_id) and
 * PUTs it to the presigned URL itself. The URL never reaches Claude and never touches
 * disk. pages_upload_commit is allowed only for a file Stark uploaded.
 *
 * Permission modes: a hook "ask" reaches a person in the default, acceptEdits and plan
 * modes. In other modes (auto, dontAsk, bypassPermissions, or a -p run) it may be
 * decided without one, so every Pages write that would ask is denied there instead.
 * A saved "always allow" rule for the tool may also skip an ask (Claude Code does not say),
 * so while one is in a settings file the ask is denied too (saved-rules.js).
 *
 * Output format, checked against the Claude Code hooks reference on 2026-10-14
 * (https://code.claude.com/docs/en/hooks, sections "PreToolUse decision control",
 * "PostToolUse decision control" and "Block the action when a hook fails"): exit 0 and
 * print one JSON object
 *   { "hookSpecificOutput": { "hookEventName": "PreToolUse",
 *       "permissionDecision": "allow" | "deny" | "ask", "permissionDecisionReason": "..." } }
 * The reason is shown to the user for "ask" and to Claude for "deny". A hook "ask"
 * forces the prompt even in auto mode; with several hooks, deny > defer > ask > allow.
 * The PostToolUse hook answers with `updatedToolOutput` (and `updatedMCPToolOutput` for
 * older versions), which replaces what Claude sees of an MCP result, plus
 * `additionalContext`, a note for Claude.
 *
 * The guard loads only Node built-ins and small local modules on the common path: it runs
 * before every Bash, Write, Edit and MCP call, so it must be fast and must never crash.
 * Only the first ask for a bundle loads the checker and renderer (to rebuild the bundle),
 * and only an upload loads the uploader.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { printableRuns, scanSecrets } from './secrets.js';
import { fileURLToPath } from 'node:url';
import { safeTerminalText } from './text.js';
import { savedAllowFor, savedRuleReason } from './saved-rules.js';
import {
  bundleDir, bundleHashOf, bundleSizeProblem, contentAddressOk, formatBytes, isSharedPath, isTextFile, pageFileFor, readBundleFile,
  readCurrent, readManifest, sha256, verifyBundle,
} from './publish/bundle.js';

/** A commit is allowed for a file Stark uploaded this recently. */
export const UPLOAD_ID_TTL_MS = 60 * 60 * 1000;
/** A begin the guard checked must reach PostToolUse within this time. */
const BEGIN_TTL_MS = 30 * 60 * 1000;
/** Upload records older than this are dropped from the file. */
const PRUNE_MS = 24 * 60 * 60 * 1000;
/** The guard answers within this time (the hook timeout is 5 s). */
export const HOOK_DEADLINE_MS = 3500;
/** Payloads above this are not parsed; the first PREFIX_BYTES are kept to find the tool name. */
export const MAX_PAYLOAD_BYTES = 8 * 1024 * 1024;
const PREFIX_BYTES = 64 * 1024;
/** What Claude sees in place of the presigned upload URL. */
export const URL_PLACEHOLDER = '[kept by the Stark guard]';
/** What Claude sees in place of a begin result the hook could not read. */
const BLANK_RESULT = [{ type: 'text', text: `pages_upload_begin result hidden: ${URL_PLACEHOLDER}` }];
/** The upload hook answers within this time (its timeout in hooks.json is 120 s). */
export const POST_DEADLINE_MS = 100_000;

/** Pages tools that only read. They pass silently. (pages_query_data is not here: its schema is unknown.) */
export const PAGES_READ_TOOLS = new Set([
  'pages_list_projects', 'pages_search', 'pages_read_content', 'pages_read_file', 'pages_get_data_sdk_reference',
  'pages_get_public_url', 'pages_download_files_zip', 'pages_export_data',
]);
/** claude.ai connector sign-in tools: they publish nothing. */
const AUTH_TOOLS = new Set(['authenticate', 'complete_authentication']);

/**
 * @typedef {{
 *   io: { stdout: { write: (s: string) => unknown }, stderr: { write: (s: string) => unknown }, stdin?: NodeJS.ReadableStream & { isTTY?: boolean } },
 *   env: Record<string, string | undefined>,
 *   cwd: string,
 *   now?: () => Date,
 *   homedir?: string,
 *   deadlineMs?: number,
 *   postDeadlineMs?: number,
 *   fetch?: typeof globalThis.fetch,
 *   rebuild?: (fm: import('./publish/bundle.js').FoundManifest, o: { home: string, now: Date }) => Promise<RebuildResult>,
 *   managedSettings?: string,
 *   pluginRoot?: string,
 * }} GuardContext
 * @typedef {{ ok: true, facts: { title: string, type: string, status: string, images: number } } | { ok: false, why: string }} RebuildResult
 * @typedef {'allow' | 'ask' | 'deny'} Decision
 * @typedef {{ decision: Decision, reason: string } | null} Verdict
 * @typedef {{ path: string, sha256: string, size: number, contentType: string }} BundleFileRef
 * @typedef {{ root: string, project: string, bundleHash: string, files: BundleFileRef[] }} BundleRef
 * @typedef {{
 *   at: string, root: string, project: string, bundleHash: string, slug: string, path: string,
 *   sha256: string, size: number, contentType: string, shared: boolean,
 * }} BeginRecord
 * @typedef {{
 *   upload_id: string, project: string, root: string, slug: string, path: string, sha256: string, size: number,
 *   bundleHash: string, status: 'uploaded' | 'failed', reason?: string, at: string, committedAt?: string, public_url?: string,
 * }} UploadRecord
 * @typedef {{ v: 2, begins: Record<string, BeginRecord>, uploads: Record<string, UploadRecord> }} ApprovalStore
 */

class DeadlineError extends Error {}

/** @param {number | undefined} deadline */
function checkDeadline(deadline) {
  if (deadline !== undefined && performance.now() > deadline) throw new DeadlineError('deadline');
}

/** On darwin and win32 file names ignore case. @param {string} p */
function foldCase(p) {
  return process.platform === 'darwin' || process.platform === 'win32' ? p.toLowerCase() : p;
}

// ---------------------------------------------------------------------------
// Input

/**
 * Read stdin (a hook payload) with a size cap and a time limit. A TTY gives ''.
 * It stops as soon as a complete JSON payload has arrived (Claude Code may close stdin
 * late). Over the cap, only the first 64 KB are kept and `truncated` is set, so the
 * caller can still find the tool name (a padded payload must not make the guard go silent).
 * Kept here, not imported from hook.js, so the guard does not load the mirror.
 * @param {(NodeJS.ReadableStream & { isTTY?: boolean, destroy?: () => void }) | undefined} stdin
 * @param {{ maxBytes?: number, timeoutMs?: number }} [opts]
 * @returns {Promise<{ text: string, truncated: boolean }>}
 */
export function readHookPayload(stdin, opts = {}) {
  const maxBytes = opts.maxBytes ?? MAX_PAYLOAD_BYTES;
  const timeoutMs = opts.timeoutMs ?? 1500;
  if (!stdin || stdin.isTTY) return Promise.resolve({ text: '', truncated: false });
  return new Promise((resolve) => {
    /** @type {Buffer[]} */
    const chunks = [];
    let size = 0;
    let done = false;
    let truncated = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (probe) clearTimeout(probe);
      stdin.removeListener('data', onData);
      stdin.removeListener('end', finish);
      stdin.removeListener('error', finish);
      try { stdin.pause?.(); stdin.destroy?.(); } catch { /* closed */ }
      const all = Buffer.concat(chunks);
      resolve(truncated ? { text: all.subarray(0, PREFIX_BYTES).toString('utf8'), truncated } : { text: all.toString('utf8'), truncated });
    };
    /** @param {Buffer | string} c */
    const onData = (c) => {
      const b = Buffer.isBuffer(c) ? c : Buffer.from(c);
      size += b.length;
      if (size > maxBytes) {
        truncated = true;
        const have = chunks.reduce((n, x) => n + x.length, 0);
        if (have < PREFIX_BYTES) chunks.push(b.subarray(0, PREFIX_BYTES - have));
        finish();
        return;
      }
      chunks.push(b);
      // A complete JSON payload is enough: do not wait for an end that may come late.
      // The parse waits for a 5 ms pause in the data, so a large payload is parsed once,
      // not once per chunk that happens to end in "}".
      if (probe) { clearTimeout(probe); probe = undefined; }
      if (/[}\]]\s*$/.test(b.toString('utf8', Math.max(0, b.length - 16)))) {
        probe = setTimeout(tryParse, 5);
        probe.unref?.();
      }
    };
    /** @type {NodeJS.Timeout | undefined} */
    let probe;
    const tryParse = () => {
      probe = undefined;
      if (done) return;
      try {
        JSON.parse(Buffer.concat(chunks).toString('utf8'));
        finish();
      } catch {
        // not complete yet
      }
    };
    const timer = setTimeout(finish, timeoutMs);
    if (typeof timer === 'object' && 'unref' in timer) timer.unref();
    stdin.on('data', onData);
    stdin.once('end', finish);
    stdin.once('error', finish);
    stdin.resume?.();
  });
}

/**
 * The payload as text, or '' when it is over the cap (kept for callers of slice 1's API).
 * @param {(NodeJS.ReadableStream & { isTTY?: boolean, destroy?: () => void }) | undefined} stdin
 * @param {{ maxBytes?: number, timeoutMs?: number }} [opts]
 * @returns {Promise<string>}
 */
export async function readHookInput(stdin, opts = {}) {
  const r = await readHookPayload(stdin, opts);
  return r.truncated ? '' : r.text;
}

/** @param {string} raw */
function parsePayload(raw) {
  if (!raw || !raw.trim()) return null;
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
  } catch {
    return null;
  }
}

/**
 * Split an MCP tool name. A Pages tool is one whose own name starts with `pages_`, on any
 * MCP server (the claude.ai connector, a server added by hand, a renamed server).
 * @param {unknown} toolName
 * @returns {{ server: string, tool: string, pages: boolean } | null}
 */
export function parseMcpTool(toolName) {
  if (typeof toolName !== 'string' || !toolName.startsWith('mcp__')) return null;
  const m = /^mcp__(.+?)__(.+)$/.exec(toolName);
  if (!m) return null;
  // A server name may hold "__" too: prefer the split that yields a pages_ tool.
  const at = toolName.toLowerCase().lastIndexOf('__pages_');
  if (at > 4) {
    return { server: toolName.slice(5, at), tool: toolName.slice(at + 2).toLowerCase().replace(/-/g, '_'), pages: true };
  }
  const raw = m[2].toLowerCase().replace(/-/g, '_');
  return { server: m[1], tool: raw, pages: raw.startsWith('pages_') };
}

/**
 * A Pages tool called through a generic proxy tool (`{ name: 'pages_upload_begin', ... }`).
 * @param {any} ti
 * @returns {string | null}
 */
export function proxiedPagesTool(ti) {
  if (!ti || typeof ti !== 'object') return null;
  for (const k of ['name', 'tool', 'tool_name', 'toolName', 'method']) {
    const v = ti[k];
    if (typeof v !== 'string') continue;
    const m = /(?:^|__|[./:])(pages_[A-Za-z0-9_-]{1,80})$/.exec(v.trim());
    if (m) return m[1].toLowerCase().replace(/-/g, '_');
  }
  return null;
}

// ---------------------------------------------------------------------------
// The guard's store (~/.stark/guard/approvals.json, outside the agent's sandbox)

/** @param {string} home */
export function guardDir(home) {
  return path.join(home, '.stark', 'guard');
}

/** @param {string} home */
export function approvalsFile(home) {
  return path.join(guardDir(home), 'approvals.json');
}

/** @param {unknown} v */
function isRecord(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

/**
 * The store, or an empty one. A file from an older guard (v 1) is ignored. Approvals that
 * an older v 2 guard kept are dropped: no stored record decides a begin any more.
 * @param {string} home
 * @returns {ApprovalStore}
 */
export function readApprovals(home) {
  try {
    const v = JSON.parse(fs.readFileSync(approvalsFile(home), 'utf8'));
    if (isRecord(v) && v.v === 2 && isRecord(v.begins) && isRecord(v.uploads)) return { v: 2, begins: v.begins, uploads: v.uploads };
  } catch {
    // none yet
  }
  return { v: 2, begins: {}, uploads: {} };
}

/**
 * Write the store (mode 0600, folder 0700), dropping old entries.
 * @param {string} home @param {ApprovalStore} store @param {Date} now
 */
export function writeApprovals(home, store, now) {
  const dir = guardDir(home);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const t = now.getTime();
  const young = (/** @type {string} */ at, /** @type {number} */ ms) => t - Date.parse(at) < ms;
  /** @type {ApprovalStore} */
  const kept = { v: 2, begins: {}, uploads: {} };
  for (const [k, b] of Object.entries(store.begins)) if (isRecord(b) && young(b.at, BEGIN_TTL_MS)) kept.begins[k] = b;
  for (const [k, u] of Object.entries(store.uploads)) if (isRecord(u) && young(u.at, PRUNE_MS)) kept.uploads[k] = u;
  const tmp = path.join(dir, `.approvals.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`);
  fs.writeFileSync(tmp, JSON.stringify(kept, null, 2) + '\n', { mode: 0o600 });
  fs.renameSync(tmp, approvalsFile(home));
  try { fs.chmodSync(approvalsFile(home), 0o600); } catch { /* best effort */ }
}

/** @param {number} ms */
function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

/**
 * Read, change and write the store under a lock file, so begins that run in parallel do
 * not lose each other's records. A lock older than 10 s is stale. If the lock cannot be
 * had in time, the change is made anyway (a lost record only makes an upload fail). When
 * the folder cannot be written at all, the write throws and the caller's "cannot check
 * means no" path answers.
 * @template T
 * @param {string} home @param {Date} now @param {(store: ApprovalStore) => T} change
 * @param {{ waitMs?: number }} [o]
 * @returns {T}
 */
export function updateApprovals(home, now, change, o = {}) {
  const dir = guardDir(home);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const lock = path.join(dir, 'approvals.lock');
  const until = Date.now() + (o.waitMs ?? 2000);
  let held = false;
  // Every pass checks the time first, so the loop always ends (a read-only folder, a full
  // disk or a stale lock that is a folder must not make the hook spin).
  for (let pass = 0; Date.now() <= until && pass < 1000; pass++) {
    try {
      fs.closeSync(fs.openSync(lock, 'wx', 0o600));
      held = true;
      break;
    } catch (e) {
      // Only "someone else holds it" is worth waiting for.
      if (/** @type {NodeJS.ErrnoException} */ (e).code !== 'EEXIST') break;
      try {
        if (Date.now() - fs.statSync(lock).mtimeMs > 10_000) fs.rmSync(lock, { force: true, recursive: true });
      } catch {
        // gone already, or cannot be removed: wait and try again
      }
      sleepSync(15);
    }
  }
  try {
    const store = readApprovals(home);
    const out = change(store);
    writeApprovals(home, store, now);
    return out;
  } finally {
    if (held) fs.rmSync(lock, { force: true });
  }
}

/** A folder compared by real path (and in any case on darwin and win32). @param {string} root */
export function rootKey(root) {
  let r = path.resolve(root);
  try { r = fs.realpathSync.native(r); } catch { /* gone: keep the plain path */ }
  return foldCase(r);
}

/**
 * The files of a bundle that Stark uploaded and Pages committed: path to the newest
 * committed upload record whose bytes are the bundle's bytes (record uses it).
 * @param {ApprovalStore} store @param {BundleRef} a
 * @returns {Map<string, UploadRecord>}
 */
export function committedUploads(store, a) {
  /** @type {Map<string, UploadRecord>} */
  const out = new Map();
  const want = new Map(a.files.map((f) => [f.path, f.sha256]));
  const root = rootKey(a.root);
  for (const u of Object.values(store.uploads)) {
    if (!isRecord(u) || u.status !== 'uploaded' || !u.committedAt) continue;
    if (u.bundleHash !== a.bundleHash || u.project !== a.project || typeof u.root !== 'string' || rootKey(u.root) !== root) continue;
    if (want.get(u.path) !== u.sha256) continue;
    const prev = out.get(u.path);
    if (!prev || Date.parse(String(prev.committedAt)) <= Date.parse(u.committedAt)) out.set(u.path, u);
  }
  return out;
}

/**
 * The key that ties a PreToolUse payload to the PostToolUse payload of the same call.
 * @param {any} payload
 */
function beginKey(payload) {
  const id = payload?.tool_use_id;
  if (typeof id === 'string' && /^[A-Za-z0-9_-]{1,200}$/.test(id)) return `id:${id}`;
  return `in:${sha256(JSON.stringify([payload?.session_id ?? '', payload?.tool_name ?? '', payload?.tool_input ?? null]))}`;
}

// ---------------------------------------------------------------------------
// Finding the bundle an upload belongs to

/**
 * Folders whose pages/.spage/publish/current.json may name the bundle, in a fixed order.
 * @param {GuardContext} ctx @param {any} payload @param {string} home
 */
function candidateRoots(ctx, payload, home) {
  const list = [ctx.env.CLAUDE_PROJECT_DIR, typeof payload?.cwd === 'string' ? payload.cwd : undefined, ctx.cwd, path.join(home, 'Stark')];
  return [...new Set(list.filter((x) => typeof x === 'string' && x).map((x) => path.resolve(/** @type {string} */ (x))))];
}

/**
 * The bundle prepared last (current.json) that lists this upload and is unchanged, or
 * why there is none. Only the bundle current.json names is considered, never the first
 * manifest a folder listing happens to return.
 * @param {string[]} roots
 * @param {Record<string, unknown>} ti pages_upload_begin arguments
 * @param {Date} now
 * @param {number} [deadline] a performance.now() time after which it gives up
 * @returns {{ found: import('./publish/bundle.js').FoundManifest, totalSize: number } | { found: null, why: string }}
 */
export function matchCurrent(roots, ti, now, deadline) {
  const { root, path: p, size, content_type: ct } = ti;
  if (typeof root !== 'string' || typeof p !== 'string' || typeof ct !== 'string' || typeof size !== 'number') {
    return { found: null, why: 'the upload arguments are incomplete' };
  }
  let why = 'no page was prepared here';
  for (const r of roots) {
    checkDeadline(deadline);
    const cur = readCurrent(r);
    if (!cur) continue;
    if (cur.project !== root) { why = `the page prepared last is for project ${JSON.stringify(cur.project)}`; continue; }
    const m = readManifest(r, cur.slug);
    if (!m || m.bundleHash !== cur.bundleHash || m.project !== cur.project || m.createdAt !== cur.createdAt) {
      why = 'the prepared bundle changed after prepare';
      continue;
    }
    const f = m.files.find((x) => x.path === p);
    if (!f) { why = `${short(p)} is not in the bundle of ${cur.slug}, the page prepared last`; continue; }
    if (f.size !== size || f.contentType !== ct) { why = 'the size or content type differs from the prepared bundle'; continue; }
    const big = bundleSizeProblem(m);
    if (big) { why = big; continue; }
    const fm = { root: r, slug: cur.slug, dir: bundleDir(r, cur.slug), file: path.join(bundleDir(r, cur.slug), 'manifest.json'), manifest: m };
    const v = verifyBundle(r, m, { now, manifestFile: fm.file });
    if (!v.ok) { why = v.reason; continue; }
    return { found: fm, totalSize: v.totalSize };
  }
  return { found: null, why };
}

/**
 * Scan the page and every bundle file again, at decision time (text files as text, fonts
 * and images by their readable runs).
 * @param {import('./publish/bundle.js').FoundManifest} fm
 */
function rescan(fm) {
  const hits = [];
  try {
    hits.push(...scanSecrets(fs.readFileSync(pageFileFor(fm.root, fm.slug), 'utf8'), { file: 'index.md' }));
    for (const f of fm.manifest.files) {
      const data = readBundleFile(fm.root, fm.manifest, f);
      // Fonts and images: the readable runs of text in them (a key appended to a font file).
      hits.push(...(isTextFile(f)
        ? scanSecrets(data.toString('utf8'), { file: f.path, html: f.contentType === 'text/html' })
        : scanSecrets(printableRuns(data), { file: f.path })));
    }
  } catch {
    return [{ rule: 'unreadable', line: 0, preview: '', file: 'bundle' }];
  }
  return hits;
}

/**
 * Build the bundle again from index.md and img/, in memory, and compare its hash with the
 * manifest's. A hand-made bundle (scripts, content that differs from the page, a mock page,
 * an unstripped image) never matches. The checker and renderer load only here.
 * @param {import('./publish/bundle.js').FoundManifest} fm
 * @param {{ home: string, now: Date }} o
 * @returns {Promise<RebuildResult>}
 */
export async function rebuildBundle(fm, o) {
  const [{ buildBundle }, { loadFormat, loadRenderer }] = await Promise.all([
    import('./publish/prepare.js'),
    import('./deps.js'),
  ]);
  const r = await buildBundle({
    pageArg: path.join(fm.root, 'pages', fm.slug),
    cwd: fm.root,
    project: fm.manifest.project,
    homedir: o.home,
    now: () => o.now,
    getFormat: loadFormat,
    getRenderer: loadRenderer,
  });
  if (!r.ok) return { ok: false, why: `prepare would refuse this page now: ${r.reasons[0] ?? 'unknown reason'}` };
  if (r.manifest.bundleHash !== fm.manifest.bundleHash) {
    return { ok: false, why: 'the bundle is not what spage publish prepare makes from the page' };
  }
  const m = r.manifest;
  return { ok: true, facts: { title: m.title, type: m.type, status: m.status, images: r.images } };
}

// ---------------------------------------------------------------------------
// Bash, Monitor and file tools: two rules only

const GLOB_CHARS = /[*?[\]]/;

/** Commands that only list names or sizes: a glob over hidden home folders is fine for them. */
const LISTING_HEADS = new Set(['ls', 'du', 'stat', 'cd', 'pushd', 'tree', 'eza', 'exa']);
/** Commands whose words are search patterns, not paths. */
const SEARCH_HEADS = new Set(['grep', 'egrep', 'fgrep', 'rg', 'ag', 'ack', 'git-grep']);
/** Words that run the next word as the command. */
const WRAPPERS = new Set(['sudo', 'command', 'builtin', 'env', 'time', 'nice', 'nohup', 'exec', 'xargs', 'export']);

/**
 * The command a segment runs (its first word after assignments and wrappers), by base name.
 * `git grep` gives "git-grep".
 * @param {string[]} words
 */
function segmentHead(words) {
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(w) || w.startsWith('-')) continue;
    const b = (w.split('/').pop() ?? '').toLowerCase();
    if (WRAPPERS.has(b)) continue;
    if (b === 'git') {
      const sub = words.slice(i + 1).find((x) => !x.startsWith('-'));
      return sub === 'grep' ? 'git-grep' : 'git';
    }
    return b;
  }
  return '';
}

/**
 * A token rooted at the home folder: `~`, `$HOME`, `${HOME}` or the absolute home path,
 * alone or followed by `/`. Returns the rest after the home folder, or null.
 * @param {string} tok @param {string} home
 */
function homeRest(tok, home) {
  const m = /^(?:~|\$HOME|\$\{HOME\})(?=\/|$)/.exec(tok);
  if (m) return tok.slice(m[0].length);
  const h = home.replace(/\/+$/, '');
  if (h && (foldCase(tok) === foldCase(h) || foldCase(tok).startsWith(`${foldCase(h)}/`))) return tok.slice(h.length);
  return null;
}

/**
 * A shell glob as a regular expression for one path segment. `*` and `?` as in the shell,
 * `[...]` as a character class. An invalid class matches anything (the safe side).
 * @param {string} seg @param {boolean} ci
 */
function globRegex(seg, ci) {
  let re = '';
  for (let i = 0; i < seg.length; i++) {
    const c = seg[i];
    if (c === '*') re += '.*';
    else if (c === '?') re += '.';
    else if (c === '[') {
      let j = i + 1;
      if (seg[j] === '!' || seg[j] === '^') j++;
      if (seg[j] === ']') j++;
      const end = seg.indexOf(']', j);
      if (end < 0) { re += '\\['; continue; }
      let body = seg.slice(i + 1, end);
      const neg = body[0] === '!' || body[0] === '^';
      if (neg) body = body.slice(1);
      re += `[${neg ? '^' : ''}${body.replace(/[\\\]^[]/g, '\\$&')}]`;
      i = end;
    } else re += c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
  try {
    return new RegExp(`^${re}$`, ci ? 'i' : '');
  } catch {
    return /^/;
  }
}

/** Can a path segment (maybe a glob) be `name`? @param {string} seg @param {string} name @param {boolean} ci */
function segMatches(seg, name, ci) {
  // As in the shell, a glob reaches a hidden name only when it starts with a dot itself.
  if (GLOB_CHARS.test(seg)) return (!name.startsWith('.') || seg.startsWith('.')) && globRegex(seg, ci).test(name);
  return ci ? seg.toLowerCase() === name : seg === name;
}

/**
 * `{a,b}` alternatives of a word (not nested braces), at most 32.
 * @param {string} w @returns {string[]}
 */
function expandBraces(w) {
  const out = /** @type {string[]} */ ([]);
  const walk = (/** @type {string} */ x, /** @type {number} */ depth) => {
    const m = depth < 6 ? /\{([^{}]*,[^{}]*)\}/.exec(x) : null;
    if (!m) { out.push(x); return; }
    for (const alt of m[1].split(',')) {
      if (out.length >= 32) return;
      walk(x.slice(0, m.index) + alt + x.slice(m.index + m[0].length), depth + 1);
    }
  };
  walk(w, 0);
  return out;
}

/**
 * Does an absolute path (maybe holding globs) reach the guard folder or the embed origins
 * file? Only paths directly under the home folder are looked at.
 * @param {string} abs @param {string} home @param {string} head @param {boolean} ci
 */
function reachesGuard(abs, home, head, ci) {
  const H = foldCase(home);
  if (!foldCase(abs).startsWith(`${H}/`)) return false;
  const segs = abs.slice(home.length + 1).split('/').filter((x) => x && x !== '.');
  if (segs.length === 0 || !segMatches(segs[0], '.stark', ci)) return false;
  if (segs.length === 1) {
    // ~/.st*, ~/.s[t]ark: a glob over hidden home folders. Listing names or sizes is fine.
    return GLOB_CHARS.test(segs[0]) && !LISTING_HEADS.has(head);
  }
  return segMatches(segs[1], 'guard', ci) || segMatches(segs[1], 'embed-origins', ci);
}

/** `.stark/guard` named as a path anywhere in a word, e.g. `homedir()+'/.stark/guard/x'`. */
const GUARD_SEGMENT = /(?:^|[/=:+,])\.stark\/+(?:guard|embed-origins)(?=$|[/,;&|<>)}\]])/i;

/**
 * Does a command refer to the guard folder or the embed origins file? Quotes are removed,
 * the command is split into words, and each word (and the part after `=` in `--opt=x`) is
 * taken as a path: from the home folder when it starts with ~, $HOME, ${HOME} or the home
 * path, else from the folder the command runs in (following `cd`). Variables set earlier in
 * the command are filled in; other variables and `{a,b}` count as globs. A path that is or
 * may be (through a glob) `~/.stark/guard` or `~/.stark/embed-origins`, or under them, is
 * refused; so is a glob over hidden home folders that may be `~/.stark` (except for `ls`,
 * `du`, `stat` and `cd`). A word holding `.stark/guard` as a path is refused too, except in
 * a grep or rg pattern. Bare words such as "stark" or "guard" never match, and globs only
 * matter in paths directly under the home folder.
 * @param {string} cmd @param {{ cwd: string, home: string }} o
 */
export function refersToGuardDir(cmd, o) {
  const home = path.resolve(o.home);
  const ci = process.platform === 'darwin' || process.platform === 'win32';
  const flat = cmd.replace(/["'\\]/g, '');
  let dir = path.resolve(o.cwd);
  /** @type {Map<string, string>} */
  const vars = new Map();
  const fill = (/** @type {string} */ w) => w
    .replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)/g, (all, a, b) => {
      const name = a ?? b;
      if (name === 'HOME') return all;
      return vars.has(name) ? /** @type {string} */ (vars.get(name)) : '*';
    })
    .replace(/(?!^)\$\{?HOME\}?/g, '*')
    .replace(/\$(?![{A-Za-z_])/g, '*');
  for (const segment of flat.split(/[;&|\n\r()`]+/)) {
    const words = segment.split(/[\s<>]+/).filter(Boolean);
    const head = segmentHead(words);
    let cd = false;
    for (const raw of words) {
      const asg = /^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/.exec(raw);
      if (asg) vars.set(asg[1], fill(asg[2]));
      const word = fill(raw);
      if (cd && !word.startsWith('-')) {
        const rest = homeRest(word, home);
        dir = rest !== null ? path.join(home, rest) : path.resolve(dir, word);
        cd = false;
      }
      if (word === 'cd' || word === 'pushd') cd = true;
      const eq = raw.indexOf('=');
      for (const tok of eq > 0 ? [word, fill(raw.slice(eq + 1))] : [word]) {
        if (!tok) continue;
        const rest = homeRest(tok, home);
        if (rest === null && !SEARCH_HEADS.has(head) && GUARD_SEGMENT.test(tok)) return true;
        for (const alt of expandBraces(tok)) {
          const r = homeRest(alt, home);
          const abs = r !== null ? path.join(home, r) : path.resolve(dir, alt);
          if (reachesGuard(abs, home, head, ci)) return true;
        }
      }
    }
    if (cd) dir = home;
  }
  return false;
}

/** Commands whose quoted words are text, never run as a command. */
const NO_EXEC_HEADS = new Set([...SEARCH_HEADS, 'echo', 'printf', 'git', 'gh', 'jq', 'yq']);

/**
 * Split a command into segments of words the way a shell would: quotes and backslashes
 * respected, segments split at `;`, `&`, `|`, newlines, parentheses and backticks. A word
 * that holds spaces, `$(` or a backtick (`bash -c "..."`, `"$(curl ...)"`) is split again,
 * so a command inside it is seen too, except in the text of grep, echo, git and the like.
 * @param {string} cmd @param {number} [depth]
 * @returns {string[][]}
 */
export function shellSegments(cmd, depth = 0) {
  /** @type {string[][]} */
  const segs = [];
  /** @type {string[]} */
  let words = [];
  /** @type {string[]} */
  const inner = [];
  let cur = '';
  let has = false;
  /** @type {string | null} */
  let q = null;
  /** @type {string[]} */
  let mine = [];
  const endWord = () => {
    if (has) {
      words.push(cur);
      // `$(...)` and backticks run whatever the command is; plain text with spaces runs
      // only as the argument of a shell (bash -c, eval, ssh).
      if (/\$\(|`/.test(cur)) inner.push(cur.replace(/\$\(/g, ' ; '));
      else if (/\s/.test(cur)) mine.push(cur);
    }
    cur = '';
    has = false;
  };
  const endSeg = () => {
    endWord();
    // Text given to grep, echo or git (a pattern, a commit message) is not run.
    if (!NO_EXEC_HEADS.has(segmentHead(words))) inner.push(...mine);
    if (words.length) segs.push(words);
    words = [];
    mine = [];
  };
  for (let i = 0; i < cmd.length; i++) {
    const c = cmd[i];
    if (q === "'") { if (c === "'") q = null; else cur += c; continue; }
    if (q === '"') {
      if (c === '"') q = null;
      else if (c === '\\' && i + 1 < cmd.length && '"\\$`\n'.includes(cmd[i + 1])) cur += cmd[++i];
      else cur += c;
      continue;
    }
    if (c === "'" || c === '"') { q = c; has = true; continue; }
    if (c === '\\' && i + 1 < cmd.length) { cur += cmd[++i]; has = true; continue; }
    if (c === '\n' || c === '\r') { endSeg(); continue; }
    if (/\s/.test(c)) { endWord(); continue; }
    if (';&|()`'.includes(c)) { endSeg(); continue; }
    if (c === '<' || c === '>') { endWord(); continue; }
    cur += c;
    has = true;
  }
  endSeg();
  if (depth < 3) for (const w of inner) segs.push(...shellSegments(w, depth + 1));
  return segs;
}

/** Hosts that receive published data, named literally. */
const PAGES_HOST = /^(?:vibecoded-apps\.s3(?:[.-][a-z0-9.-]*)?|pages\.starkfuture\.com|pages-ext\.starkfuture\.com)$/i;

/** The host a curl or wget URL argument names, or ''. @param {string} w */
function urlHost(w) {
  const m = /^(?:[a-z][a-z0-9+.-]*:\/\/)?(?:[^/?#@]*@)?(\[[^\]]*\]|[^/?#:]*)/i.exec(w);
  return (m?.[1] ?? '').replace(/\.$/, '');
}

const CURL_SHORT_VALUE = new Set([...'dFHouAebcXTxmwKrECUzYyPDtQ']);
const CURL_LONG_VALUE = new Set([
  'data', 'data-ascii', 'data-binary', 'data-raw', 'data-urlencode', 'form', 'form-string', 'header', 'output', 'user',
  'user-agent', 'referer', 'cookie', 'cookie-jar', 'request', 'upload-file', 'proxy', 'max-time', 'connect-timeout',
  'write-out', 'config', 'range', 'cert', 'key', 'cacert', 'capath', 'resolve', 'json', 'dump-header', 'retry',
  'retry-delay', 'retry-max-time', 'interface', 'limit-rate', 'output-dir', 'proxy-user', 'connect-to', 'max-filesize',
  'oauth2-bearer', 'aws-sigv4', 'unix-socket', 'variable', 'trace', 'trace-ascii', 'stderr', 'preproxy', 'proto',
  'proto-redir', 'ciphers', 'local-port', 'keepalive-time', 'max-redirs', 'netrc-file', 'pinnedpubkey', 'quote',
  'request-target', 'user-agent', 'cert-type', 'key-type', 'pass', 'expect100-timeout', 'happy-eyeballs-timeout-ms',
]);
const WGET_SHORT_VALUE = new Set([...'OoaPUeitTwQlDBARIX']);
const WGET_LONG_VALUE = new Set([
  'header', 'output-document', 'output-file', 'append-output', 'post-data', 'post-file', 'body-data', 'body-file', 'method',
  'user', 'password', 'http-user', 'http-password', 'user-agent', 'referer', 'load-cookies', 'save-cookies',
  'directory-prefix', 'input-file', 'tries', 'timeout', 'wait', 'quota', 'level', 'domains', 'accept', 'reject',
  'include-directories', 'exclude-directories', 'execute', 'base', 'config', 'ca-certificate', 'certificate', 'private-key',
]);

/**
 * One curl or wget call: does it upload, and to which hosts?
 * @param {'curl' | 'wget'} tool @param {string[]} args
 */
function transferCall(tool, args) {
  const shortValue = tool === 'curl' ? CURL_SHORT_VALUE : WGET_SHORT_VALUE;
  const longValue = tool === 'curl' ? CURL_LONG_VALUE : WGET_LONG_VALUE;
  /** @type {string[]} */
  const urls = [];
  let uploads = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--') { urls.push(...args.slice(i + 1)); break; }
    if (a.startsWith('--')) {
      const eq = a.indexOf('=');
      const name = (eq > 0 ? a.slice(2, eq) : a.slice(2)).toLowerCase();
      let value = eq > 0 ? a.slice(eq + 1) : null;
      if (value === null && (longValue.has(name) || name === 'url')) value = args[++i] ?? '';
      if (name === 'url' && value) urls.push(value);
      if (tool === 'curl') {
        if (/^(?:upload-file|data[a-z-]*|form[a-z-]*|json)$/.test(name)) uploads = true;
        if (name === 'request' && /^(?:PUT|POST|PATCH)$/i.test(value ?? '')) uploads = true;
      } else {
        if (name === 'method' && /^(?:PUT|POST)$/i.test(value ?? '')) uploads = true;
        if (/^(?:post-data|post-file|body-[a-z-]+)$/.test(name)) uploads = true;
      }
      continue;
    }
    if (a.startsWith('-') && a.length > 1) {
      // A cluster of short options; the first one that takes a value takes the rest, or the next word.
      for (let k = 1; k < a.length; k++) {
        const f = a[k];
        if (!shortValue.has(f)) continue;
        const value = k + 1 < a.length ? a.slice(k + 1) : (args[++i] ?? '');
        if (tool === 'curl') {
          if (f === 'T' || f === 'd' || f === 'F') uploads = true;
          if (f === 'X' && /^(?:PUT|POST|PATCH)$/i.test(value)) uploads = true;
        }
        break;
      }
      continue;
    }
    urls.push(a);
  }
  return { uploads, hosts: urls.map(urlHost) };
}

/**
 * Does a command upload to a literally named Pages or upload host with curl or wget? The
 * host must be the URL of the same curl or wget call that uploads: a page link inside the
 * data of a post to another host, or a read of Pages next to a post elsewhere, passes.
 * @param {string} cmd
 */
export function uploadsToPages(cmd) {
  if (!/vibecoded-apps\.s3|pages(?:-ext)?\.starkfuture\.com/i.test(cmd)) return false;
  for (const words of shellSegments(cmd)) {
    for (let at = 0; at < words.length; at++) {
      const w = words[at];
      if (!/(?:^|\/)(?:curl|wget2?)$/.test(w)) continue;
      const tool = w.endsWith('curl') ? 'curl' : 'wget';
      const call = transferCall(tool, words.slice(at + 1));
      if (call.uploads && call.hosts.some((h) => PAGES_HOST.test(h))) return true;
    }
  }
  return false;
}

/** Functions of the guard that write its records. */
const GUARD_WRITERS = /\b(?:hookPreToolUse|hookPostToolUsePages|uploadAfterBegin|updateApprovals|writeApprovals|recordCommit|pagesVerdict|preToolUseVerdict)\b/;

/**
 * Does a command run the guard's own hooks (or the functions behind them)? Run by hand,
 * with a made-up tool_use_id and result, they could write records the guard reads (a
 * begin it never checked, an upload it never made). Reading or searching the guard's code
 * is fine.
 * @param {string} cmd
 */
export function runsGuardHook(cmd) {
  for (const words of shellSegments(cmd)) {
    const head = segmentHead(words);
    if (SEARCH_HEADS.has(head) || head === 'sed' || head === 'cat' || head === 'less' || head === 'head' || head === 'tail') continue;
    const i = words.findIndex((w) => /(?:^|\/)spage(?:\.js)?$/.test(w));
    if (i >= 0) {
      const j = words.indexOf('hook', i + 1);
      if (j > 0 && /^(?:pre-tool-use|post-tool-use-pages)$/.test(words[j + 1] ?? '')) return true;
    }
  }
  // The guard's functions called from a script given inline (node -e, a heredoc on stdin).
  if (!GUARD_WRITERS.test(cmd)) return false;
  for (const words of shellSegments(cmd)) {
    if (!/^(?:node|nodejs|bun|deno|tsx)$/.test(segmentHead(words))) continue;
    const args = words.slice(words.findIndex((w) => /(?:^|\/)(?:node|nodejs|bun|deno|tsx)$/.test(w)) + 1);
    if (args.some((w) => /^(?:-e|-p|--eval|--print|--input-type(?:=.*)?|-|eval)$/.test(w))) return true;
    if (!args.some((w) => !w.startsWith('-')) && !args.some((w) => /^(?:--test|--version|-v|--help|-h)$/.test(w))) return true;
  }
  return false;
}

/**
 * @param {string} command
 * @param {{ cwd: string, home?: string }} o
 * @returns {Verdict}
 */
export function bashVerdict(command, o) {
  const home = o.home ?? os.homedir();
  if (refersToGuardDir(command, { cwd: o.cwd, home })) {
    return { decision: 'deny', reason: 'Stark publish guard: commands may not touch ~/.stark/guard (the publish records) or ~/.stark/embed-origins.' };
  }
  if (runsGuardHook(command)) {
    return { decision: 'deny', reason: 'Stark publish guard: only Claude Code runs the guard\'s hooks. Running them by hand could record an upload the user never approved.' };
  }
  if (uploadsToPages(command)) {
    return {
      decision: 'deny',
      reason: 'Stark publish guard: this command uploads to Stark Pages or its upload host. Publish only with spage publish prepare and the Pages upload tools; Stark uploads each file itself.',
    };
  }
  return null;
}

/**
 * Paths a Write, Edit, MultiEdit or NotebookEdit call names.
 * @param {any} ti
 */
function toolPaths(ti) {
  /** @type {string[]} */
  const out = [];
  if (!ti || typeof ti !== 'object') return out;
  for (const k of ['file_path', 'path', 'notebook_path']) if (typeof ti[k] === 'string') out.push(ti[k]);
  if (Array.isArray(ti.edits)) for (const e of ti.edits) if (e && typeof e.file_path === 'string') out.push(e.file_path);
  return out;
}

/** @param {string} p */
function realish(p) {
  // The real path of the longest existing parent, plus the rest.
  let cur = p;
  const rest = [];
  for (let i = 0; i < 64; i++) {
    try {
      return path.join(fs.realpathSync.native(cur), ...rest.reverse());
    } catch {
      const parent = path.dirname(cur);
      if (parent === cur) break;
      rest.push(path.basename(cur));
      cur = parent;
    }
  }
  return p;
}

/** @param {string} child @param {string} parent */
function inside(child, parent) {
  const r = path.relative(foldCase(parent), foldCase(child));
  return r === '' || (!r.startsWith('..') && !path.isAbsolute(r));
}

/**
 * @param {any} ti @param {{ cwd: string, home: string, projectDir: string }} o
 * @returns {Verdict}
 */
export function fileToolVerdict(ti, o) {
  const guard = guardDir(o.home);
  const origins = path.join(o.home, '.stark', 'embed-origins');
  const fonts = path.join(o.home, '.stark', 'fonts');
  for (const raw of toolPaths(ti)) {
    let p = raw.replace(/^~(?=\/|$)/, o.home).replace(/^\$\{?HOME\}?(?=\/|$)/, o.home);
    p = p.replace(/^\$\{?CLAUDE_PROJECT_DIR\}?(?=\/|$)/, o.projectDir);
    const abs = path.resolve(o.cwd, p);
    const real = realish(abs);
    if (inside(abs, guard) || inside(real, realish(guard))) {
      return { decision: 'deny', reason: 'Stark publish guard: ~/.stark/guard holds the publish records. Only the guard writes there.' };
    }
    if (inside(abs, origins) || inside(real, realish(origins))) {
      return { decision: 'deny', reason: 'Stark publish guard: ~/.stark/embed-origins decides which apps may frame the mirror. Ask the user to edit it.' };
    }
    if (inside(abs, fonts) || inside(real, realish(fonts))) {
      return { decision: 'deny', reason: 'Stark publish guard: ~/.stark/fonts is published without a prompt as the shared Stark fonts. Only "spage fonts fetch", run by the user, fills it.' };
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Pages tools

/** @param {unknown} v */
function short(v) {
  const s = typeof v === 'string' ? v : JSON.stringify(v) ?? String(v);
  const t = safeTerminalText(s).replace(/\s+/g, ' ');
  return t.length > 80 ? `${t.slice(0, 77)}...` : t;
}

/** A value quoted so it cannot close its quotes and add text of its own. @param {unknown} v */
function quoted(v) {
  return JSON.stringify(short(v));
}

/** @param {number} n @param {string} one @param {string} [many] */
function plural(n, one, many = `${one}s`) {
  return `${n} ${n === 1 ? one : many}`;
}

/** Permission modes in which a hook "ask" reaches a person. */
const PERSON_MODES = new Set(['default', 'acceptEdits', 'plan']);
/** Why a Pages write that would ask is denied in other modes. */
export const NEEDS_PERSON = 'Publishing needs a person to say yes. Switch to the default permission mode (Shift+Tab) and ask again.';

/**
 * Can a hook "ask" reach a person in this call's permission mode? A missing mode counts
 * as default. auto, dontAsk and bypassPermissions (and any mode not known here) do not:
 * there the prompt may be skipped or decided without a person.
 * @param {unknown} mode
 */
export function personCanAnswer(mode) {
  if (mode === undefined || mode === null) return true;
  return typeof mode === 'string' && PERSON_MODES.has(mode);
}

/**
 * The images of this bundle that Stark already uploaded after the user said yes.
 * @param {ApprovalStore} store @param {import('./publish/bundle.js').FoundManifest} fm
 */
function imagesUploaded(store, fm) {
  const m = fm.manifest;
  const want = new Map(m.files.filter((f) => f.path.startsWith(`${fm.slug}/img/`)).map((f) => [f.path, f.sha256]));
  const root = rootKey(fm.root);
  const done = new Set();
  for (const u of Object.values(store.uploads)) {
    if (!isRecord(u) || u.status !== 'uploaded' || u.bundleHash !== m.bundleHash || u.project !== m.project) continue;
    if (want.get(u.path) !== u.sha256 || typeof u.root !== 'string' || rootKey(u.root) !== root) continue;
    done.add(u.path);
  }
  return done.size;
}

/**
 * The question for one page file, built from the verified bundle.
 * @param {import('./publish/bundle.js').FoundManifest} fm
 * @param {{ title: string, type: string, status: string }} facts
 * @param {import('./publish/bundle.js').ManifestFile} file
 * @param {ApprovalStore} store
 */
function pageFileQuestion(fm, facts, file, store) {
  const m = fm.manifest;
  const head = `${quoted(facts.title)} (${short(facts.type)}, ${short(facts.status)}) to Stark Pages project ${quoted(m.project)}`;
  const tail = 'Who can see it follows the project\'s sharing. No secrets found.';
  const images = m.files.filter((f) => f.path.startsWith(`${fm.slug}/img/`));
  if (file.path === `${fm.slug}/index.html`) {
    const done = imagesUploaded(store, fm);
    const imgs = images.length === 0
      ? 'The page has no images.'
      : `${done} of ${plural(images.length, 'image')} already approved for this page${done < images.length ? ' (the others will not show)' : ''}.`;
    return `Publish ${head} at ${short(file.path)} (${formatBytes(file.size)}). This puts the page live. ${imgs} ${tail}`;
  }
  const n = images.findIndex((f) => f.path === file.path) + 1;
  return `Upload image ${short(file.path)} (${formatBytes(file.size)}), ${n} of ${images.length}, for ${head}. The page itself comes last. ${tail}`;
}

/** @param {any} ti */
function mainArgs(ti) {
  if (!ti || typeof ti !== 'object') return 'no arguments';
  const keys = Object.keys(ti).slice(0, 5);
  if (keys.length === 0) return 'no arguments';
  return keys.map((k) => `${short(k)}=${short(ti[k])}`).join(', ');
}

/**
 * A Pages write that would ask is denied when no person can answer the prompt
 * (permission modes other than default, acceptEdits and plan).
 * @param {Verdict} v @param {unknown} mode
 * @returns {Verdict}
 */
function needsPerson(v, mode) {
  return v && v.decision === 'ask' && !personCanAnswer(mode) ? { decision: 'deny', reason: NEEDS_PERSON } : v;
}

/** The plugin's own folder: the guard and the renderer it rebuilds pages with. */
const PLUGIN_ROOT = fileURLToPath(new URL('../../../', import.meta.url));

/**
 * The folders this Claude Code session runs in (its sandbox may write them, and its
 * project settings live there).
 * @param {GuardContext} ctx @param {any} payload
 * @returns {Array<string | undefined>}
 */
function sessionDirs(ctx, payload) {
  return [ctx.env.CLAUDE_PROJECT_DIR, typeof payload?.cwd === 'string' ? payload.cwd : undefined];
}

/**
 * A Pages ask must reach a person. It is denied when the mode has no person (needsPerson),
 * and when a saved "always allow" rule for the tool may skip the question: Claude Code
 * does not document whether such a rule silences a hook ask (16.6).
 * @param {Verdict} v @param {any} payload @param {GuardContext} ctx @param {string} home @param {unknown} toolName
 * @returns {Verdict}
 */
function personGate(v, payload, ctx, home, toolName) {
  const w = needsPerson(v, payload?.permission_mode);
  if (!w || w.decision !== 'ask' || typeof toolName !== 'string') return w;
  const hit = savedAllowFor(toolName, { home, projectDirs: sessionDirs(ctx, payload), managedSettings: ctx.managedSettings });
  return hit ? { decision: 'deny', reason: savedRuleReason(hit, short) } : w;
}

/**
 * Is the plugin's folder inside a folder this session runs in? Then Claude's sandbox may
 * have changed the renderer that made the shared style file, so that file asks too (16.6).
 * @param {GuardContext} ctx @param {any} payload
 */
function pluginInSession(ctx, payload) {
  const plugin = realish(path.resolve(ctx.pluginRoot ?? PLUGIN_ROOT));
  return sessionDirs(ctx, payload).some((d) => typeof d === 'string' && d !== '' && inside(plugin, realish(path.resolve(d))));
}

/**
 * The verdict when the guard cannot check a call (no time left, an unreadable payload,
 * an internal error): deny uploads, ask for other Pages writes (deny when no person can
 * answer), silence for the rest.
 * @param {unknown} toolName @param {string} why @param {unknown} [mode] the payload's permission_mode
 * @returns {Verdict}
 */
function fallbackVerdict(toolName, why, mode) {
  const t = parseMcpTool(toolName);
  if (!t || !t.pages || PAGES_READ_TOOLS.has(t.tool) || AUTH_TOOLS.has(t.tool)) return null;
  if (t.tool === 'pages_upload_begin' || t.tool === 'pages_upload_files') {
    return { decision: 'deny', reason: `Stark publish guard could not check this upload (${why}). Run spage publish prepare again, then retry.` };
  }
  return needsPerson({ decision: 'ask', reason: `Stark publish guard could not check ${short(toolName)} (${why}). Approve only if you asked for this.` }, mode);
}

/**
 * The fallback verdict, with saved "always allow" rules honoured (personGate).
 * @param {GuardContext} ctx @param {unknown} toolName @param {string} why @param {unknown} mode @param {any} [payload]
 * @returns {Verdict}
 */
function gatedFallback(ctx, toolName, why, mode, payload) {
  const p = payload && typeof payload === 'object' ? payload : { permission_mode: mode };
  return personGate(fallbackVerdict(toolName, why, mode), p, ctx, ctx.homedir ?? os.homedir(), toolName);
}

/** @param {UploadRecord} u */
function failedReason(u) {
  return `Stark could not upload ${short(u.path)}: ${short(u.reason ?? 'unknown reason')}. Call pages_upload_begin again for this file.`;
}

/**
 * @param {{ tool: string, server: string }} t
 * @param {any} payload
 * @param {GuardContext} ctx
 * @param {{ home: string, now: Date, deadline?: number }} o
 * @returns {Promise<Verdict>}
 */
export async function pagesVerdict(t, payload, ctx, o) {
  const ti = isRecord(payload.tool_input) ? payload.tool_input : {};
  if (PAGES_READ_TOOLS.has(t.tool) || AUTH_TOOLS.has(t.tool)) return null;

  if (t.tool === 'pages_upload_begin') {
    const shared = isSharedPath(/** @type {string} */ (ti.path));
    // A page file always needs a person; say so before any work. Shared files too: without
    // a person no page can follow them, and a font in ~/.stark/fonts is any bytes that start
    // like a font, so uploading it alone would publish data no one was asked about.
    if (!personCanAnswer(payload.permission_mode)) return { decision: 'deny', reason: NEEDS_PERSON };
    const match = matchCurrent(candidateRoots(ctx, payload, o.home), ti, o.now, o.deadline);
    if (!match.found) {
      return {
        decision: 'deny',
        reason: `Run spage publish prepare first. Stark only publishes the page prepared last, unchanged since the check. (${match.why}.)`,
      };
    }
    const fm = match.found;
    const m = fm.manifest;
    const file = /** @type {import('./publish/bundle.js').ManifestFile} */ (m.files.find((x) => x.path === ti.path));
    if (shared && !contentAddressOk(file.path, file.sha256)) {
      return { decision: 'deny', reason: `Run spage publish prepare first. ${short(file.path)} does not carry its own content hash, so Stark cannot tell it is the shared Stark file.` };
    }
    const hits = rescan(fm);
    if (hits.length) {
      return { decision: 'deny', reason: `Stark publish guard: the secret scan found ${hits.length} possible secret${hits.length === 1 ? '' : 's'} in the bundle (${hits.slice(0, 3).map((h) => `${h.file}:${h.line} ${h.rule}`).join(', ')}). Remove them and prepare again.` };
    }
    checkDeadline(o.deadline);
    const rebuilt = await (ctx.rebuild ?? rebuildBundle)(fm, { home: o.home, now: o.now });
    checkDeadline(o.deadline);
    if (!rebuilt.ok) {
      return { decision: 'deny', reason: `Run spage publish prepare first. Stark only publishes prepared pages, unchanged since the check. (${short(rebuilt.why)}.)` };
    }
    // What PreToolUse checked, so PostToolUse uploads exactly these bytes (and re-derives
    // them from current.json before it does). This record never allows a later begin.
    /** @type {BeginRecord} */
    const begin = {
      at: o.now.toISOString(), root: fm.root, project: m.project, bundleHash: m.bundleHash, slug: fm.slug,
      path: file.path, sha256: file.sha256, size: file.size, contentType: file.contentType, shared,
    };
    const key = beginKey(payload);
    const store = updateApprovals(o.home, o.now, (s) => { s.begins[key] = begin; return s; }, { waitMs: 1000 });
    if (shared && pluginInSession(ctx, payload)) {
      return {
        decision: 'ask',
        reason: `Upload the shared Stark style file ${short(file.path)} (${formatBytes(file.size)}) for ${quoted(rebuilt.facts.title)} to Stark Pages project ${quoted(m.project)}. The Stark plugin runs from inside this session's folder (${short(ctx.pluginRoot ?? PLUGIN_ROOT)}), so Claude could have changed the code that made this file, and Stark cannot vouch for it. Approve only if you trust that folder. No secrets found.`,
      };
    }
    if (shared) {
      return {
        decision: 'allow',
        reason: `Stark publish guard: ${short(file.path)} is a shared Stark style file of the page prepared last, unchanged and content-addressed. It holds no page content.`,
      };
    }
    return { decision: 'ask', reason: pageFileQuestion(fm, rebuilt.facts, file, store) };
  }

  if (t.tool === 'pages_upload_commit') {
    const id = typeof ti.upload_id === 'string' ? ti.upload_id : null;
    if (id) {
      const store = readApprovals(o.home);
      const u = Object.hasOwn(store.uploads, id) ? store.uploads[id] : null;
      if (u && u.status === 'failed') return { decision: 'deny', reason: failedReason(u) };
      if (u && u.status === 'uploaded' && o.now.getTime() - Date.parse(u.at) < UPLOAD_ID_TTL_MS && typeof u.bundleHash === 'string' && u.bundleHash) {
        return { decision: 'allow', reason: `Stark publish guard: Stark uploaded ${short(u.path)} from the checked bundle.` };
      }
    }
    return { decision: 'ask', reason: 'Stark did not upload this file; it cannot tell what this commit makes public.' };
  }

  if (t.tool === 'pages_upload_files') {
    return { decision: 'deny', reason: 'Use the prepared upload path (spage publish prepare).' };
  }

  return {
    decision: 'ask',
    reason: `Stark Pages write: ${short(t.tool)} on ${short(t.server)} (${mainArgs(ti)}). This changes who can see Stark pages.`,
  };
}

// ---------------------------------------------------------------------------
// Hook entry points

/**
 * @param {GuardContext} ctx @param {Verdict} v
 */
function answer(ctx, v) {
  if (!v) return;
  const out = { hookEventName: 'PreToolUse', permissionDecision: v.decision, permissionDecisionReason: v.reason };
  ctx.io.stdout.write(JSON.stringify({ hookSpecificOutput: out }) + '\n');
}

/**
 * The decision for one PreToolUse payload (exported for tests).
 * @param {any} payload @param {GuardContext & { deadline?: number }} ctx
 * @returns {Promise<Verdict>}
 */
export async function preToolUseVerdict(payload, ctx) {
  const home = ctx.homedir ?? os.homedir();
  const now = (ctx.now ?? (() => new Date()))();
  const cwd = typeof payload?.cwd === 'string' && payload.cwd ? payload.cwd : ctx.cwd;
  const projectDir = path.resolve(ctx.env.CLAUDE_PROJECT_DIR || cwd);
  const name = payload?.tool_name;
  const ti = payload?.tool_input;
  if (name === 'Bash' || name === 'Monitor') {
    if (typeof ti?.command !== 'string') return null;
    return bashVerdict(ti.command, { cwd, home });
  }
  if (name === 'Write' || name === 'Edit' || name === 'MultiEdit' || name === 'NotebookEdit') {
    return fileToolVerdict(ti, { cwd, home, projectDir });
  }
  const t = parseMcpTool(name);
  if (!t) return null;
  if (t.pages) return personGate(await pagesVerdict(t, payload, ctx, { home, now, deadline: ctx.deadline }), payload, ctx, home, name);
  // A Pages tool reached through a generic proxy tool.
  const inner = looksLikeProxy(t, ti) ? proxiedPagesTool(ti) : null;
  if (inner && !PAGES_READ_TOOLS.has(inner)) {
    if (inner === 'pages_upload_begin' || inner === 'pages_upload_files' || inner === 'pages_upload_commit') {
      return { decision: 'deny', reason: `Stark publish guard: call ${short(inner)} directly, not through ${short(name)}, so the guard can check it.` };
    }
    return personGate({ decision: 'ask', reason: `Stark Pages write through ${short(name)}: ${short(inner)}. This changes who can see Stark pages.` }, payload, ctx, home, name);
  }
  // A browser or web tool aimed at Pages runs with the user's signed-in session, which the
  // guard cannot check: the user decides.
  if (isWebTool(t) && namesPagesHost(ti)) {
    // Looking at a page is fine in any mode; a tool that can click, type, run script or
    // send data needs a person, and there is none in auto, dontAsk or bypass modes.
    if (!personCanAnswer(payload.permission_mode) && !WEB_LOOK.test(t.tool)) {
      return {
        decision: 'deny',
        reason: `${short(name)} could send something to Stark Pages (or its upload host) with your signed-in session, and no person can say yes in this permission mode. Switch to the default permission mode (Shift+Tab) and ask again.`,
      };
    }
    return {
      decision: 'ask',
      reason: `${short(name)} would open or send something to Stark Pages (or its upload host) in your browser or a web tool. Stark cannot check what that publishes. Approve only if you want Claude to look at a page.`,
    };
  }
  return null;
}

/** Tool names and input fields of generic tools that call other tools. */
const PROXY_NAME = /(?:^|_)(?:call|invoke|execute|exec|run|proxy|batch|dispatch|use)(?:_|$)|tool/i;
const PROXY_ARGS = ['arguments', 'params', 'args', 'input', 'parameters', 'tool_input'];

/**
 * A generic proxy tool: its name says it calls tools, or its input carries the inner
 * call's arguments. A Gmail label or a Monday board named "pages_x" is not one.
 * @param {{ server: string, tool: string }} t @param {any} ti
 */
function looksLikeProxy(t, ti) {
  if (PROXY_NAME.test(t.tool)) return true;
  return !!ti && typeof ti === 'object' && PROXY_ARGS.some((k) => isRecord(ti[k]) || Array.isArray(ti[k]));
}

/** Browsers and web tools (they can act with the user's signed-in session). */
const WEB_SERVER = /chrome|browser|playwright|puppeteer|selenium|webdriver|fetch|http|curl|web/i;
const WEB_TOOL = /navigate|evaluate|javascript|run_code|script|fetch|request|http|upload|form|batch|computer|open|goto/i;
/** Web tools that only open or read a page; they cannot click, type, run script or send data. */
const WEB_LOOK = /(?:^|_)(?:navigate|goto|open|get_page_text|read_page|snapshot|screenshot)(?:_|$)/i;

/** @param {{ server: string, tool: string }} t */
function isWebTool(t) {
  return WEB_SERVER.test(t.server) || WEB_TOOL.test(t.tool);
}

/** Does a tool input literally name a Pages or upload host? @param {unknown} ti */
function namesPagesHost(ti) {
  let text = '';
  try { text = JSON.stringify(ti) ?? ''; } catch { return false; }
  return /vibecoded-apps\.s3|pages(?:-ext)?\.starkfuture\.com/i.test(text.slice(0, 1024 * 1024));
}

/**
 * `spage hook pre-tool-use`. Always exits 0. A payload it cannot read or check in time
 * gets the fallback verdict: deny uploads, ask for other Pages writes, deny Bash, Write,
 * Edit and Monitor calls too large to check, silence for everything else.
 * @param {GuardContext} ctx
 * @returns {Promise<number>}
 */
export async function hookPreToolUse(ctx) {
  /** @type {any} */
  let payload = null;
  let toolName = null;
  /** @type {unknown} */
  let mode;
  try {
    const { text, truncated } = await readHookPayload(ctx.io.stdin);
    payload = truncated ? null : parsePayload(text);
    if (!payload) {
      toolName = /"tool_name"\s*:\s*"([^"\\]{1,300})"/.exec(text)?.[1] ?? null;
      if (!toolName) return 0;
      if (truncated && /^(?:Bash|Monitor|Write|Edit|MultiEdit|NotebookEdit)$/.test(toolName)) {
        answer(ctx, { decision: 'deny', reason: 'Stark publish guard: this call is too large to check. Split it into smaller steps.' });
        return 0;
      }
      mode = /"permission_mode"\s*:\s*"([^"\\]{1,64})"/.exec(text)?.[1];
      answer(ctx, gatedFallback(ctx, toolName, truncated ? 'the call is too large to check' : 'the call could not be read', mode));
      return 0;
    }
    toolName = payload.tool_name;
    mode = payload.permission_mode;
    const ms = ctx.deadlineMs ?? HOOK_DEADLINE_MS;
    const deadline = performance.now() + ms;
    const TIMEOUT = Symbol('timeout');
    /** @type {NodeJS.Timeout | undefined} */
    let timer;
    const late = new Promise((resolve) => { timer = setTimeout(() => resolve(TIMEOUT), ms); timer.unref?.(); });
    const v = await Promise.race([preToolUseVerdict(payload, { ...ctx, deadline }), late]);
    clearTimeout(timer);
    answer(ctx, v === TIMEOUT ? gatedFallback(ctx, toolName, 'it ran out of time', mode, payload) : /** @type {Verdict} */ (v));
  } catch (e) {
    try {
      answer(ctx, gatedFallback(ctx, toolName, e instanceof DeadlineError ? 'it ran out of time' : 'an internal error', mode, payload));
    } catch {
      // never crash
    }
  }
  return 0;
}

/**
 * Find a string field in a tool response, whatever its shape (object, JSON text,
 * MCP content blocks).
 * @param {unknown} v @param {string} key @param {RegExp} ok @param {number} [depth]
 * @returns {string | null}
 */
function findField(v, key, ok, depth = 0) {
  if (depth > 6 || v === null || v === undefined) return null;
  if (typeof v === 'string') {
    const s = v.trim();
    if (s.startsWith('{') || s.startsWith('[')) {
      try { return findField(JSON.parse(s), key, ok, depth + 1); } catch { /* fall through */ }
    }
    const m = new RegExp(`"${key}"\\s*:\\s*("(?:[^"\\\\]|\\\\.){1,4096}")`).exec(s);
    if (!m) return null;
    try {
      const val = JSON.parse(m[1]);
      return typeof val === 'string' && ok.test(val) ? val : null;
    } catch {
      return null;
    }
  }
  if (Array.isArray(v)) {
    for (const x of v.slice(0, 50)) {
      const r = findField(x, key, ok, depth + 1);
      if (r) return r;
    }
    return null;
  }
  if (typeof v === 'object') {
    const o = /** @type {Record<string, unknown>} */ (v);
    const own = o[key];
    if (typeof own === 'string' && ok.test(own)) return own;
    for (const k of Object.keys(o).slice(0, 50)) {
      const r = findField(o[k], key, ok, depth + 1);
      if (r) return r;
    }
  }
  return null;
}

/**
 * Every object in a tool response that has a `path` and a `public_url` (commit results).
 * @param {unknown} v @param {Array<{ path: unknown, public_url: unknown, status?: unknown }>} [out] @param {number} [depth]
 */
function commitResults(v, out = [], depth = 0) {
  if (depth > 6 || v === null || v === undefined || out.length > 200) return out;
  if (typeof v === 'string') {
    const s = v.trim();
    if (s.startsWith('{') || s.startsWith('[')) {
      try { commitResults(JSON.parse(s), out, depth + 1); } catch { /* not JSON */ }
    }
    return out;
  }
  if (Array.isArray(v)) {
    for (const x of v.slice(0, 200)) commitResults(x, out, depth + 1);
    return out;
  }
  if (typeof v === 'object') {
    const o = /** @type {Record<string, unknown>} */ (v);
    if ('public_url' in o && 'path' in o) out.push({ path: o.path, public_url: o.public_url, status: o.status });
    for (const k of Object.keys(o).slice(0, 50)) commitResults(o[k], out, depth + 1);
  }
  return out;
}

const UPLOAD_ID_RE = /^[A-Za-z0-9._:-]{1,200}$/;
const UPLOAD_URL_RE = /^https:\/\/[^\s'"\\<>]{1,4000}$/;
/** Any S3 URL in a begin result is hidden, also when it is not where we expect it. */
const ANY_S3_URL = /https?:(?:\/|\\\/){2}[^\s"'<>\\]*amazonaws\.com[^\s"'<>\\]*/gi;

/**
 * Find an upload_id in a tool response.
 * @param {unknown} v
 * @returns {string | null}
 */
export function findUploadId(v) {
  return findField(v, 'upload_id', UPLOAD_ID_RE);
}

/**
 * Find an upload_url in a tool response.
 * @param {unknown} v
 * @returns {string | null}
 */
export function findUploadUrl(v) {
  return findField(v, 'upload_url', UPLOAD_URL_RE);
}

/**
 * The tool response with the upload URL replaced everywhere (shape kept), so Claude never
 * sees the bearer URL. Any other S3 URL is replaced too.
 * @param {unknown} v @param {string | null} url @param {number} [depth]
 * @returns {unknown}
 */
export function redactUrl(v, url, depth = 0) {
  if (depth > 12) return v;
  if (typeof v === 'string') {
    let out = v;
    if (url) {
      const forms = [url, JSON.stringify(url).slice(1, -1), url.replace(/\//g, '\\/'), url.replace(/&/g, '\\u0026')];
      for (const f of forms) if (f) out = out.split(f).join(URL_PLACEHOLDER);
      const q = url.split('?').slice(1).join('?');
      if (q.length > 16) out = out.split(q).join(URL_PLACEHOLDER);
    }
    return out.replace(ANY_S3_URL, URL_PLACEHOLDER);
  }
  if (Array.isArray(v)) return v.map((x) => redactUrl(x, url, depth + 1));
  if (v && typeof v === 'object') {
    /** @type {Record<string, unknown>} */
    const out = {};
    for (const [k, x] of Object.entries(v)) out[k] = redactUrl(x, url, depth + 1);
    return out;
  }
  return v;
}

/**
 * Read one file from a bundle folder and check it is byte for byte the file PreToolUse
 * checked (`f`: path, size and sha256 from the begin record).
 * @param {string} root @param {string} slug @param {BundleFileRef} f
 * @returns {{ ok: true, data: Buffer } | { ok: false, reason: string }}
 */
function readCheckedFile(root, slug, f) {
  const dir = bundleDir(root, slug);
  const abs = path.join(dir, 'files', ...f.path.split('/'));
  try {
    const st = fs.lstatSync(abs);
    if (st.isSymbolicLink() || !st.isFile()) return { ok: false, reason: 'the file in the prepared bundle is not a plain file' };
    if (st.size !== f.size) return { ok: false, reason: 'the file changed since the check' };
    const realDir = fs.realpathSync(dir);
    if (!fs.realpathSync(abs).startsWith(realDir + path.sep)) return { ok: false, reason: 'the file is outside the prepared bundle' };
    const data = fs.readFileSync(abs);
    if (data.length !== f.size || sha256(data) !== f.sha256) return { ok: false, reason: 'the file changed since the check' };
    return { ok: true, data };
  } catch {
    return { ok: false, reason: 'the file is missing from the prepared bundle' };
  }
}

/**
 * The bytes to upload for a begin, derived again from current.json: the page prepared
 * last must still be the bundle PreToolUse checked, its manifest must list this file with
 * the same hash, and the file on disk must hash to it. Anything that disagrees refuses.
 * @param {BeginRecord} b
 * @returns {{ ok: true, data: Buffer } | { ok: false, reason: string }}
 */
function rederive(b) {
  const cur = readCurrent(b.root);
  if (!cur || cur.slug !== b.slug || cur.project !== b.project || cur.bundleHash !== b.bundleHash) {
    return { ok: false, reason: 'another page was prepared, or this one prepared again, since you were asked' };
  }
  const m = readManifest(b.root, cur.slug);
  if (!m || m.slug !== cur.slug || m.project !== cur.project || m.bundleHash !== cur.bundleHash || m.createdAt !== cur.createdAt
    || bundleHashOf(m.files) !== m.bundleHash) {
    return { ok: false, reason: 'the prepared bundle changed since you were asked' };
  }
  const f = m.files.find((x) => x.path === b.path);
  if (!f || f.sha256 !== b.sha256 || f.size !== b.size || f.contentType !== b.contentType) {
    return { ok: false, reason: 'the file changed since the check' };
  }
  if (b.shared && !contentAddressOk(f.path, f.sha256)) return { ok: false, reason: 'the shared file does not carry its own content hash' };
  return readCheckedFile(b.root, b.slug, b);
}

/**
 * After pages_upload_begin ran (the user said yes, or the guard allowed a shared Stark
 * file): upload the checked bytes to the presigned URL, record the outcome, and hide the
 * URL (exported for tests).
 * @param {any} payload @param {GuardContext} ctx
 * @returns {Promise<{ output: unknown, note: string, status: 'uploaded' | 'failed' }>}
 */
export async function uploadAfterBegin(payload, ctx) {
  const ti = isRecord(payload.tool_input) ? payload.tool_input : {};
  const resp = payload.tool_response;
  const url = findUploadUrl(resp);
  // Hidden first, so the URL never reaches Claude, whatever happens below.
  const output = redactUrl(resp, url);
  const p = typeof ti.path === 'string' ? ti.path : '(no path)';
  let r;
  try {
    r = await uploadChecked(payload, ctx, ti, url, p);
  } catch (e) {
    r = { reason: `an internal error (${e instanceof Error ? e.message : String(e)})`, id: null, size: 0 };
  }
  const note = r.reason
    ? `Stark could not upload ${short(p)}: ${short(url ? r.reason.split(url).join(URL_PLACEHOLDER) : r.reason)}. Call pages_upload_begin again for this file.`
    : `Stark uploaded ${short(p)} (${formatBytes(r.size)}). Now call pages_upload_commit with upload_id ${r.id}.`;
  return { output, note, status: r.reason ? 'failed' : 'uploaded' };
}

/**
 * The checks, the upload and the records behind uploadAfterBegin.
 * @param {any} payload @param {GuardContext} ctx @param {Record<string, any>} ti @param {string | null} url @param {string} p
 * @returns {Promise<{ reason: string | null, id: string | null, size: number }>}
 */
async function uploadChecked(payload, ctx, ti, url, p) {
  const home = ctx.homedir ?? os.homedir();
  const now = (ctx.now ?? (() => new Date()))();
  const id = findUploadId(payload.tool_response);
  const key = beginKey(payload);

  // 1. What PreToolUse checked for this very call (used once, then dropped).
  const b = /** @type {BeginRecord | null} */ (updateApprovals(home, now, (s) => {
    const rec = Object.hasOwn(s.begins, key) ? s.begins[key] : null;
    delete s.begins[key];
    return rec;
  }));

  /** @type {string | null} */
  let reason = null;
  if (!b || !isRecord(b) || !(now.getTime() - Date.parse(b.at) < BEGIN_TTL_MS) || b.path !== p) {
    reason = 'the guard did not check this begin, so Stark uploads nothing';
  } else if (ti.root !== b.project || ti.size !== b.size || ti.content_type !== b.contentType) {
    reason = 'this file is not the one you were asked about';
  }
  if (!reason && !id) reason = 'pages_upload_begin returned no upload_id';
  if (!reason && !url) reason = 'pages_upload_begin returned no upload URL';
  // 2. The bytes, derived again from current.json and checked against the begin record.
  let data = null;
  if (!reason && b) {
    const r = rederive(b);
    if (r.ok) data = r.data; else reason = r.reason;
  }
  if (!reason && data && b && url) {
    const { putBytes } = await import('./publish/put.js');
    const r = await putBytes({ url, data, contentType: b.contentType, fetch: ctx.fetch ?? globalThis.fetch });
    if (!r.ok) reason = r.reason;
  }

  // 3. The outcome, without the URL.
  const ok = !reason && b ? b : null;
  if (id) {
    /** @type {UploadRecord} */
    const rec = {
      upload_id: id,
      project: ok?.project ?? String(ti.root ?? ''),
      root: ok?.root ?? '',
      slug: ok?.slug ?? '',
      path: p,
      sha256: ok?.sha256 ?? '',
      size: ok?.size ?? 0,
      bundleHash: ok?.bundleHash ?? '',
      status: reason ? 'failed' : 'uploaded',
      ...(reason ? { reason } : {}),
      at: now.toISOString(),
    };
    updateApprovals(home, now, (s) => { s.uploads[id] = rec; });
  }
  return { reason, id, size: ok?.size ?? 0 };
}

/**
 * After pages_upload_commit ran: mark the upload committed and keep its public_url.
 * @param {any} payload @param {GuardContext} ctx
 * @returns {boolean} whether an upload Stark made was marked
 */
export function recordCommit(payload, ctx) {
  const home = ctx.homedir ?? os.homedir();
  const now = (ctx.now ?? (() => new Date()))();
  const ti = isRecord(payload.tool_input) ? payload.tool_input : {};
  const id = typeof ti.upload_id === 'string' ? ti.upload_id : null;
  if (!id || (isRecord(payload.tool_response) && payload.tool_response.isError === true)) return false;
  if (!Object.hasOwn(readApprovals(home).uploads, id)) return false;
  const results = commitResults(payload.tool_response);
  return updateApprovals(home, now, (s) => {
    const u = Object.hasOwn(s.uploads, id) ? s.uploads[id] : null;
    if (!u || u.status !== 'uploaded') return false;
    const mine = results.filter((r) => r.path === u.path);
    const hit = mine[0] ?? (results.length === 1 ? results[0] : null);
    if (hit && typeof hit.status === 'string' && /err|fail|denied|reject/i.test(hit.status)) return false;
    u.committedAt = now.toISOString();
    if (hit && typeof hit.public_url === 'string' && /^https:\/\/[^\s"'<>\\]{1,2000}$/.test(hit.public_url)) u.public_url = hit.public_url;
    return true;
  });
}

/**
 * `spage hook post-tool-use-pages`. After pages_upload_begin it uploads the checked file
 * itself and replaces the URL in what Claude sees; after pages_upload_commit it keeps the
 * public URL. Every other MCP tool returns at once. Always exits 0.
 * @param {GuardContext} ctx
 * @returns {Promise<number>}
 */
export async function hookPostToolUsePages(ctx) {
  let said = false;
  /** @type {(output: unknown, note: string) => void} */
  const say = (output, note) => {
    if (said) return;
    said = true;
    ctx.io.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', updatedToolOutput: output, updatedMCPToolOutput: output, additionalContext: note },
    }) + '\n');
  };
  let begin = false;
  try {
    const { text: raw, truncated } = await readHookPayload(ctx.io.stdin);
    // Most MCP calls are not Pages uploads: skip parsing their (possibly large) results.
    if (!/pages[_-]upload[_-](?:begin|commit)/i.test(raw.slice(0, 4096)) && !/"tool_name"\s*:\s*"[^"]*pages[_-]upload[_-](?:begin|commit)"/i.test(raw)) return 0;
    const named = /"tool_name"\s*:\s*"([^"\\]{1,300})"/.exec(raw)?.[1];
    begin = parseMcpTool(named)?.tool === 'pages_upload_begin';
    const payload = truncated ? null : parsePayload(raw);
    if (!payload) {
      // Too large or unreadable: nothing is uploaded, and the result (which may hold the
      // upload URL) is replaced all the same.
      if (begin) say(BLANK_RESULT, 'Stark could not upload this file: the begin result was too large to check. Call pages_upload_begin again for this file.');
      return 0;
    }
    const t = parseMcpTool(payload.tool_name);
    if (!t || !t.pages) return 0;
    if (t.tool === 'pages_upload_begin') {
      begin = true;
      const ms = ctx.postDeadlineMs ?? POST_DEADLINE_MS;
      /** @type {NodeJS.Timeout | undefined} */
      let timer;
      const late = new Promise((resolve) => { timer = setTimeout(() => resolve(null), ms); timer.unref?.(); });
      const r = /** @type {Awaited<ReturnType<typeof uploadAfterBegin>> | null} */ (await Promise.race([uploadAfterBegin(payload, ctx), late]));
      clearTimeout(timer);
      if (r) say(r.output, r.note);
      else {
        say(redactUrl(payload.tool_response, findUploadUrl(payload.tool_response)), 'Stark could not upload this file in time. Call pages_upload_begin again for this file.');
      }
    } else if (t.tool === 'pages_upload_commit') {
      recordCommit(payload, ctx);
    }
  } catch {
    // never crash; a begin result is never shown as it came
    try {
      if (begin) say(BLANK_RESULT, 'Stark could not upload this file: an internal error. Call pages_upload_begin again for this file.');
    } catch {
      // nothing more to do
    }
  }
  return 0;
}
