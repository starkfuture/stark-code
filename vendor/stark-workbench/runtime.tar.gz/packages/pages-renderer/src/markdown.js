// @ts-check
// markdown-it setup: no raw HTML, safe links only, typed fenced blocks.

import MarkdownIt from 'markdown-it';
import { classifyLink, escapeHtml, resolveImageSrc, toText } from './safe.js';

/**
 * @typedef {{ lang: string; info: string; content: string; line: number; data?: unknown; parseError?: string }} Block
 * @typedef {{
 *   assetPrefix?: string;
 *   blocks?: Block[];
 *   fallbackBlocks?: Block[];
 *   used?: Set<Block>;
 *   cursor?: Map<Block[], number>;
 *   minHeading?: number;
 *   diagrams?: Map<number, DiagramResult> | null;
 *   pageBlocks?: Block[];
 * }} RenderEnv
 * @typedef {{ svg: string, caption: string | null } | { error: string }} DiagramResult
 */

export const md = new MarkdownIt({ html: false, linkify: true, typographer: false });

md.validateLink = (url) => classifyLink(url) !== null;

const defaultRender = md.renderer.renderToken.bind(md.renderer);
const defaultFence = md.renderer.rules.fence;

md.renderer.rules.link_open = (tokens, idx, options, env, self) => {
  const token = tokens[idx];
  const kind = classifyLink(token.attrGet('href') ?? '');
  if (kind === null) token.attrSet('href', '#');
  if (kind === 'external') {
    token.attrSet('target', '_blank');
    token.attrSet('rel', 'noopener noreferrer');
  }
  return self.renderToken(tokens, idx, options);
};

md.renderer.rules.image = (tokens, idx, options, env, self) => {
  const token = tokens[idx];
  const alt = self.renderInlineAsText(token.children ?? [], options, env);
  const src = resolveImageSrc(token.attrGet('src') ?? '', /** @type {RenderEnv} */ (env)?.assetPrefix ?? '');
  if (src === null) {
    return `<span class="sp-img-blocked">[Image not shown: ${escapeHtml(alt || 'images must be files in img/')}]</span>`;
  }
  const title = token.attrGet('title');
  return `<img src="${escapeHtml(src)}" alt="${escapeHtml(alt)}"${title ? ` title="${escapeHtml(title)}"` : ''} loading="lazy" decoding="async">`;
};

/** @param {string} tag @param {RenderEnv} env */
function shiftHeading(tag, env) {
  const level = Number(tag.slice(1)) || 2;
  return `h${Math.min(6, Math.max(env?.minHeading ?? 1, level))}`;
}

md.renderer.rules.heading_open = (tokens, idx, options, env) => {
  const tag = shiftHeading(tokens[idx].tag, env);
  return `<${tag}>`;
};
md.renderer.rules.heading_close = (tokens, idx, options, env) => `</${shiftHeading(tokens[idx].tag, env)}>\n`;

md.renderer.rules.table_open = (tokens, idx, options) => `<div class="sp-table">${defaultRender(tokens, idx, options)}`;
md.renderer.rules.table_close = (tokens, idx, options) => `${defaultRender(tokens, idx, options)}</div>\n`;

/** @param {string} s */
function normalizeContent(s) {
  return toText(s)
    .split('\n')
    .map((line) => line.replace(/\s+$/, ''))
    .join('\n')
    .replace(/^\n+|\n+$/g, '');
}

/**
 * Find the parsed Block for a fence token: the section's own blocks first, then the
 * page's. Within a list, the next unused block of the same lang with the same content
 * is taken; fences come in file order, so this is usually the very next one (linear
 * time even for pages with thousands of blocks). Falls back to the first unused block.
 * @param {RenderEnv} env
 * @param {string} lang
 * @param {string} content
 * @returns {Block | null}
 */
function findBlock(env, lang, content) {
  const used = env?.used ?? new Set();
  const cursor = env?.cursor ?? new Map();
  const wanted = normalizeContent(content);
  /** @type {Block | null} */
  let firstFree = null;
  // The section's own blocks, in order: the next unused one normally matches.
  const own = Array.isArray(env?.blocks) ? env.blocks : [];
  let start = cursor.get(own) ?? 0;
  while (start < own.length && used.has(own[start])) start++;
  cursor.set(own, start);
  for (let i = start; i < own.length && i - start <= 64; i++) {
    const b = own[i];
    if (!b || b.lang !== lang || used.has(b)) continue;
    if (normalizeContent(b.content) === wanted) { used.add(b); return b; }
    firstFree ??= b;
  }
  // Then the whole page, through an index built once per block list.
  const all = Array.isArray(env?.fallbackBlocks) ? env.fallbackBlocks : [];
  if (all.length) {
    const index = blockIndex(all);
    const exact = (index.byContent.get(`${lang}\0${wanted}`) ?? []).find((b) => !used.has(b));
    if (exact) { used.add(exact); return exact; }
    if (!firstFree) firstFree = (index.byLang.get(lang) ?? []).find((b) => !used.has(b)) ?? null;
  }
  if (firstFree) used.add(firstFree);
  return firstFree;
}

/** @type {WeakMap<Block[], { byContent: Map<string, Block[]>, byLang: Map<string, Block[]> }>} */
const indexCache = new WeakMap();

/** @param {Block[]} list */
function blockIndex(list) {
  let index = indexCache.get(list);
  if (index) return index;
  index = { byContent: new Map(), byLang: new Map() };
  for (const b of list) {
    if (!b || typeof b.lang !== 'string') continue;
    if (b.lang !== 'options' && b.lang !== 'findings' && b.lang !== 'mermaid') continue;
    const key = `${b.lang}\0${normalizeContent(b.content)}`;
    for (const [map, k] of /** @type {const} */ ([[index.byContent, key], [index.byLang, b.lang]])) {
      const bucket = map.get(k);
      if (bucket) bucket.push(b); else map.set(k, [b]);
    }
  }
  indexCache.set(list, index);
  return index;
}

md.renderer.rules.fence = (tokens, idx, options, env, self) => {
  const token = tokens[idx];
  const lang = token.info.trim().split(/\s+/)[0] ?? '';
  if (lang === 'pending') {
    const text = token.content.trim();
    return `<div class="sp-pending"><span class="sp-pending__label">Pending</span><p>${text ? escapeHtml(text) : 'This part is not written yet.'}</p></div>\n`;
  }
  if (lang === 'mermaid') return renderMermaidBlock(env, token.content);
  if (lang === 'options' || lang === 'findings') {
    const block = findBlock(env, lang, token.content);
    if (block && !block.parseError) {
      const html = lang === 'options' ? renderOptions(block.data, env) : renderFindings(block.data, env);
      if (html !== null) return html;
    }
    const reason = block?.parseError ? ` ${escapeHtml(block.parseError)}` : '';
    return `<figure class="sp-raw-block"><pre class="sp-code"><code>${escapeHtml(token.content)}</code></pre><figcaption>This ${lang} block could not be read, so it is shown as text.${reason}</figcaption></figure>\n`;
  }
  return /** @type {NonNullable<typeof defaultFence>} */ (defaultFence)(tokens, idx, options, env, self).replace(/^<pre>/, '<pre class="sp-code">');
};

/** @type {WeakMap<Block[], Map<Block, number>>} */
const positionCache = new WeakMap();

/**
 * The drawn diagram for a mermaid fence, if `drawDiagrams` drew it (CONTRACTS.md 14.3).
 * @param {RenderEnv} env
 * @param {string} content
 * @returns {DiagramResult | null}
 */
function diagramFor(env, content) {
  const diagrams = env?.diagrams;
  const page = env?.pageBlocks;
  if (!(diagrams instanceof Map) || diagrams.size === 0 || !Array.isArray(page)) return null;
  const block = findBlock(env, 'mermaid', content);
  // Only the block with exactly this source: never show another diagram's drawing.
  if (!block || normalizeContent(block.content) !== normalizeContent(content)) return null;
  let positions = positionCache.get(page);
  if (!positions) {
    positions = new Map(page.map((b, i) => [b, i]));
    positionCache.set(page, positions);
  }
  const index = positions.get(block);
  return index === undefined ? null : diagrams.get(index) ?? null;
}

/**
 * A mermaid block: the drawn picture with its source folded under it, the source with
 * the reason when it could not be drawn, or (without drawings) the source as in slice 1.
 * @param {RenderEnv} env
 * @param {string} content
 */
function renderMermaidBlock(env, content) {
  const source = `<pre class="sp-code"><code>${escapeHtml(content)}</code></pre>`;
  const drawn = diagramFor(env, content);
  if (drawn && 'svg' in drawn && typeof drawn.svg === 'string') {
    const caption = toText(drawn.caption).trim();
    return `<figure class="sp-diagram sp-diagram--drawn">${drawn.svg}${caption ? `<figcaption>${escapeHtml(caption)}</figcaption>` : ''}</figure>\n`
      + `<details class="sp-diagram__source"><summary>Diagram source</summary>${source}</details>\n`;
  }
  if (drawn && 'error' in drawn) {
    return `<figure class="sp-diagram sp-diagram--error">${source}<figcaption>${escapeHtml(toText(drawn.error) || 'Diagram could not be drawn')}</figcaption></figure>\n`;
  }
  return `<figure class="sp-diagram">${source}<figcaption>Diagram source (drawing comes later)</figcaption></figure>\n`;
}

/**
 * Inline markdown (links, code, emphasis) for short strings from YAML values.
 * @param {unknown} value
 * @param {RenderEnv} [env]
 * @returns {string}
 */
export function inline(value, env = {}) {
  return md.renderInline(toText(value), { assetPrefix: env?.assetPrefix ?? '' });
}

/** @param {unknown} value @returns {string[]} */
function asList(value) {
  if (value === undefined || value === null || value === '') return [];
  if (Array.isArray(value)) return value.map(toText).filter((s) => s.trim() !== '');
  return [toText(value)];
}

/** @param {unknown} value @returns {value is Record<string, unknown>} */
function isRecord(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * Render an options block as cards. Returns null when the data is not a list
 * of options, so the caller falls back to showing the source.
 * @param {unknown} data
 * @param {RenderEnv} [env]
 * @returns {string | null}
 */
export function renderOptions(data, env = {}) {
  if (!Array.isArray(data) || data.length === 0 || !data.every(isRecord)) return null;
  const cards = data.map((item) => {
    const chosen = item.chosen === true;
    const pros = asList(item.pros);
    const cons = asList(item.cons);
    const cost = toText(item.cost).trim();
    const name = toText(item.name).trim() || 'Unnamed option';
    return [
      `<li class="sp-option${chosen ? ' sp-option--chosen' : ''}">`,
      `<div class="sp-option__head"><h3 class="sp-option__name">${escapeHtml(name)}</h3>`,
      chosen ? '<span class="sp-pill sp-pill--solid">Chosen</span>' : '',
      '</div>',
      pros.length
        ? `<div class="sp-option__group"><p class="sp-label">Pros</p><ul class="sp-marks sp-marks--pros">${pros.map((p) => `<li>${inline(p, env)}</li>`).join('')}</ul></div>`
        : '',
      cons.length
        ? `<div class="sp-option__group"><p class="sp-label">Cons</p><ul class="sp-marks sp-marks--cons">${cons.map((c) => `<li>${inline(c, env)}</li>`).join('')}</ul></div>`
        : '',
      cost ? `<p class="sp-option__cost"><span class="sp-label">Cost</span><span>${inline(cost, env)}</span></p>` : '',
      '</li>',
    ].join('');
  });
  return `<ul class="sp-options">${cards.join('')}</ul>\n`;
}

// Outline pills for every level: a solid pill is kept for the one chosen option.
const CONFIDENCE = /** @type {Record<string, string>} */ ({ high: 'sp-pill', medium: 'sp-pill', low: 'sp-pill sp-pill--muted' });

/**
 * Render a findings block as rows. Returns null when the data is not a list of findings.
 * @param {unknown} data
 * @param {RenderEnv} [env]
 * @returns {string | null}
 */
export function renderFindings(data, env = {}) {
  if (!Array.isArray(data) || data.length === 0 || !data.every(isRecord)) return null;
  const rows = data.map((item, i) => {
    const level = toText(item.confidence).trim().toLowerCase();
    const pillClass = Object.hasOwn(CONFIDENCE, level) ? CONFIDENCE[level] : 'sp-pill sp-pill--muted';
    const label = level ? level.toUpperCase() : 'NO CONFIDENCE';
    const sources = asList(item.sources);
    return [
      '<li class="sp-finding">',
      `<span class="sp-finding__num sp-id">${String(i + 1).padStart(2, '0')}</span>`,
      `<div class="sp-finding__body"><p class="sp-finding__claim">${inline(item.claim, env)}</p>`,
      sources.length
        ? `<p class="sp-finding__sources"><span class="sp-label">Sources</span> ${sources.map(renderSource).join('<span class="sp-sep" aria-hidden="true"> · </span>')}</p>`
        : '',
      '</div>',
      `<span class="${pillClass}" title="Confidence">${escapeHtml(label)}</span>`,
      '</li>',
    ].join('');
  });
  return `<ol class="sp-findings">${rows.join('')}</ol>\n`;
}

/**
 * A source string: a link when it is an http(s) URL, plain text otherwise.
 * @param {string} source
 * @returns {string}
 */
export function renderSource(source) {
  const s = source.trim();
  if (/^https?:\/\//i.test(s) && classifyLink(s) === 'external') {
    return `<a href="${escapeHtml(md.normalizeLink(s))}" target="_blank" rel="noopener noreferrer">${escapeHtml(s)}</a>`;
  }
  return `<span class="sp-source">${escapeHtml(s)}</span>`;
}

/**
 * Safe HTML for a markdown snippet.
 * @param {string} text
 * @param {{ assetBase?: string, minHeading?: number, diagrams?: Map<number, DiagramResult> | null, pageBlocks?: Block[] }} [opts]
 * @param {Block[]} [blocks] the blocks parsed from this text
 * @param {Block[]} [fallbackBlocks] other blocks to try (the whole page's)
 * @returns {string}
 */
export function renderMarkdownWith(text, opts = {}, blocks = [], fallbackBlocks = []) {
  /** @type {RenderEnv} */
  const env = {
    assetPrefix: opts.assetBase ?? '', blocks, fallbackBlocks, used: new Set(), cursor: new Map(), minHeading: opts.minHeading ?? 1,
    diagrams: opts.diagrams ?? null, pageBlocks: opts.pageBlocks,
  };
  return md.render(toText(text), env);
}
