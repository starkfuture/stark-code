// @ts-check
/**
 * Drawing mermaid blocks as pictures (CONTRACTS.md 14.3).
 *
 * `drawDiagrams(doc)` draws every mermaid block that passes the diagram rules (14.2) with
 * beautiful-mermaid, runs the result through `sanitizeSvg`, and returns a Map from the
 * block's index in `doc.blocks` to `{ svg, caption }` or `{ error }`. `renderPage` stays
 * synchronous and takes this Map as `opts.diagrams`.
 *
 * The cache holds the drawing tool's raw output, keyed by the SHA-256 of the tool version,
 * the renderer and sanitiser versions and the source. The sanitiser runs on every use, so
 * a cache file someone edited cannot get past it.
 */
import { createHash } from 'node:crypto';
import nodeFs from 'node:fs';
import nodePath from 'node:path';
import { checkMermaid, diagramCaption } from '@stark/page-format';
import { sanitizeSvg, SANITIZER_VERSION } from './svg-sanitize.js';
import { RENDERER_VERSION } from './render.js';

/** The drawing tool and the version every behaviour in FORMAT 6.8 was checked against. */
export const DRAWING_TOOL = 'beautiful-mermaid@1.1.3';

/** Options passed to the drawing tool. Colours do not matter: the sanitiser replaces them with classes. */
const DRAW_OPTIONS = Object.freeze({ padding: 16, transparent: true });

const NOT_DRAWN = 'Diagram could not be drawn';
/** Diagrams drawn per page; later ones show as source. */
export const MAX_DIAGRAMS = 40;
const MEMORY_LIMIT = 200;

/** @type {Map<string, string>} key -> raw tool output */
const memory = new Map();

/**
 * @typedef {{ svg: string, caption: string | null } | { error: string }} DiagramResult
 * @typedef {(source: string) => Promise<string> | string} DrawFn
 * @typedef {{
 *   cacheDir?: string | null,
 *   draw?: DrawFn,
 *   fs?: Pick<typeof nodeFs, 'readFileSync' | 'writeFileSync' | 'mkdirSync' | 'renameSync'>,
 * }} DrawOptions
 */

/** @type {DrawFn | null} */
let tool = null;

/** The real drawing tool, loaded on first use. @returns {Promise<DrawFn>} */
async function loadTool() {
  if (tool) return tool;
  const mod = /** @type {any} */ (await import('beautiful-mermaid'));
  const render = mod.renderMermaid ?? mod.renderMermaidSVGAsync;
  if (typeof render !== 'function') throw new Error('beautiful-mermaid has no renderMermaid function.');
  tool = (source) => render(source, DRAW_OPTIONS);
  return tool;
}

/**
 * The cache key for a diagram source.
 * @param {string} source
 */
export function diagramKey(source) {
  return createHash('sha256').update(`${DRAWING_TOOL}\0${RENDERER_VERSION}\0${SANITIZER_VERSION}\0${source}`).digest('hex');
}

/**
 * @param {DrawOptions['fs']} fs @param {string | null | undefined} dir @param {string} key
 * @returns {string | null}
 */
function readCache(fs, dir, key) {
  const hit = memory.get(key);
  if (hit !== undefined) return hit;
  if (!dir || !fs) return null;
  try {
    const text = String(fs.readFileSync(nodePath.join(dir, `${key}.svg`), 'utf8'));
    remember(key, text);
    return text;
  } catch {
    return null;
  }
}

/** @param {string} key @param {string} raw */
function remember(key, raw) {
  if (memory.size >= MEMORY_LIMIT) memory.delete(/** @type {string} */ (memory.keys().next().value));
  memory.set(key, raw);
}

/**
 * @param {DrawOptions['fs']} fs @param {string | null | undefined} dir @param {string} key @param {string} raw
 */
function writeCache(fs, dir, key, raw) {
  remember(key, raw);
  if (!dir || !fs) return;
  try {
    fs.mkdirSync(dir, { recursive: true });
    const tmp = nodePath.join(dir, `.${key}.${process.pid}.tmp`);
    fs.writeFileSync(tmp, raw);
    fs.renameSync(tmp, nodePath.join(dir, `${key}.svg`));
  } catch {
    // the cache is optional
  }
}

/**
 * The source as the drawing tool needs it: it reads the diagram kind from the first line,
 * so leading comment lines (the caption) are left out. Other comment lines stay; they do
 * not change the picture (FORMAT 6.8).
 * @param {string} source
 */
export function toolSource(source) {
  const lines = source.replace(/\r\n?/g, '\n').split('\n');
  let i = 0;
  while (i < lines.length && (!lines[i].trim() || lines[i].trim().startsWith('%%'))) i++;
  return lines.slice(i).join('\n');
}

/**
 * Draw one diagram source: check the rules, draw, sanitise.
 * @param {string} source
 * @param {{ idPrefix: string } & DrawOptions} o
 * @returns {Promise<DiagramResult>}
 */
export async function drawDiagram(source, o) {
  const check = checkMermaid(source);
  const first = check.problems.find((p) => p.severity === 'error');
  if (first) return { error: `${NOT_DRAWN}: ${first.message}` };
  const caption = diagramCaption(source);
  const fs = o.fs ?? nodeFs;
  const key = diagramKey(source);
  let raw = readCache(fs, o.cacheDir, key);
  let fresh = false;
  if (raw === null) {
    try {
      const draw = o.draw ?? (await loadTool());
      raw = String(await draw(toolSource(source)));
      fresh = true;
    } catch {
      return { error: NOT_DRAWN };
    }
  }
  try {
    const svg = sanitizeSvg(raw, { idPrefix: o.idPrefix, title: caption ?? 'Diagram' });
    if (fresh) writeCache(fs, o.cacheDir, key, raw);
    return { svg, caption };
  } catch {
    if (!fresh) memory.delete(key);
    return { error: NOT_DRAWN };
  }
}

/**
 * Draw every mermaid block of a page.
 * @param {{ blocks?: Array<{ lang: string, content: string }> } | null | undefined} doc a PageDoc
 * @param {DrawOptions} [opts] `cacheDir`: the mirror and `publish prepare` pass `<root>/pages/.spage/diagrams`
 * @returns {Promise<Map<number, DiagramResult>>}
 */
export async function drawDiagrams(doc, opts = {}) {
  /** @type {Map<number, DiagramResult>} */
  const out = new Map();
  const blocks = Array.isArray(doc?.blocks) ? doc.blocks : [];
  let drawn = 0;
  for (let i = 0; i < blocks.length; i++) {
    const b = blocks[i];
    if (!b || b.lang !== 'mermaid' || typeof b.content !== 'string') continue;
    // Drawing takes a few milliseconds each; a page with hundreds would stall the mirror.
    if (++drawn > MAX_DIAGRAMS) {
      out.set(i, { error: `${NOT_DRAWN}: a page draws at most ${MAX_DIAGRAMS} diagrams.` });
      continue;
    }
    out.set(i, await drawDiagram(b.content, { ...opts, idPrefix: `sp-d${i}` }));
  }
  return out;
}

/** Forget the in-memory cache (tests). */
export function clearDiagramMemory() {
  memory.clear();
}
