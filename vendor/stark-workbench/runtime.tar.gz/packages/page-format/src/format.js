// @ts-check

/**
 * @typedef {import('./parse.js').Issue} Issue
 */

/**
 * Replace control characters (escape codes that could retitle or clear a terminal)
 * with U+FFFD. Page text is untrusted and these lines go to terminals and to Claude.
 * @param {string} s
 */
export function safeText(s) {
  return String(s).replace(/[\u0000-\u0008\u000b-\u001f\u007f-\u009f]/g, '�');
}

/** @param {number} n @param {string} word */
function plural(n, word) {
  return `${n} ${word}${n === 1 ? '' : 's'}`;
}

/**
 * One line per issue, errors first, then a summary line like "2 errors, 1 warning".
 * Accepts a ValidationResult ({ errors, warnings }) or a plain list of issues.
 * @param {{ errors?: Issue[], warnings?: Issue[] } | Issue[]} result
 * @param {{ file?: string }} [opts]
 */
export function formatIssues(result, { file = 'index.md' } = {}) {
  /** @type {Issue[]} */
  let errors;
  /** @type {Issue[]} */
  let warnings;
  if (Array.isArray(result)) {
    errors = result.filter((i) => i.severity === 'error');
    warnings = result.filter((i) => i.severity !== 'error');
  } else {
    errors = result?.errors ?? [];
    warnings = result?.warnings ?? [];
  }
  const lines = [...errors, ...warnings].map((i) => {
    const where = i.line == null ? file : `${file}:${i.line}`;
    const message = /[.!?:]$/.test(i.message) ? i.message : `${i.message}.`;
    const hint = i.hint ? ` Hint: ${i.hint}` : '';
    return safeText(`${where}  ${i.severity}  [${i.code}] ${message}${hint}`).replace(/\n/g, ' ');
  });
  lines.push(`${plural(errors.length, 'error')}, ${plural(warnings.length, 'warning')}`);
  return lines.join('\n');
}
