---
schema: 1
type: explainer
title: How the thing works, in plain words
owner: ""
status: draft
verified: null
reviewBy: null
sources: []
supersedes: null
---

## Summary

```pending
What it is and why it matters, in three to five sentences.
```

## Tour

```pending
Walk through the parts in the order a newcomer meets them. One short paragraph per step.
```

```mermaid
flowchart LR
  A[First part] --> B[Second part]
```
