// @ts-check
/**
 * The mirror's request handler: a pure function of its options, so tests drive it
 * with fake request and response objects and never bind a port.
 *
 * Routes (CONTRACTS.md sections 8, 11 and 13.3):
 *   GET  /follow                 follower page (`?slug=` starts on a page)
 *   GET  /panel                  page panel for the Stark Code app (`?slug=`)
 *   GET  /events                 Server-Sent Events (`show`)
 *   GET  /p/<slug>               rendered page (`?view=panel` forces the narrow layout)
 *   GET  /p/<slug>/img/<file>    image from the page's img/ folder (no svg)
 *   POST /p/<slug>/img?name=N    image upload from /follow and /panel (CSRF token, same origin)
 *   POST /notify                 hooks and `spage notify` (token, no Origin)
 *   GET  /api/pages              page list
 *   GET  /health                 token check for liveMirror and the app
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createBroadcaster } from './sse.js';
import { MAX_UPLOAD_BYTES, UPLOAD_TYPES, followerCsp, renderFollower } from './follower.js';
import { cleanEmbedOrigins, isEmbeddableRoute, isPanelNavigation, loadEmbedOrigins, withFrameAncestors } from './embed.js';
import { panelCsp, renderPanel } from './panel.js';
import { formatEvent } from './sse.js';
import {
  MAX_PAGE_BYTES, findPageForFile, isRealPageFile, isSlug, listPagesMeta, pagesDir, readPageMeta, readPageText,
} from './pages.js';

/**
 * `view` is 'panel' for `/p/<slug>?view=panel` (narrow layout forced); the render
 * function passes it to renderPage as `view`.
 * @typedef {{ slug: string, dir: string, file: string, text: string, assetBase: string, view?: 'panel' }} RenderInput
 * @typedef {(input: RenderInput) => string | Promise<string>} RenderFn
 * @typedef {{
 *   method?: string, url?: string, headers: Record<string, string | string[] | undefined>,
 *   on?: (ev: string, fn: (...a: any[]) => void) => unknown,
 *   [Symbol.asyncIterator]?: () => AsyncIterator<any>
 * }} Req
 * @typedef {{
 *   writeHead: (status: number, headers?: Record<string, string | number>) => unknown,
 *   write: (chunk: any) => unknown,
 *   end: (chunk?: any) => unknown,
 *   on?: (ev: string, fn: (...a: any[]) => void) => unknown,
 *   headersSent?: boolean, writableEnded?: boolean, destroyed?: boolean,
 *   flushHeaders?: () => void
 * }} Res
 */

export const IMAGE_TYPES = /** @type {Record<string, string>} */ ({
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
});

export const PAGE_CSP = [
  "default-src 'none'",
  "img-src 'self' data:",
  "style-src 'unsafe-inline'",
  'font-src https://assets.starkfuture.com',
  "base-uri 'none'",
  "form-action 'none'",
  "frame-ancestors 'self'",
].join('; ');

export const BASE_HEADERS = Object.freeze({
  'Content-Security-Policy': "frame-ancestors 'self'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Cache-Control': 'no-store',
  // Other sites cannot embed mirror responses (for example an <img> that probes for a page).
  'Cross-Origin-Resource-Policy': 'same-origin',
});

const MAX_BODY = 64 * 1024;

/**
 * The image module's upload entry point (CONTRACTS.md section 13.2), injected so tests
 * use a fake. Errors may carry `status` (400, 413, 415 or 422) and a plain message.
 * @typedef {{ saveUpload: (root: string, slug: string, bytes: Buffer, o: { contentType: string, name?: string }) =>
 *   { file: string, markdown: string } | Promise<{ file: string, markdown: string }> }} ImagesApi
 */

/**
 * @param {{
 *   root: string,
 *   token: string,
 *   render: RenderFn,
 *   now?: () => Date,
 *   port?: number,
 *   broadcaster?: import('./sse.js').Broadcaster,
 *   fs?: typeof fs,
 *   nonce?: () => string,
 *   onActivity?: () => void,
 *   embedOrigins?: readonly string[],
 *   csrf?: string,
 *   images?: ImagesApi,
 *   log?: (line: string) => void,
 * }} opts
 * `embedOrigins`: who may frame /panel and /p/* (section 11.2); default: built-ins,
 *   $SPAGE_EMBED_ORIGINS and ~/.stark/embed-origins, bad entries logged through `log`.
 * `csrf`: the upload token embedded in /follow and /panel (section 13.3); default: random.
 * `images`: provides saveUpload; default: ./images.js, loaded on the first upload.
 * `log`: one line per message; default: stderr (mirror.log for a background mirror).
 */
export function createMirrorHandler(opts) {
  const { root, token, render } = opts;
  if (typeof root !== 'string' || !root) throw new Error('createMirrorHandler needs a root folder.');
  if (typeof token !== 'string' || token.length < 16) throw new Error('createMirrorHandler needs a token of at least 16 characters.');
  if (typeof render !== 'function') throw new Error('createMirrorHandler needs a render function.');
  const now = opts.now ?? (() => new Date());
  const f = opts.fs ?? fs;
  const sse = opts.broadcaster ?? createBroadcaster();
  const makeNonce = opts.nonce ?? (() => crypto.randomBytes(16).toString('base64'));
  const tokenBuf = Buffer.from(token, 'utf8');
  const log = opts.log ?? ((/** @type {string} */ line) => { try { process.stderr.write(line + '\n'); } catch { /* no stderr */ } });
  const embedOrigins = opts.embedOrigins ? cleanEmbedOrigins(opts.embedOrigins) : loadEmbedOrigins({ log });
  const csrf = opts.csrf ?? crypto.randomBytes(32).toString('hex');
  if (typeof csrf !== 'string' || csrf.length < 16) throw new Error('createMirrorHandler needs a csrf token of at least 16 characters.');
  const csrfBuf = Buffer.from(csrf, 'utf8');
  /** @type {WeakSet<Res>} responses on routes the app may frame */
  const embeddable = new WeakSet();
  let rev = 0;
  /** @type {import('./follower.js').ShowEvent | null} */
  let lastShown = null;

  /** @param {Req} req */
  function hostOk(req) {
    const host = String(req.headers.host ?? '').toLowerCase();
    const m = /^(127\.0\.0\.1|localhost):(\d{1,5})$/.exec(host);
    if (!m) return false;
    return opts.port === undefined || Number(m[2]) === opts.port;
  }

  /**
   * @param {Res} res @param {number} status @param {string} type @param {string | Buffer} body
   * @param {Record<string, string>} [extra]
   */
  function send(res, status, type, body, extra = {}) {
    const buf = typeof body === 'string' ? Buffer.from(body, 'utf8') : body;
    /** @type {Record<string, string | number>} */
    const headers = { ...BASE_HEADERS, 'Content-Type': type, 'Content-Length': buf.length, ...extra };
    if (embeddable.has(res)) headers['Content-Security-Policy'] = withFrameAncestors(String(headers['Content-Security-Policy']), embedOrigins);
    res.writeHead(status, headers);
    res.end(buf);
  }

  /** @param {Res} res @param {number} status @param {string} message */
  function text(res, status, message) {
    send(res, status, 'text/plain; charset=utf-8', message + '\n');
  }

  /** @param {Res} res @param {number} status @param {unknown} data */
  function json(res, status, data) {
    send(res, status, 'application/json; charset=utf-8', JSON.stringify(data));
  }

  /** A page folder and its index.md, both real (not symlinks out of pages/). */
  function pageRef(/** @type {string} */ slug) {
    if (!isSlug(slug)) return null;
    if (!isRealPageFile(root, slug, { fs: f })) return null;
    const dir = path.join(pagesDir(root), slug);
    return { root, slug, dir, file: path.join(dir, 'index.md') };
  }

  /** @param {Req} req */
  async function readBody(req) {
    if (!req[Symbol.asyncIterator]) return '';
    /** @type {Buffer[]} */
    const chunks = [];
    let size = 0;
    for await (const chunk of /** @type {AsyncIterable<any>} */ (req)) {
      const b = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk));
      size += b.length;
      if (size > MAX_BODY) throw Object.assign(new Error('body too large'), { status: 413 });
      chunks.push(b);
    }
    return Buffer.concat(chunks).toString('utf8');
  }

  /** @param {Req} req */
  function tokenOk(req) {
    const given = req.headers['x-spage-token'];
    if (typeof given !== 'string' || given.length === 0) return false;
    const buf = Buffer.from(given, 'utf8');
    return buf.length === tokenBuf.length && crypto.timingSafeEqual(buf, tokenBuf);
  }

  /** @param {Req} req @param {Res} res */
  async function onNotify(req, res) {
    if (req.headers.origin !== undefined) return text(res, 403, 'Refused: requests from a browser page are not allowed.');
    if (!tokenOk(req)) return text(res, 403, 'Refused: missing or wrong X-Spage-Token header. Read the token from pages/.spage/mirror.json.');
    let body;
    try {
      body = JSON.parse((await readBody(req)) || 'null');
    } catch (e) {
      const status = /** @type {any} */ (e).status === 413 ? 413 : 400;
      return text(res, status, status === 413 ? 'Body too large.' : 'Body must be JSON like {"slug":"my-page"}.');
    }
    if (!body || typeof body !== 'object') return text(res, 400, 'Body must be JSON like {"slug":"my-page"}.');
    /** @type {string | undefined} */
    let slug;
    if (typeof body.slug === 'string') slug = body.slug;
    else if (typeof body.path === 'string') {
      const found = findPageForFile(body.path, root);
      if (found && path.resolve(found.root) === path.resolve(root)) slug = found.slug;
    }
    if (!slug) return text(res, 400, 'Give "slug" or a "path" inside this mirror\'s pages/ folder.');
    const ref = pageRef(slug);
    if (!ref) return text(res, 404, `No page "${slug}" under pages/. Check the slug.`);
    const meta = readPageMeta(ref, { fs: f });
    rev += 1;
    const event = {
      slug,
      title: meta?.title ?? slug,
      type: meta?.type ?? 'unknown',
      status: meta?.status ?? 'unknown',
      rev,
      at: now().toISOString(),
    };
    lastShown = event;
    opts.onActivity?.();
    const followers = sse.send('show', event, rev);
    return json(res, 200, { ok: true, rev, followers });
  }

  /** @param {Req} req @param {Res} res */
  function onEvents(req, res) {
    res.writeHead(200, {
      ...BASE_HEADERS,
      'Content-Type': 'text/event-stream; charset=utf-8',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.flushHeaders?.();
    const remove = sse.add(res);
    opts.onActivity?.();
    // A follower that reconnects says which event it saw last (Last-Event-ID, or ?since=
    // on its first connect). Replay the latest "show" it missed.
    const raw = req.headers['last-event-id'] ?? sinceParam(req.url);
    const since = raw === undefined || raw === null || raw === '' ? NaN : Number(raw);
    if (lastShown && Number.isFinite(since) && since < lastShown.rev) {
      try { res.write(formatEvent('show', lastShown, lastShown.rev)); } catch { /* client gone */ }
    }
    // A follower leaving counts as activity too, so the idle clock starts then.
    const done = () => { remove(); opts.onActivity?.(); };
    req.on?.('close', done);
    res.on?.('close', done);
  }

  /** @param {Req} req @param {Res} res */
  function onHealth(req, res) {
    if (req.headers.origin !== undefined || !tokenOk(req)) return text(res, 403, 'Refused: missing or wrong X-Spage-Token header.');
    return json(res, 200, { ok: true, root: path.resolve(root), pid: process.pid });
  }

  /**
   * The page a follower or panel starts on: `?slug=` when it names a page, else the
   * last page shown, else the newest page.
   * @param {URL} url
   * @returns {import('./follower.js').ShowEvent | null}
   */
  function initialPage(url) {
    const wanted = url.searchParams.get('slug');
    if (wanted) {
      const ref = pageRef(wanted);
      const meta = ref ? readPageMeta(ref, { fs: f }) : null;
      // rev stays at the latest show, so the event stream does not replay it over this page.
      if (meta) return { slug: meta.slug, title: meta.title, type: meta.type, status: meta.status, rev: lastShown?.rev ?? 0, at: meta.mtime };
    }
    if (lastShown) return lastShown;
    const newest = listPagesMeta(root, { fs: f })[0];
    return newest ? { slug: newest.slug, title: newest.title, type: newest.type, status: newest.status, rev: 0, at: newest.mtime } : null;
  }

  /** @param {Res} res @param {URL} url */
  function onFollow(res, url) {
    const nonce = makeNonce();
    send(res, 200, 'text/html; charset=utf-8', renderFollower({ nonce, initial: initialPage(url), csrf }), {
      'Content-Security-Policy': followerCsp(nonce),
    });
  }

  /** @param {Req} req @param {Res} res @param {URL} url */
  function onPanel(req, res, url) {
    const nonce = makeNonce();
    const hostPort = Number(/:(\d{1,5})$/.exec(String(req.headers.host ?? ''))?.[1]);
    const port = opts.port ?? (Number.isInteger(hostPort) ? hostPort : 0);
    const html = renderPanel({ nonce, initial: initialPage(url), csrf, embedOrigins, port, root: path.resolve(root) });
    send(res, 200, 'text/html; charset=utf-8', html, { 'Content-Security-Policy': panelCsp(nonce, embedOrigins) });
  }

  /** @param {Req} req @param {number} max */
  async function readBytes(req, max) {
    if (!req[Symbol.asyncIterator]) return Buffer.alloc(0);
    /** @type {Buffer[]} */
    const chunks = [];
    let size = 0;
    for await (const chunk of /** @type {AsyncIterable<any>} */ (req)) {
      const b = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      size += b.length;
      if (size > max) throw Object.assign(new Error('body too large'), { status: 413 });
      chunks.push(b);
    }
    return Buffer.concat(chunks);
  }

  /** @param {Req} req */
  function csrfOk(req) {
    const given = req.headers['x-spage-csrf'];
    if (typeof given !== 'string' || given.length === 0) return false;
    const buf = Buffer.from(given, 'utf8');
    return buf.length === csrfBuf.length && crypto.timingSafeEqual(buf, csrfBuf);
  }

  /** @type {ImagesApi | null} */
  let imagesApi = opts.images ?? null;

  /**
   * POST /p/<slug>/img?name=<name>: an image dropped or pasted into /follow or /panel.
   * @param {Req} req @param {Res} res @param {string} slug @param {URL} url
   */
  async function onUpload(req, res, slug, url) {
    const h = req.headers;
    if (String(h['sec-fetch-site'] ?? '').toLowerCase() !== 'same-origin') {
      return text(res, 403, 'Refused: uploads must come from the mirror page itself.');
    }
    const origin = h.origin;
    if (typeof origin !== 'string' || origin.toLowerCase() !== `http://${String(h.host ?? '').toLowerCase()}`) {
      return text(res, 403, 'Refused: uploads must come from the mirror page itself.');
    }
    if (!csrfOk(req)) return text(res, 403, 'Refused: missing or wrong upload token. Reload the mirror page and try again.');
    const contentType = String(h['content-type'] ?? '').split(';')[0].trim().toLowerCase();
    if (!UPLOAD_TYPES.includes(contentType)) {
      return text(res, 415, 'Only PNG, JPEG, WebP and GIF images can be added.');
    }
    const declared = Number(h['content-length']);
    if (Number.isFinite(declared) && declared > MAX_UPLOAD_BYTES) return text(res, 413, 'This image is over 10 MB. Make it smaller first.');
    const ref = pageRef(slug);
    if (!ref) return text(res, 404, `No page "${slug}" under pages/.`);
    const rawName = url.searchParams.get('name');
    const name = rawName ? rawName.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 120) || undefined : undefined;
    let bytes;
    try {
      bytes = await readBytes(req, MAX_UPLOAD_BYTES);
    } catch (e) {
      if (/** @type {any} */ (e).status === 413) return text(res, 413, 'This image is over 10 MB. Make it smaller first.');
      throw e;
    }
    if (bytes.length === 0) return text(res, 400, 'The upload was empty.');
    if (!imagesApi) {
      try {
        imagesApi = /** @type {ImagesApi} */ (/** @type {unknown} */ (await import('./images.js')));
      } catch {
        imagesApi = null;
      }
      if (!imagesApi || typeof imagesApi.saveUpload !== 'function') {
        imagesApi = null;
        return text(res, 501, 'Image upload is not available in this version of spage.');
      }
    }
    let saved;
    try {
      saved = await imagesApi.saveUpload(root, slug, bytes, { contentType, ...(name ? { name } : {}) });
    } catch (e) {
      const status = /** @type {any} */ (e)?.status;
      const msg = e instanceof Error ? e.message : String(e);
      return text(res, [400, 413, 415, 422].includes(status) ? status : 422, `Could not add the image: ${msg}`);
    }
    opts.onActivity?.();
    json(res, 200, { file: saved.file, markdown: saved.markdown });
    // Any local program can call this route (it can read the token from /follow), so
    // every open follower and panel shows each upload: Claude's inbox note then names
    // only an image the user could see arrive. No id: a reconnect replays only "show".
    const added = { slug, file: String(saved.file), at: now().toISOString() };
    log(`Image added to page ${slug} from the mirror: img/${added.file}`);
    sse.send('added', added);
  }

  /** @param {Res} res @param {string} slug @param {URL} url */
  async function onPage(res, slug, url) {
    const ref = pageRef(slug);
    if (!ref) return text(res, 404, `No page "${slug}" under pages/.`);
    let html;
    try {
      // Pages over the limit are not rendered at all: rendering is slow on huge input
      // and would block every other follower.
      const read = readPageText(ref.file, { fs: f, maxBytes: MAX_PAGE_BYTES });
      if (!read.ok) {
        const msg = read.issue.code === 'size'
          ? `This page is too large to show (${Math.ceil(read.bytes / 1024)} KB, limit ${MAX_PAGE_BYTES / 1024} KB). Split it or move data into files under the page folder.`
          : 'This page is not a text file, so it cannot be shown. Write index.md as plain markdown.';
        return send(res, 200, 'text/html; charset=utf-8', notShownDoc(slug, msg), { 'Content-Security-Policy': PAGE_CSP });
      }
      const view = url.searchParams.get('view') === 'panel' ? /** @type {const} */ ('panel') : undefined;
      html = await render({ ...ref, text: read.text, assetBase: `/p/${slug}/`, ...(view ? { view } : {}) });
    } catch (e) {
      return text(res, 500, `Could not render "${slug}": ${e instanceof Error ? e.message : String(e)}`);
    }
    send(res, 200, 'text/html; charset=utf-8', String(html), { 'Content-Security-Policy': PAGE_CSP });
  }

  /** @param {Res} res @param {string} slug @param {string} rawName */
  function onImage(res, slug, rawName) {
    const notFound = () => text(res, 404, 'No such image.');
    let name;
    try {
      name = decodeURIComponent(rawName);
    } catch {
      return notFound();
    }
    if (!name || name.startsWith('.') || /[\\/\0]/.test(name) || name.includes('..')) return notFound();
    const type = IMAGE_TYPES[path.extname(name).toLowerCase()];
    if (!type) return text(res, 404, 'Only png, jpg, jpeg, gif and webp images are served.');
    const ref = pageRef(slug);
    if (!ref) return notFound();
    const imgDir = path.join(ref.dir, 'img');
    try {
      const realPages = f.realpathSync(pagesDir(root));
      const realPage = f.realpathSync(ref.dir);
      const realImg = f.realpathSync(imgDir);
      const realFile = f.realpathSync(path.join(imgDir, name));
      if (!within(realPage, realPages) || !within(realImg, realPage) || path.dirname(realFile) !== realImg) return notFound();
      const st = f.statSync(realFile);
      if (!st.isFile() || st.size > 20 * 1024 * 1024) return notFound();
      const data = f.readFileSync(realFile);
      return send(res, 200, type, data);
    } catch {
      return notFound();
    }
  }

  /**
   * @param {Req} req @param {Res} res
   * @returns {Promise<void>}
   */
  async function handler(req, res) {
    try {
      if (!hostOk(req)) return text(res, 403, 'Refused: wrong Host header. Open the mirror at http://127.0.0.1:<port>/follow.');
      const method = (req.method ?? 'GET').toUpperCase();
      let url;
      try {
        url = new URL(req.url ?? '/', 'http://127.0.0.1');
      } catch {
        return text(res, 400, 'Bad request URL.');
      }
      const p = url.pathname;
      // Browsers mark requests that come from another site. The mirror serves nothing to
      // them, except the app framing /panel (section 11.2).
      if (String(req.headers['sec-fetch-site'] ?? '').toLowerCase() === 'cross-site' && !isPanelNavigation(req, p)) {
        return text(res, 403, 'Refused: requests from other sites are not allowed.');
      }
      if ((method === 'GET' || method === 'HEAD') && isEmbeddableRoute(p)) embeddable.add(res);

      if (p === '/notify') {
        if (method !== 'POST') return text(res, 405, 'Use POST for /notify.');
        return await onNotify(req, res);
      }
      const up = /^\/p\/([^/]+)\/img\/?$/.exec(p);
      if (up && method === 'POST') return await onUpload(req, res, safeDecode(up[1]), url);
      if (method !== 'GET' && method !== 'HEAD') return text(res, 405, 'Only GET is allowed here.');

      if (p === '/') {
        res.writeHead(302, { ...BASE_HEADERS, Location: '/follow', 'Content-Length': 0 });
        res.end();
        return;
      }
      if (p === '/health') return onHealth(req, res);
      if (p === '/follow') return onFollow(res, url);
      if (p === '/panel') return onPanel(req, res, url);
      if (p === '/events') return onEvents(req, res);
      if (p === '/api/pages') {
        return json(res, 200, listPagesMeta(root, { fs: f }).map(({ mtimeMs, ...m }) => m));
      }
      let m = /^\/p\/([^/]+)\/?$/.exec(p);
      if (m) return await onPage(res, safeDecode(m[1]), url);
      m = /^\/p\/([^/]+)\/img\/([^/]+)$/.exec(p);
      if (m) return onImage(res, safeDecode(m[1]), m[2]);
      return text(res, 404, 'Not found. The follower is at /follow.');
    } catch (e) {
      if (!res.headersSent) return text(res, 500, 'Internal error: ' + (e instanceof Error ? e.message : String(e)));
      try { res.end(); } catch { /* ignore */ }
    }
  }

  handler.broadcaster = sse;
  handler.embedOrigins = embedOrigins;
  return handler;
}

/** @param {string | undefined} url */
function sinceParam(url) {
  try {
    return new URL(url ?? '/', 'http://127.0.0.1').searchParams.get('since') ?? undefined;
  } catch {
    return undefined;
  }
}

/** A tiny page shown instead of a page that cannot be rendered. @param {string} slug @param {string} message */
function notShownDoc(slug, message) {
  const esc = (/** @type {string} */ s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] ?? c);
  return `<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(slug)}</title>`
    + '<style>body{margin:0;padding:3rem 1.5rem;background:#000;color:#fff;font:16px/1.5 system-ui,sans-serif}@media (prefers-color-scheme: light){body{background:#fff;color:#000}}p{max-width:40rem}</style>'
    + `</head><body><p>${esc(message)}</p></body></html>\n`;
}

/** @param {string} s */
function safeDecode(s) {
  try {
    return decodeURIComponent(s);
  } catch {
    return '';
  }
}

/** @param {string} child @param {string} parent */
function within(child, parent) {
  return child === parent || child.startsWith(parent.endsWith(path.sep) ? parent : parent + path.sep);
}
