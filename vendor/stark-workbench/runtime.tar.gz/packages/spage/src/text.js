// @ts-check
/**
 * Page text is untrusted. Before it goes to a terminal, replace control characters
 * (escape codes can set the terminal title or clear the screen) with U+FFFD.
 * The same rule as safeText in @stark/page-format, kept here so `spage` works
 * even when the dependencies fail to load.
 * @param {unknown} s
 */
export function safeTerminalText(s) {
  return String(s).replace(/[\u0000-\u0008\u000a-\u001f\u007f-\u009f]/g, '�');
}
