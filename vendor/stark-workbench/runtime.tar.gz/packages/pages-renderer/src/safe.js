// @ts-check
// Escaping and URL safety helpers. Everything the renderer puts into HTML goes
// through escapeHtml, and every href or src goes through classifyLink first.

/** @typedef {'external' | 'mailto' | 'anchor' | 'relative'} LinkKind */

const HTML_ESCAPES = /** @type {Record<string, string>} */ ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
});

/**
 * Escape a value for use in HTML text or a double- or single-quoted attribute.
 * @param {unknown} value
 * @returns {string}
 */
export function escapeHtml(value) {
  return toText(value).replace(/[&<>"']/g, (ch) => HTML_ESCAPES[ch]);
}

/**
 * Turn any header or block value into display text. Never throws.
 * @param {unknown} value
 * @returns {string}
 */
export function toText(value) {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'boolean' || typeof value === 'bigint') return String(value);
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? '' : value.toISOString().slice(0, 10);
  if (Array.isArray(value)) return value.map(toText).join(', ');
  try {
    return JSON.stringify(value) ?? '';
  } catch {
    return '';
  }
}

/**
 * Decide whether a link target is safe, and what kind it is.
 * Allowed: http, https, mailto, in-page anchors and relative paths.
 * Refused (returns null): javascript:, data:, file:, any other scheme,
 * protocol-relative URLs (//host) and their backslash variants.
 * @param {unknown} raw
 * @returns {LinkKind | null}
 */
export function classifyLink(raw) {
  if (typeof raw !== 'string') return null;
  // Browsers drop tabs, newlines and control characters while parsing a URL,
  // so check the string the browser will actually see.
  const url = raw.replace(/[\u0000- \u007f-\u009f]/g, '');
  if (url === '') return null;
  if (url.startsWith('#')) return 'anchor';
  if (/^[\\/]{2}/.test(url)) return null;
  const scheme = /^([^:/?#]*):/.exec(url);
  if (scheme) {
    const name = scheme[1].toLowerCase();
    if (name === 'http' || name === 'https') return 'external';
    if (name === 'mailto') return 'mailto';
    return null;
  }
  return 'relative';
}

/**
 * Resolve an image source. Only relative paths directly in img/ are shown; anything
 * else (remote, absolute, data:, paths with "..") returns null.
 * @param {string} src
 * @param {string} prefix normalised assetBase ('' or ending with '/')
 * @returns {string | null}
 */
export function resolveImageSrc(src, prefix) {
  if (classifyLink(src) !== 'relative') return null;
  let path = src;
  while (path.startsWith('./')) path = path.slice(2);
  if (!path.startsWith('img/')) return null;
  let decoded = path;
  try {
    decoded = decodeURIComponent(path);
  } catch {
    return null;
  }
  const segments = decoded.split(/[\\/]/);
  // Flat img/ only, the same rule as the checker and the mirror.
  if (segments.length !== 2 || segments.some((s) => s === '..' || s === '.' || s === '')) return null;
  return prefix + path;
}

/**
 * Normalise the assetBase option.
 * @param {unknown} value
 * @returns {{ prefix: string, origin: string | null }}
 */
export function normalizeAssetBase(value) {
  if (value === undefined || value === null || value === '') return { prefix: '', origin: null };
  if (typeof value !== 'string') {
    throw new TypeError('assetBase must be a string, such as "/p/my-page/" or "https://example.com/pages/my-page/".');
  }
  if (/[\s"'<>`]/.test(value)) {
    throw new Error(`assetBase "${value}" contains spaces or quotes. Use a plain URL prefix.`);
  }
  const kind = classifyLink(value);
  const prefix = value.endsWith('/') ? value : `${value}/`;
  if (kind === 'relative') return { prefix, origin: null };
  if (kind === 'external') {
    let origin;
    try {
      origin = new URL(value).origin;
    } catch {
      origin = '';
    }
    if (!/^https?:\/\/(\[[0-9a-f:.]+\]|[a-z0-9.-]+)(:\d+)?$/i.test(origin)) {
      throw new Error(`assetBase "${value}" is not a valid http(s) URL. Fix the host name.`);
    }
    return { prefix, origin };
  }
  throw new Error(`assetBase "${value}" is not allowed. Use a relative path or an http(s) URL.`);
}

/**
 * Make a stable, safe id from a heading.
 * @param {string} heading
 * @returns {string}
 */
export function slugify(heading) {
  const slug = heading
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return slug || 'section';
}
