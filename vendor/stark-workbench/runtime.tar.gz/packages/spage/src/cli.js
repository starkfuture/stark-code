// @ts-check
/**
 * `spage` command-line entry. `main(argv, ctx)` returns an exit code:
 * 0 success, 1 usage or internal error, 2 validation errors.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parseArgs } from 'node:util';
import { DepsError, loadFormat, loadRenderer, makeRender } from './deps.js';
import { PAGE_TYPES, ensureGitExclude, isSlug, listPageRefs, pagesDir, readPageText, resolvePageArg, stateDir } from './pages.js';
import { readTemplate, setHeaderFields } from './templates.js';
import * as server from './server.js';
import { hookPostToolUse, hookSessionStart, localDay, markOpened } from './hook.js';
import { safeTerminalText } from './text.js';
import { formatChecks, runDoctor } from './doctor.js';

export const USAGE = `Usage: spage <command> [options]

Commands:
  new <type> <slug> [--root DIR] [--title T] [--owner O] [--author A]
                                   create pages/<slug>/index.md from a template
  validate <page> [--strict] [--json]
                                   check a page (folder or index.md)
  render <page> [--out FILE] [--theme stark|host]
                                   write the page as one HTML file
  list [--root DIR] [--json]       list pages and whether they pass the check
  serve [--root DIR] [--port N] [--open]
                                   start the browser mirror on 127.0.0.1
  notify <page>                    tell a running mirror to show a page
  publish prepare <page> [--project NAME] [--json]
                                   check a page and build its Stark Pages bundle
  publish record <page>            note the published URL in the page header
                                   (the URL Stark kept when the upload was committed)
  fonts fetch                      download the Stark fonts for published pages into ~/.stark/fonts
  image add <page> <file> [--name N] [--json]
                                   add an image file to the page's img/ folder
  image paste <page> [--name N] [--json]
                                   add the image on the clipboard (macOS)
  hook <event>                     used by the Claude Code plugin hooks; event is
                                   post-tool-use, session-start, pre-tool-use,
                                   post-tool-use-pages or user-prompt-submit
  doctor [--root DIR]              check the setup

Page types: ${PAGE_TYPES.join(', ')}
`;

/**
 * @typedef {{
 *   io: { stdout: { write: (s: string) => unknown }, stderr: { write: (s: string) => unknown }, stdin?: NodeJS.ReadableStream & { isTTY?: boolean } },
 *   env?: Record<string, string | undefined>,
 *   cwd?: string,
 *   now?: () => Date,
 *   getFormat?: () => Promise<import('./deps.js').FormatApi>,
 *   getRenderer?: () => Promise<import('./deps.js').RendererApi>,
 *   server?: Partial<typeof server>,
 *   sleep?: (ms: number) => Promise<void>,
 *   homedir?: string,
 *   username?: string,
 *   fetch?: typeof globalThis.fetch,
 *   readClipboard?: (o: { page?: string }) => Promise<Buffer | null>,
 * }} CliContext
 */

class UsageError extends Error {}

/**
 * @param {string[]} args
 * @param {Record<string, { type: 'string' | 'boolean', short?: string }>} options
 * @param {[number, number]} positionalCount
 */
function parse(args, options, [min, max]) {
  let parsed;
  try {
    parsed = parseArgs({ args, options, allowPositionals: true, strict: true });
  } catch (e) {
    throw new UsageError(e instanceof Error ? e.message : String(e));
  }
  if (parsed.positionals.length < min) throw new UsageError('Missing arguments.');
  if (parsed.positionals.length > max) throw new UsageError(`Unexpected argument "${parsed.positionals[max]}".`);
  return parsed;
}

/** @param {string} cwd @param {string} p */
function display(cwd, p) {
  const r = path.relative(cwd, p);
  return r && !r.startsWith('..') ? r : p;
}

/** @param {Date} d */
function isoSeconds(d) {
  return d.toISOString().replace(/\.\d{3}Z$/, 'Z');
}

/**
 * @param {string[]} argv arguments after the program name
 * @param {CliContext} ctx
 * @returns {Promise<number>}
 */
export async function main(argv, ctx) {
  const io = ctx.io;
  const env = ctx.env ?? process.env;
  const cwd = ctx.cwd ?? process.cwd();
  const now = ctx.now ?? (() => new Date());
  const getFormat = ctx.getFormat ?? loadFormat;
  const getRenderer = ctx.getRenderer ?? loadRenderer;
  const srv = { ...server, ...(ctx.server ?? {}) };
  const [command, ...rest] = argv;

  try {
    switch (command) {
      case undefined:
      case 'help':
      case '--help':
      case '-h':
        io.stdout.write(USAGE);
        return command === undefined ? 1 : 0;

      case 'new': {
        const { values, positionals } = parse(rest, {
          root: { type: 'string' }, title: { type: 'string' }, owner: { type: 'string' }, author: { type: 'string' },
        }, [2, 2]);
        const [type, slug] = positionals;
        if (!PAGE_TYPES.includes(type)) throw new UsageError(`Unknown page type "${type}". Use one of: ${PAGE_TYPES.join(', ')}.`);
        if (!isSlug(slug)) throw new UsageError(`"${slug}" is not a valid slug. Use 3 to 64 lowercase letters, digits and hyphens, like "kc-golive-date".`);
        const author = values.author ?? 'human';
        if (!['claude', 'codex', 'human'].includes(author)) throw new UsageError('--author must be claude, codex or human.');
        const root = path.resolve(cwd, values.root ?? '.');
        const dir = path.join(pagesDir(root), slug);
        const file = path.join(dir, 'index.md');
        if (fs.existsSync(file)) {
          io.stderr.write(`${display(cwd, file)} already exists. Pick another slug, or edit that page.\n`);
          return 1;
        }
        const title = values.title ?? slug.split('-').map((w, i) => (i === 0 ? w.charAt(0).toUpperCase() + w.slice(1) : w)).join(' ');
        if (title.length < 3 || title.length > 120 || /[\r\n]/.test(title)) throw new UsageError('--title must be 3 to 120 characters on one line.');
        const owner = values.owner ?? ctx.username ?? safeUsername();
        const text = setHeaderFields(readTemplate(type), {
          schema: 1, type, title, owner, status: 'draft', id: slug, created: isoSeconds(now()), author,
        });
        const firstPage = !fs.existsSync(pagesDir(root));
        fs.mkdirSync(path.join(dir, 'img'), { recursive: true });
        fs.writeFileSync(file, text, { flag: 'wx' });
        // Drafts stay out of git: the first page in a repo adds pages/ to .git/info/exclude.
        const excluded = firstPage && ensureGitExclude(root);
        io.stdout.write(`Created ${display(cwd, file)}\n`);
        if (excluded) io.stdout.write('Added pages/ to .git/info/exclude, so drafts are not committed by accident.\n');
        return 0;
      }

      case 'validate': {
        const { values, positionals } = parse(rest, { strict: { type: 'boolean' }, json: { type: 'boolean' } }, [1, 1]);
        const ref = resolvePageArg(positionals[0], cwd);
        let text;
        try {
          text = fs.readFileSync(ref.file, 'utf8');
        } catch {
          io.stderr.write(`Cannot read ${display(cwd, ref.file)}. Give a page folder or its index.md.\n`);
          return 1;
        }
        const format = await getFormat();
        const result = format.validatePage(text, { path: ref.file, strict: Boolean(values.strict) });
        const label = display(cwd, ref.file);
        if (values.json) {
          io.stdout.write(JSON.stringify({ file: label, ok: result.ok, errors: result.errors, warnings: result.warnings }, null, 2) + '\n');
        } else if (result.errors.length || result.warnings.length) {
          io.stderr.write(format.formatIssues(result, { file: label }).trimEnd() + '\n');
        } else {
          io.stdout.write(`${label}: no problems\n`);
        }
        return result.ok ? 0 : 2;
      }

      case 'render': {
        const { values, positionals } = parse(rest, { out: { type: 'string' }, theme: { type: 'string' } }, [1, 1]);
        const theme = values.theme ?? 'stark';
        if (theme !== 'stark' && theme !== 'host') throw new UsageError('--theme must be stark or host.');
        const ref = resolvePageArg(positionals[0], cwd);
        let text;
        try {
          text = fs.readFileSync(ref.file, 'utf8');
        } catch {
          io.stderr.write(`Cannot read ${display(cwd, ref.file)}. Give a page folder or its index.md.\n`);
          return 1;
        }
        const format = await getFormat();
        const renderer = await getRenderer();
        const doc = format.parsePage(text, { path: ref.file });
        const validation = format.validatePage(doc, { path: ref.file });
        const out = path.resolve(cwd, values.out ?? path.join(ref.dir, '.render', 'index.html'));
        // img/ paths are written relative to the output file, wherever it is
        const relDir = path.relative(path.dirname(out), ref.dir).split(path.sep).join('/');
        const assetBase = relDir ? `${relDir}/` : '';
        // Diagrams are drawn first (renderPage stays synchronous); the drawings are cached
        // next to the mirror's in pages/.spage/diagrams/. A failed drawing shows as source.
        /** @type {Map<number, any> | undefined} */
        let diagrams;
        const hasDiagram = Array.isArray(doc?.blocks) && doc.blocks.some((/** @type {any} */ b) => b && b.lang === 'mermaid');
        if (hasDiagram && typeof renderer.drawDiagrams === 'function') {
          diagrams = await renderer.drawDiagrams(doc, { cacheDir: path.join(stateDir(ref.root), 'diagrams') });
        }
        const html = renderer.renderPage(doc, { mode: 'document', theme, assetBase, validation, ...(diagrams ? { diagrams } : {}) });
        fs.mkdirSync(path.dirname(out), { recursive: true });
        fs.writeFileSync(out, html);
        io.stdout.write(`Wrote ${display(cwd, out)}${validation.ok ? '' : ` (the page has ${validation.errors.length} error${validation.errors.length === 1 ? '' : 's'}; they are listed at the top)`}\n`);
        return 0;
      }

      case 'list': {
        const { values } = parse(rest, { root: { type: 'string' }, json: { type: 'boolean' } }, [0, 0]);
        const root = path.resolve(cwd, values.root ?? '.');
        const format = await getFormat();
        const rows = listPageRefs(root).map((ref) => {
          try {
            const read = readPageText(ref.file);
            const result = read.ok
              ? format.validatePage(read.text, { path: ref.file })
              : { ok: false, errors: [read.issue], warnings: [], doc: null };
            const h = result.doc?.header ?? {};
            return {
              slug: ref.slug,
              type: typeof h.type === 'string' ? h.type : '?',
              status: typeof h.status === 'string' ? h.status : '?',
              title: typeof h.title === 'string' ? h.title : ref.slug,
              errors: result.errors.length,
              warnings: result.warnings.length,
            };
          } catch {
            // One unreadable page (no permission, say) must not hide the others.
            return { slug: ref.slug, type: '?', status: '?', title: ref.slug, errors: 0, warnings: 0, unreadable: true };
          }
        });
        if (values.json) {
          io.stdout.write(JSON.stringify(rows, null, 2) + '\n');
          return 0;
        }
        if (rows.length === 0) {
          io.stdout.write(`No pages in ${display(cwd, pagesDir(root)) || 'pages'}. Make one with "spage new report <slug>".\n`);
          return 0;
        }
        const shown = rows.map((r) => ({ ...r, type: safeTerminalText(r.type), status: safeTerminalText(r.status), title: safeTerminalText(r.title) }));
        const w = (/** @type {string} */ k) => Math.max(...shown.map((r) => String(/** @type {any} */ (r)[k]).length));
        const ws = w('slug'), wt = w('type'), wst = w('status');
        for (const r of shown) {
          const state = 'unreadable' in r ? 'cannot read' : r.errors ? `${r.errors} error${r.errors === 1 ? '' : 's'}` : 'valid';
          io.stdout.write(`${r.slug.padEnd(ws)}  ${r.type.padEnd(wt)}  ${r.status.padEnd(wst)}  ${r.title}  [${state}]\n`);
        }
        return 0;
      }

      case 'serve': {
        const { values } = parse(rest, { root: { type: 'string' }, port: { type: 'string' }, open: { type: 'boolean' } }, [0, 0]);
        const root = path.resolve(cwd, values.root ?? '.');
        let port;
        if (values.port !== undefined) {
          port = Number(values.port);
          if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new UsageError('--port must be a number from 1024 to 65535.');
        }
        const live = await srv.liveMirror(root);
        if (live) {
          io.stdout.write(`Mirror already running: ${srv.followUrl(live.port)}\n`);
          if (values.open) srv.openUrl(srv.followUrl(live.port));
          return 0;
        }
        const deps = { format: await getFormat(), renderer: await getRenderer() };
        let started;
        try {
          started = await srv.startMirror({
            root, port, render: makeRender(deps, { diagramCacheDir: path.join(stateDir(root), 'diagrams') }), log: (s) => io.stdout.write(`${s}\n`),
          });
        } catch (e) {
          const code = /** @type {NodeJS.ErrnoException} */ (e).code;
          if (code === 'ELOCKED') {
            io.stdout.write(`${e instanceof Error ? e.message : String(e)}\n`);
            return 0;
          }
          if (code === 'EPERM' || code === 'EACCES') {
            io.stderr.write('The sandbox does not allow this process to open a port. Run "spage serve" in your own terminal, or let the plugin\'s SessionStart hook start it.\n');
            return 1;
          }
          throw e;
        }
        io.stdout.write(`Stark mirror for ${root}\n${started.url}\nPress Ctrl+C to stop.\n`);
        if (values.open) {
          srv.openUrl(started.url);
          // The follower is open now; the session-start hook does not open it again today.
          markOpened(root, localDay(now()));
        }
        // keep running until a signal stops the process
        await new Promise(() => {});
        return 0;
      }

      case 'notify': {
        const { positionals } = parse(rest, {}, [1, 1]);
        const ref = resolvePageArg(positionals[0], cwd);
        if (!fs.existsSync(ref.file)) {
          io.stderr.write(`No page at ${display(cwd, ref.file)}.\n`);
          return 1;
        }
        if (!isSlug(ref.slug)) {
          io.stderr.write(`"${ref.slug}" is not a valid page slug.\n`);
          return 1;
        }
        await srv.notifyMirror(ref.root, ref.slug);
        return 0;
      }

      case 'hook': {
        const which = rest[0];
        // pre-tool-use runs before every Bash, Write, Edit and MCP call: it loads only the guard.
        if (which === 'pre-tool-use') {
          const { hookPreToolUse } = await import('./guard.js');
          return await hookPreToolUse({ io, env, cwd, now, ...(ctx.homedir ? { homedir: ctx.homedir } : {}) });
        }
        if (which === 'post-tool-use-pages') {
          const { hookPostToolUsePages } = await import('./guard.js');
          return await hookPostToolUsePages({
            io, env, cwd, now, ...(ctx.homedir ? { homedir: ctx.homedir } : {}), ...(ctx.fetch ? { fetch: ctx.fetch } : {}),
          });
        }
        if (which === 'user-prompt-submit') {
          const { hookUserPromptSubmit } = await import('./inbox.js');
          return await hookUserPromptSubmit({ io, env, cwd, now });
        }
        const hctx = { io, env, cwd, now, getFormat, server: ctx.server, sleep: ctx.sleep, homedir: ctx.homedir };
        if (which === 'post-tool-use') return await hookPostToolUse(hctx);
        if (which === 'session-start') return await hookSessionStart(hctx);
        throw new UsageError('Use "spage hook" with post-tool-use, session-start, pre-tool-use, post-tool-use-pages or user-prompt-submit.');
      }

      case 'publish': {
        const { publishCommand } = await import('./publish/index.js');
        return await publishCommand(rest, {
          io, cwd, env, now, getFormat, getRenderer,
          ...(ctx.homedir ? { homedir: ctx.homedir } : {}),
          ...(ctx.fetch ? { fetch: ctx.fetch } : {}),
        });
      }

      case 'fonts': {
        const { fontsCommand } = await import('./publish/index.js');
        return await fontsCommand(rest, {
          io, cwd, getRenderer, ...(ctx.fetch ? { fetch: ctx.fetch } : {}), ...(ctx.homedir ? { homedir: ctx.homedir } : {}),
        });
      }

      case 'image':
        return await imageCommand(rest, { io, cwd, ...(ctx.readClipboard ? { readClipboard: ctx.readClipboard } : {}) });

      case 'doctor': {
        const { values } = parse(rest, { root: { type: 'string' } }, [0, 0]);
        const root = path.resolve(cwd, values.root ?? '.');
        const checks = await runDoctor({ root, getFormat, getRenderer, server: ctx.server, ...(ctx.homedir ? { home: ctx.homedir } : {}) });
        io.stdout.write(formatChecks(checks));
        return checks.some((c) => c.level === 'fail') ? 1 : 0;
      }

      default:
        throw new UsageError(`Unknown command "${command}".`);
    }
  } catch (e) {
    if (e instanceof UsageError) {
      io.stderr.write(`${e.message}\n\n${USAGE}`);
      return 1;
    }
    if (e instanceof DepsError) {
      io.stderr.write(`${e.message}\n`);
      return 1;
    }
    io.stderr.write(`spage: ${e instanceof Error ? e.message : String(e)}\n`);
    return 1;
  }
}

/**
 * `spage image add <page> <file>` and `spage image paste <page>` (CONTRACTS.md 13.2).
 * Exit 0 added, 1 usage error, no image on the clipboard or a clipboard that cannot be
 * read here (the sandbox), 2 the image was refused.
 * @param {string[]} argv arguments after "image"
 * @param {{ io: CliContext['io'], cwd: string, readClipboard?: CliContext['readClipboard'] }} c
 * @returns {Promise<number>}
 */
async function imageCommand(argv, c) {
  const { io, cwd } = c;
  const [sub, ...rest] = argv;
  if (sub !== 'add' && sub !== 'paste') throw new UsageError('Use "spage image add <page> <file>" or "spage image paste <page>".');
  const { values, positionals } = parse(rest, { name: { type: 'string' }, json: { type: 'boolean' } }, sub === 'add' ? [2, 2] : [1, 1]);
  const ref = resolvePageArg(positionals[0], cwd);
  if (!fs.existsSync(ref.file)) {
    io.stderr.write(`No page at ${display(cwd, ref.file)}. Give a page folder or its index.md.\n`);
    return 1;
  }
  const images = await import('./images.js');
  /** @type {{ file: string, markdown: string, notes: string[] }} */
  let added;
  try {
    if (sub === 'add') {
      const file = path.resolve(cwd, positionals[1]);
      added = await images.addImage(ref.dir, file, {
        ...(typeof values.name === 'string' ? { name: values.name } : {}),
        retry: `image add ${shellArg(positionals[0])} ${shellArg(positionals[1])}`,
      });
    } else {
      const bytes = await (c.readClipboard ?? images.readClipboardImage)({ page: positionals[0] });
      if (!bytes) {
        io.stderr.write('The clipboard has no image. Copy an image or a screenshot first.\n');
        return 1;
      }
      added = await images.addImage(ref.dir, bytes, {
        name: typeof values.name === 'string' ? values.name : 'pasted-image',
        retry: `image paste ${shellArg(positionals[0])}`,
      });
    }
  } catch (e) {
    if (e instanceof images.ImageError) {
      io.stderr.write(`${e.message}\n`);
      // A clipboard that cannot be read here is not a refused image: exit 1, like an empty clipboard.
      return /^clipboard-/.test(String(e.code)) ? 1 : 2;
    }
    throw e;
  }
  if (values.json) {
    io.stdout.write(JSON.stringify({ file: `img/${added.file}`, markdown: added.markdown, notes: added.notes }, null, 2) + '\n');
    return 0;
  }
  io.stdout.write(`Added ${display(cwd, path.join(ref.dir, 'img', added.file))}\n`);
  for (const n of added.notes) io.stdout.write(`${safeTerminalText(n)}\n`);
  io.stdout.write(`Put this in the page, with real alt text:\n${added.markdown}\n`);
  return 0;
}

/** A word for a command line the user runs: quoted when it holds anything but plain path characters. */
function shellArg(/** @type {string} */ s) {
  return /^[A-Za-z0-9_./@:+-]+$/.test(s) ? s : `'${s.replace(/'/g, `'\\''`)}'`;
}

function safeUsername() {
  try {
    return os.userInfo().username || 'unknown';
  } catch {
    return 'unknown';
  }
}
